Short plugin documentation

-= Warning =-
Plugins can be dangerous, they have access to the system where the JTS3ServerMod process is running,
to the Teamspeak 3 server and (if used) the MySQL database.
So only use plugins from a person you trust or after checking the source code.
The author of the JTS3ServerMod is not responsible for any damage or data loss!


-= Usage of plugins =-
Plugins will be set as bot function at bot_functions in the main bot configuration file JTS3ServerMod_server.cfg.
Set the filename of the plugin as function class, example: AutoKickTimer.jar:akt
If using MySQL, it has to be set in the MySQL database to the bot settings.

If you use the official JTS3ServerMod Web Interface,
you have to import a SQL file of the plugin to the MySQL database.

In case you want to configure the AutoKickTimer plugin with the official JTS3ServerMod Web Interface,
you have to import the included AutoKickTimer.sql file to the MySQL database of the Web Interface.


-= Create own plugins =-
If you want to use "Eclipse IDE for Java Developers", just check out my how to:
http://www.stefan1200.de/documentation/jts3servermod/jts3servermod_plugindevelopment/index.html

Full API documentation are included in the JTS3ServerMod directory at:
documents\Plugin_API\index.html

Plugin API sources/interfaces are included in the JTS3ServerMod directory at:
documents\plugin_sources\plugin_api_src.zip

Plugin API binary files (to add it as library in your IDE) are included in the JTS3ServerMod directory at:
documents\plugin_sources\plugin_api_bin.zip

Example source code of the AutoKickTimer.jar are included in the JTS3ServerMod directory at:
documents\plugin_sources\AutoKickTimer_src.zip

Just as hint: Every plugin has to implement the HandleBotEvents interface.
So you should start with an empty class (include an empty main method),
implement the HandleBotEvents interface (and it's methods) and play around a bit,
to understand how everything works. Later just add more interfaces which you need to reach your goal.

If you export your plugin into a jar file, make sure to include only your own classes/files,
don't include the classes from the plugin_api_src.zip. Set the class of your plugin,
which implements the HandleBotEvents interface, as Main-Class in your MANIFEST.MF of the jar file.
Programs like Eclipse can do this using the JAR Export wizard.
It is recommended to use the java compiler with the source and target argument set at version 1.5 (Java 5),
like the JTS3ServerMod do. This can be set in the project settings of the most IDEs.

Some stuff has to be done, to allow the JTS3ServerMod Web Interface to support a plugin.
Currently not everything is documented, but look at the description below and
into the AutoKickTimer.sql file to get an idea.
The result of the AutoKickTimer.sql can be seen in the AutoKickTimer_WebInterface.png image.

Table jts3servermodwebui_botfunction, description of the columns:
classname -> Filename of the plugin jar file.
multiple_use -> 0 or 1 if multiple use of the plugin is useful or allowed.

Table jts3servermodwebui_functionpage, description of the columns:
configkey -> Config key without the plugin config prefix.
sortnr -> Just the order on the config page.
groupnext -> Default is 0, set to 1 and no separator line below the option will be added.
typename -> Possible values: number, channel, channelgroup, servergroup, select, multilinetext, longtext, text
options -> number: allowed number range separated with a comma like 1,99 to allow numbers between 1 and 99
options -> channel, channelgroup, servergroup: Choose the allowed selection: single / multiple
options -> select: all options separated with a comma like yes,maybe,no

You can publish your plugins on my forum at https://www.stefan1200.de
Just request a free forum account by mail at info@stefan1200.de