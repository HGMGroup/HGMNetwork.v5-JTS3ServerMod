JTS3ServerMod
Author: Stefan Martens

E-Mail:
info@stefan1200.de

Homepage:
http://www.stefan1200.de


-= Inhaltsverzeichnis =-
Copyright
Informationen
Systemanforderungen
Wie kann ein flood ban auf dem TS3 Server verhindert werden
Allgemeine Informationen zur Installation und Benutzung
Bot einrichten (alle Betriebssysteme)
Bot unter Linux starten
Bot unter Windows starten
Wie finde ich die Channel ID / Eindeutige Client ID / Client Datenbank ID / Server Gruppen ID / Channel Gruppen ID
Welche Query Login Zugangsdaten verwende ich f�r den Bot
Ben�tigte Rechte f�r den Bot
Sichtbarkeit vom Bot im Teamspeak
Verschiedene Mitteilungsarten
Globale Variablen f�r Texte
Benutzung auf dem Teamspeak Server / Chat Befehle
Log Datei
Wird Hilfe ben�tigt?
Danke


-= Copyright =-
Dieses Programm darf kostenlos f�r private Zwecke verwendet werden, aber bitte informiere mich, wenn ein Fehler gefunden worden ist.
Der Autor von diesem Programm ist nicht verantwortlich f�r irgendwelche Sch�den oder Datenverlust!
Es ist nicht erlaubt dieses Programm zu verkaufen, es muss frei erh�ltlich sein!
Die Ver�nderung der Dateiinhalte aller Dateien, die dem JTS3ServerMod beiliegen, einschlie�lich dieser Anleitung, ist nicht gestattet!
Decompilieren ist verboten! Ebenfalls verboten ist es Teile vom Quellcode in anderen Programmen weiter zu verwenden!
Die kommerzielle Nutzung, das hei�t es wird Geld f�r den Teamspeak 3 Server oder einen Bot vom JTS3ServerMod verlangt,
ist nur nach schriftlicher Genehmigung von dem oben genannten Autor des JTS3ServerMod gestattet!

Teamspeak 3 wird entwickelt von TeamSpeak Systems GmbH, Verkauf und Lizensierungen durch Triton CI & Associates, Inc.
Weitere Informationen zu Teamspeak 3: http://www.teamspeak.com

Launch4j wurde zur Erstellung der ausf�hrbaren Windows Dateien des JTS3ServerMod verwendet. Launch4j verwendet die BSD/MIT Lizenz.
Weitere Informationen zu Launch4j: http://launch4j.sourceforge.net

procrun kann verwendet werden, um den JTS3ServerMod als Windows Dienst einzurichten. procrun ist ein Produkt von Apache Commons und verwendet die Apache Lizenz.
Weitere Informationen zu procrun: http://commons.apache.org/proper/commons-daemon/procrun.html

Jsch Bibliothek wird f�r die Verbindung zur verschl�sselten SSH Query vom TS3 Server 3.3.0 oder neuer verwendet.
Jsch ist ein Produkt von JCraft,Inc. and verwendet eine BSD �hnliche Lizenz.
Weitere Informationen zu Jsch: http://www.jcraft.com/jsch/


-= Informationen =-
Dieses Programm erweitert den Teamspeak 3 Server um einige weitere Funktionen. Hier die Liste:
- Automatisches Verschieben von Mitgliedern gew�hlter Server Gruppen in bestimmte Channels, wenn kein eigener Standard Channel gesetzt ist.
- Channel Notify, sendet eine Nachricht wenn ein Client einen bestimmten Channel betritt.
- Server Group Notify, sendet eine Nachricht wenn Mitglieder gew�hlter Server Gruppen den Server betreten.
- Server Gruppen k�nnen vor unerlaubten Clients besch�tzt werden.
- Client Namen k�nnen nach unerlaubten W�rtern oder Zeichen untersucht und ggf. gekickt werden.
- Channel Namen k�nnen nach unerlaubten W�rtern oder Zeichen untersucht und ggf. gel�scht werden.
- Einen unt�tigen (idle) Client zu einer Server Gruppe hinzuf�gen, um den Server Gruppen Namen (z.B. AFK) beim Client Namen stehen zu haben.
- Unt�tige (Idle) Clients in einen bestimmten Raum bewegen oder vom Server werfen. In beiden F�llen bekommt dieser eine Nachricht.
- Verschickt eine Warnnachricht an unt�tige (Idle) Clients.
- Inaktive Channel �berpr�fung kann Channels l�schen, die bereits seit vielen Stunden/Tagen ungenutzt sind.
- Inaktive Clients k�nnen nach X Tagen Inaktivit�t aus der TS3 Server Datenbank gel�scht werden.
- Aufnehmende Clients in einen Raum bewegen oder vom Server werfen. In beiden F�llen bekommt dieser eine Nachricht.
- Nach kurzer Zeit k�nnen Clients mit aktivierten Abwesendheitsstatus (Away) in einen Raum bewegt werden.
  Das zur�ck bewegen, wenn der Client nicht mehr abwesend ist, ist einschaltbar.
- Nach kurzer Zeit k�nnen Clients mit stumm geschalteten Kopfh�hrern oder Mikrofon in einen Raum bewegt werden.
  Das zur�ck bewegen, wenn der Client nicht mehr stumm geschaltet ist, ist einschaltbar.
- Kann in Intervallen eine Textnachricht an den Server oder bestimmten Raum Chat senden.
- Jeder Client der sich mit dem Server verbindet, kann eine Willkommensnachricht bekommen.
  Auch spezielle Willkommensnachrichten f�r bestimmte Server Gruppen m�glich.
- !lastseen Chat Befehl um auszugeben, wann jemand zuletzt auf dem Teamspeak Server war.
Alles kann ausf�hrlich eingestellt oder abgeschaltet werden.

Weitere Funktionen sind:
- Viele Bot Instanzen f�r verschiedene Teamspeak 3 Server in einem Bot Prozess sind nutzbar.
- Automatisches Neuverbinden wenn die Verbindung zum Teamspeak 3 Server verloren geht.
- Viele Chat Befehle erm�glichen unter anderem das Senden von Nachrichten, Client Informationen abfragen, das �ndern der Einstellungen,
  das Neuladen der Einstellungen oder um den Bot zu beenden.
- Erstelle eigene Plugins mit der Java Programmiersprache.
- Langsamer Modus um die Nutzung des Bots (mit eingeschr�nkten Funktionen) auch ohne �nderung der query_ip_whitelist.txt zu erm�glichen.


-= Systemanforderungen =-
Dieses Programm wurde getestet unter Windows und Linux (auch ohne X Server).
Auf Mac OS X 10.7.3+, Solaris und FreeBSD sollte es ebenfalls laufen, dies ist allerdings ungetestet.
Wer es testen kann, m�ge mir bitte eine E-Mail zukommen lassen.
Alles was ben�tigt wird ist die Java SE Laufzeitumgebung Version 7 oder neuer.
Die neuste Version f�r Windows, Mac OS X, Linux und Solaris ist auf http://www.java.com/de/download/manual.jsp zu bekommen.
FreeBSD Anwender k�nnen sich auf http://www.freebsd.org/de/java/ �ber Java auf FreeBSD informieren.

Linux Anwender sollten das Java Paket �ber das Betriebssystem installieren,
so k�nnen Sicherheitsaktualisierungen bequem �ber die Paketverwaltung installiert werden.
Um dies ganz leicht zu installieren, verwende einfach das jts3servermod_startscript.sh als root mit dem java Argument.
Bevor das Skript das erste Mal verwendet werden kann, gehe einfach in das Verzeichnis vom JTS3ServerMod
und erlaube die Ausf�hrung von diesem Skript:
chmod +x jts3servermod_startscript.sh
Anschlie�end gebe einfach folgendes ein:
./jts3servermod_startscript.sh java
Dies �berpr�ft, ob Java bereits installiert ist, und wenn nicht, kann es das direkt erledigen.
Wenn die automatische Installation nicht funktioniert:
Ein Beispiel f�r Debian oder Ubuntu: apt-get install openjdk-8-jre-headless
Ein Beispiel f�r CentOS oder Fedora -21: yum install java-1.8.0-openjdk-headless
Ein Beispiel f�r Fedora 22+: dnf install java-1.8.0-openjdk-headless
Ein Beispiel f�r OpenSUSE: zypper install java-1_8_0-openjdk-headless
Je nach der verwendeten Version der Distribution, existiert die OpenJDK Version aus dem Beispiel nicht.
In dem Fall ersetze einfach die 8 vom Paketnamen mit der 7 oder 9.
Das Paket gcj-jre (GNU Java) wird nicht funktionieren! Zudem keine Preview oder Alpha Versionen von Java verwenden!

Vielleicht soll der maximale dynamische Speicher, den Java benutzen soll, begrenzt werden.
Das kann auf einem virtuellen Server n�tzlich sein.
Dies kann mit einem Java Befehlszeilen Argument f�r die Java Virtuelle Maschine erledigt werden.
Wenn zum Beispiel nur 30 MB Arbeitsspeicher maximal verwendet werden soll, starte den Bot mit folgendem Argument:
java -mx30M -jar JTS3ServerMod.jar
Hinweis: Wenn ein zu niedriger Wert gew�hlt wird, l�uft der Bot nicht oder nicht stabil. Sinnvoll sind die Werte zwischen 30M und 50M.
Ich habe hierzu keine Langzeittests durchgef�hrt. Der Bot ben�tigt weniger Arbeitsspeicher,
wenn der Client Datenbank Cache deaktiviert wird und nur eine Bot Instanz verwendet wird.

Teamspeak 3 Server 3.0 oder neuer wird ben�tigt, empfohlen ist aber immer die neuste Version.
Nat�rlich wird auch eine Verbindung zum Teamspeak 3 Server ben�tigt.

Stelle sicher, dass die IP Adresse vom Bot in der query_ip_whitelist.txt Datei auf dem Teamspeak 3 server eingetragen ist.
Weitere Informationen hierzu im Abschnitt "-= Wie kann ein flood ban auf dem TS3 Server verhindert werden? =-" in dieser Readme Datei.


-= Wie kann ein flood ban auf dem TS3 Server verhindert werden =-
Wenn der Bot nach der Verbindung mit dem TS3 Server gebannt wird, pr�fe die Log Datei vom Bot.
Wenn folgende Zeile in der Log Datei vorhanden ist (die Zahl kann abweichen), dann sollte die L�sung funktionieren:
de.stefan1200.jts3serverquery.TS3ServerQueryException: ServerQuery Error 3331: flood ban

L�sung:
Die IP Adresse, von dem Rechner auf dem der Bot l�uft, sollte in die Datei query_ip_whitelist.txt des Teamspeak 3 Servers hinzugef�gt werden.
Wenn der Bot auf dem selben Rechner wie der TS3 Server l�uft, verwende 127.0.0.1 als TS3 Server Adresse in der Bot Konfiguration.
Diese ist in der Regel bereits freigeschaltet. Falls dies nicht beachtet wird, wird die Anti Spam Funktion
des Teamspeak 3 Server das Programm sehr oft f�r einige Minuten bannen.

Falls ein Bearbeiten der query_ip_whitelist.txt nicht m�glich ist,
versuche in der Bot Server Konfigurationsdatei den bot_slowmode auf 1 zu setzen.
Dies verlangsamt den Bot beim Verbinden und schaltet einige Funktionen ab.


-= Allgemeine Informationen zur Installation und Benutzung =-
Einfach diese ZIP Datei komplett entpacken, behalte die Verzeichnisse so bei, wie diese in der ZIP Datei vorgegeben sind.
Es ist nicht n�tig den Bot in das selbe Verzeichnis zu legen, wie den Teamspeak 3 Server,
der Bot ist ein eigenst�ndiges Programm, welches einfach eine Verbindung zum Teamspeak 3 Server Telnet Query Port herstellt.

Standardm��ig gibt es zwei Hauptkonfigurationsdateien, JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_server.cfg.
Die JTS3ServerMod_InstanceManager.cfg enth�lt alle Informationen �ber virtuelle Bot Instanzen die gestartet werden sollen.
In der Datei lassen sich auch mehrere virtuelle Bot Instanzen einrichten, wenn zum Beispiel mehrere TS3 Server einen Bot
erhalten sollen. Die JTS3ServerMod_server.cfg enth�lt alle Bot Einstellungen einer virtuellen Instanz.
Jede virtuelle Bot Instanz ben�tigt eine eigene Konfigurationsdatei.
Wird also ein weiterer Bot in der JTS3ServerMod_InstanceManager.cfg angelegt, so muss das server1 Verzeichnis kopiert und
in zum Beispiel server2 umbenannt werden. Dann muss in der JTS3ServerMod_InstanceManager.cfg auf den neuen Verzeichnisnamen
entsprechend beim neu angelegten Bot verwiesen werden.

Beide Konfigurationsdateien sollten nach eigenem Wunsch ge�ndert werden. Alles ist direkt in den Dateien erkl�rt.
F�r weitere Informationen zu den Konfigurationsdateien lese documents/ConfigHelp_deutsch.html!
Auf jeden Fall sollte beachtet werden das beide Dateien im ANSI Format (Kodierung ISO-8859-1) gespeichert werden.
Wichtig: Alle anderen Konfigurationsdateien (wie die advertising, record, idle und welcome Texte)
werden standardm��ig im Unicode (UTF-8 ohne BOM) Format gespeichert. Dies kann in der Hauptkonfigurationsdatei ge�ndert werden.

Hinweis: Es befindet sich eine deutsche �bersetzung der Konfigurationsdateien im "documents" Ordner.

Dies ist ein Kommandozeilen Programm, es ben�tigt also eine Shell um Informationen anzuzeigen.
Nat�rlich funktioniert es auch ohne aktives Shell Fenster, alle Informationen werden auch in die Log Datei geschrieben.

Unter Windows kann die cmd.exe oder die mitgelieferten EXE Dateien benutzt werden.
Linux Anwender k�nnen dieses Programm auch ohne X-Server verwenden, es wird keine GUI ge�ffnet.
Wird ein X-Server verwendet, sollte dieses Programm in der Terminal / Shell gestartet werden.
Mac OS X Anwender sollten ebenfalls die Terminal verwenden.

Wenn sich die JTS3ServerMod.jar und der config Ordner (welche die Datei JTS3ServerMod_InstanceManager.cfg enth�lt)
im selben Verzeichnis befinden, kann die Server Modifikation einfach durch folgende Eingabe gestartet werden:
java -jar JTS3ServerMod.jar

Auf virtuellen Servern sollte der Arbeitsspeicher Bedarf von der Java etwas eingeschr�nkt werden.
Weitere Informationen dazu im Abschnitt "-= Systemanforderungen =-", empfohlen ist folgender Wert:
java -mx30M -jar JTS3ServerMod.jar

Sollen sich die Dateien JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_InstanceManager.log an einem anderen Ort befinden
oder einen anderen Dateinamen haben, dann kann das Argument -config und -log verwendet werden, hier ein Beispiel:
java -jar JTS3ServerMod.jar -config cfg/instance.cfg -log log/instance.log

Ein anderes Argument ist -help, welches lediglich eine Liste der Kommandozeilenargumente ausgibt und sich dann beendet.

Es ist auch m�glich eine app.home Umgebungsvariable zu setzen, indem das Argument -Dapp.home=PFAD_ZUM_JTS3SERVERMOD
beim Starten des JTS3ServerMod gesetzt wird. Dadurch wird es m�glich, die Variable %apphome% bei den Pfaden zu
Konfigdateien und Logdateien zu setzen, welche durch den app.home Pfad ersetzt wird.
Wenn die app.home Umgebungsvariable nicht existiert, wird die Variable %apphome% durch eine leere Zeichenkette ersetzt.

Beispiele:
java -Dapp.home="D:\My Services\JTS3ServerMod\" -jar JTS3ServerMod.jar
java -mx30M -Dapp.home="/home/username/my services/JTS3ServerMod/" -jar JTS3ServerMod.jar


-= Bot einrichten (alle Betriebssysteme) =-
Als Erstes sollte gepr�ft werden, ob Java bereits installiert ist.
Dies kann auf der Konsole / Terminal / Eingabeaufforderung mit folgenden Befehl gemacht werden:
java -version
Daraufhin sollte eine Ausgabe der installierten Java Version erscheinen.
Ist dies nicht der Fall, so muss Java noch erst installiert werden.
Weitere Informationen hierzu gibt es in dem Bereich "Systemanforderungen" dieser Anleitung.

Als Zweites muss die ZIP Datei, in der diese Datei zu finden war, vollst�ndig entpackt werden.
Es ist nicht n�tig den Bot in das selbe Verzeichnis zu legen, wie den Teamspeak 3 Server,
der Bot ist ein eigenst�ndiges Programm, welches einfach eine Verbindung zum Teamspeak 3 Server Telnet Query Port herstellt.
In dem Ordner config befinden sich alle Konfigdateien, welche nach den eigenen W�nschen angepasst werden m�ssen.

Hinweis: Es befindet sich eine deutsche �bersetzung der Konfigurationsdateien im "documents" Ordner.

Wichtige Einstellungen in der Konfigdatei JTS3ServerMod_server.cfg,
diese m�ssen korrekt angegeben werden, um die Funktion vom Bot zu gew�hrleisten:
ts3_server_address
ts3_server_query_port
ts3_server_query_login
ts3_server_query_password
ts3_virtualserver_id / ts3_virtualserver_port
bot_slowmode

Standardm��ig sind alle Funktionen in der Konfigdatei abgeschaltet.
Diese m�ssen dann nach eigenen W�nschen in der bot_functions Zeile aktiviert werden.
F�r weitere Informationen zu den Funktionen lese documents/ConfigHelp_deutsch.html!
Aber geht mit folgenden Funktionen vorsichtig um, denn bei falschen Einstellungen k�nnen diese gro�e Probleme bereiten:
BadNicknameCheck
BadChannelNameCheck
InactiveChannelCheck
ServerGroupProtection

Damit der Bot eine oder mehrere Personen als Admin erkennt, eines der beiden Einstellungen setzen:
Bot Full Admin (alle Admin Befehle, nur Personen denen man vertraut!): JTS3ServerMod_InstanceManager.cfg -> bot_fulladmin_list
Bot Admin (nur die Admin Befehle der virtuellen Bot Instanz): JTS3ServerMod_server.cfg -> bot_admin_list

Damit sind die Grundeinstellungen gemacht. Alle Dateien speichern, dabei sollte beachtet werden
das die Dateien JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_server.cfg im ANSI Format (Kodierung ISO-8859-1)
gespeichert werden m�ssen. Alle anderen Konfigurationsdateien (wie die advertising, record, idle und welcome Texte)
werden standardm��ig im Unicode (UTF-8 ohne BOM) Format gespeichert.
Dies kann jedoch in der Datei JTS3ServerMod_server.cfg -> bot_messages_encoding ge�ndert werden.

Zum Starten des Bots das entsprechende folgende Kapitel lesen:
Bot unter Linux starten
Bot unter Windows starten


-= Bot unter Linux starten =-
Das erste Mal sollte der Bot so gestartet werden, wie im Abschnitt
"Allgemeine Informationen zur Installation und Benutzung" angegeben.
Sobald dann alles wie gew�nscht l�uft, bitte den Bot beenden (z.B. mit Strg + C) und wie hier beschrieben, weiter verfahren.

Der beste Weg ist die Verwendung vom beiliegenden jts3servermod_startscript.sh Skript.
Gehe einfach in das Verzeichnis vom JTS3ServerMod und erlaube die Ausf�hrung von diesem Skript:
chmod +x jts3servermod_startscript.sh
Anschlie�end kann der JTS3ServerMod einfach gestartet werden:
./jts3servermod_startscript.sh start

Um den JTS3ServerMod zu stoppen:
./jts3servermod_startscript.sh stop

Weitere Argumente von diesem Skript sind: restart, status und java

Falls es hierbei zu Problemen kommt, in dieser Anleitung unter dem Punkt "Systemanforderungen"
ist beschrieben, wie man den ben�tigten Arbeitsspeicher einschr�nken kann.
Dies ist besonders auf Linux VServern interessant.
Damit das Skript dies automatisch macht, �ffne die Datei jts3servermod_startscript.sh mit einem Text Editor,
gehe in Zeile 6 und �ndere
JAVA_COMMANDLINE_PARAMETERS=""
in
JAVA_COMMANDLINE_PARAMETERS="-mx30M"

Stelle ebenfalls sicher, dass das System nicht in das Open Files Limit l�uft, wenn viele Bots gleichzeitig laufen.
Kontrolliere das Open Files Limit mit folgendem Befehl: ulimit -a
Es werden ungef�hr zwei Dateien pro virtueller Bot Instanz ben�tigt.
Beispiel: 200 Bots ben�tigen mindestens ein Open File Limit von 400.
Mit folgendem Befehl kann das Limit ge�ndert werden: ulimit -n <neues Limit>
Das �ndern von diesem Wert hat Auswirkungen auf alle Prozesse auf dem System!
Manchmal wird dieser Wert wieder auf den Standard Wert zur�ck gesetzt.
Bitte pr�fe selbst wie der neue Wert dauerhaft gesetzt werden kann.


-= Bot unter Windows starten =-
Zum Einen kann der Bot unter Windows nat�rlich als normales Programm gestartet werden.
Dazu einfach die JTS3ServerMod-Windows_NoWindow.exe mit einem Doppelklick starten.
Alle Ausgaben sind dann in der Log Datei, welche vom Bot erstellt wird, nachzulesen.
Nat�rlich kann auf eine Verkn�pfung von der JTS3ServerMod-Windows_NoWindow.exe in das
Windows Autostart Verzeichnis kopiert werden, damit der Bot bei der Anmeldung gestartet wird.
Aber stelle sicher das bei der Verkn�pfung als "Ausf�hren in" Verzeichnis das JTS3ServerMod Verzeichnis gesetzt ist.
Um das Windows Autostart Verzeichnis zu �ffnen, dr�cke die beiden Tasten Windows + R und gebe ein: shell:startup

Wenn gew�nscht, kann man den Bot auch als Windows Dienst einrichten. Das erm�glicht es,
dass der Bot im Hintergrund ausgef�hrt wird, ohne das ein Benutzer an Windows angemeldet ist.

Um ein Windows Dienst mit Apache procrun zu erstellen, habe ich ein kleines Skript vorbereitet.
Im Unterordner tools befindet sich das Skript InstallWindowsService.cmd.
Wenn gew�nscht, kann in diesem Skript der Pfad zu der Konfig- oder Logdatei oder der Name vom Dienst ge�ndert werden.
Aber es sollte auch ohne irgendeine �nderung funktionieren, der Standard-Dienstname ist JTS3ServerMod.
Starte einfach das Skript mit Administrator Rechten (Rechtklick darauf und "Als Administrator ausf�hren" w�hlen).
Wichtig: Verwende nur die InstallWindowsService.cmd wenn die 32 Bit Version der Java Laufzeitumgebung installiert ist oder
nur die InstallWindowsService_amd64.cmd wenn die 64 Bit Version der Java Laufzeitumgebung installiert ist.
Wenn die falsche Datei verwendet wurde, wird der JTS3ServerMod Dienst nicht starten. Wenn das passiert, entferne den
Dienst einfach mit der RemoveWindowsService.cmd oder RemoveWindowsService _amd64.cmd und installiere die richtige Version.

Der letzte Schritt ist das Starten des Dienstes, wie vom Skript am Ende beschrieben.

Wichtig:
Der Dienst ben�tigt absolute Pfade zu allen Konfigdateien. Allerdings sendet mein Skript den aktuellen Pfad zum JTS3ServerMod.
Dies erm�glicht es die Variable %apphome% im Pfad in allen Konfigdateien zu verwenden.
Ist dieser Pfad nicht verf�gbar (vielleicht weil der JTS3ServerMod nicht als Dienst gestartet wurde),
wird %apphome% mit einer leeren Zeichenkette ersetzt.


-= JTS3ServerMod aktualisieren =-
Hin und wieder sollte einmal auf meiner Homepage kontrolliert werden, ob eine neue Version vom JTS3ServerMod zur Verf�gung steht.
Es kann in der Konfigurationsdatei config/JTS3ServerMod_InstanceManager.cfg der bot_update_check aktiviert werden,
damit der JTS3ServerMod alle Clients auf der bot_fulladmin_list �ber eine neue Version informiert, sobald diese den TS3 Server betreten.

In den meisten F�llen muss lediglich die Datei JTS3ServerMod.jar ersetzt werden, w�hrend der JTS3ServerMod Prozess gestoppt ist.
Zus�tzlich solle man noch einen Blick in die Datei config/JTS3ServerMod_InstanceManager.cfg werden, ob hier neue Werte vorhanden sind,
die in die eigene Konfigurationsdatei r�ber kopiert werden k�nnen. Allerdigns sind die �nderungen in der Konfigurationsdatei
in den meisten F�llen optional und nicht zwingend erforderlich.

Ich empfehle den JTS3ServerMod anschlie�end mit dem Argument -updateconfig zu starten,
nachdem man die JTS3ServerMod.jar Datei ersetzt hat. Das wird alle Bot Konfigurationsdateien aktualisieren.
Der vollst�ndige Befehl: java -jar JTS3ServerMod.jar -updateconfig
Hinweis: Das -updateconfig l�scht auch alle Zeilen von entfernten und umbenannten Funktionen in dieser Konfigurationsdatei!


-= Wie finde ich die Channel ID / Eindeutige Client ID / Client Datenbank ID / Server Gruppen ID / Channel Gruppen ID =-
Der einfachste Weg an die Channel ID, Eindeutige Client ID und der Client Datenbank ID zu kommen,
ist die Installation von dem sehr sch�nen erweiterten Info Template von dante696:
http://forum.teamspeak.com/threads/73296-Release-Extended-Client-Info

Wenn man es nicht installieren m�chte, l�sst sich auch mithilfe des Bots eine Channel ID herausfinden.
Dazu den Bot starten und den Chat Befehl !getchannelid <teil des Channel Namens> verwenden, um die Channel ID zu erhalten.
Als Beispiel: !getchannelid away
Wenn der Standard Wert -1 bei bot_channel_id nicht ge�ndert wird, muss man beim ersten Bot Start keine Channel ID wissen!
Bitte sicherstellen, das man sich als Bot Admin oder Full Admin eingetragen hat, sonst kann der Befehl nicht benutzt werden.

Um die Eindeutige Client ID von einem Client zu kopieren, �ffne einfach das Rechte Fenster im TS3 Client und
suche nach dem ben�tigten Client innerhalb der Servergruppen. Anschlie�end klicke mit der rechte Maustaste auf den Namen und
w�hle den Kontextmen�eintrag Eindeutige ID in die Zwischenablage kopieren. Nun kann es woanders wieder eingef�gt werden.
Auf kleineren TS3 Servern kann auch der Men�punkt Rechte -> Alle Clients anzeigen benutzt werden,
auch hier kann dies mit der rechte Maustaste kopiert werden.
Aber bei mehr als 100 Clients auf dem TS3 Server nicht wirklich sinnvoll.

Die Server Gruppen ID und Channel Gruppen ID wird im Rechte Fenster angezeigt,
nachdem man im TS3 Client auf den folgenden Men�punkt klickt:
Rechte -> Server Gruppen
Rechte -> Channel Gruppen
Direkt neben dem Gruppennamen wird die ID der Gruppe angezeigt. Nat�rlich muss man dabei mit dem Server verbunden sein.

Ein kleines Problem ist die Client Datenbank ID, weil von TS System fast alle M�glichkeiten entfernt worden sind,
sich diese ID im TS3 Client anzeigen zu lassen. Derzeit ist der einzige Weg die Verwendung von dem erweiterten Info Template.
Aber seit dem JTS3ServerMod 5.3 kann auch die Eindeutige Client ID f�r die Chat Befehle verwendet werden.
Der Bot erkennt automatisch, wenn eine Eindeutige Client ID verwendet worden ist und
fragt die Client Datenbank ID vom TS3 Server ab.


-= Welche Query Login Zugangsdaten verwende ich f�r den Bot =-
Wenn der TS3 Server selbst betrieben wird, ist der einfachste Weg die serveradmin Logindaten vom TS3 Server zu verwenden.
Dies hat bereits nahezu alle ben�tigten Rechte und man hat au�erdem auch kein Problem mit der Identit�t vom Bot.

Wenn der TS3 Server nicht selbst betrieben wird oder man nicht das serveradmin Konto verwenden m�chte,
kann auch ein neues Query Konto mit dem TS3 Client erstellt werden,
daf�r wird nur das folgende Recht ben�tigt: b_client_create_modify_serverquery_login
Aber zuerst sollte eine neue TS3 Identit�t f�r den Bot erstellt werden. Wenn man das nicht macht,
verwendet der Bot die eigene TS3 Identit�t, was alle TS3 Clients verwirrt.

Um eine neue Identit�t zu erstellen, klicke auf Einstellungen -> Identit�ten -> Hinzuf�gen
Gebe einen Namen f�r die Identit�t ein, irgendwas wie TS3 Bot oder JTS3ServerMod.
Kopiere die Eindeutige ID und schlie�e das Fenster. Nun stelle eine Verbindung mit dem TS3 Server mit
der neuen Identit�t her. Wenn die Identit�t Auswahl nicht sichtbar ist, klicke im Verbinden Fenster auf Mehr.
Nachdem dies gemacht wurde, gehe wieder als Server Admin auf den TS3 Server, wenn nicht bereits geschehen,
und �ffne das Rechte -> Server Gruppen Fenster. W�hle die Server Gruppe, die vom Bot verwendet werden soll,
zum Beispiel die Server Admin Gruppe, und f�ge die neue Identit�t zu dieser Gruppe hinzu,
indem auf Hinzuf�gen geklickt wird und die Eindeutige ID rein kopiert wird. Es sollte sichergestellt werden,
das diese Server Gruppe alle ben�tigten Rechte hat, siehe dazu den Punkt "Ben�tigte Rechte f�r den Bot"
in dieser Readme Datei. Jetzt wieder mit der neuen Identit�t verbinden, wenn nicht mehr verbunden.
Falls man mehrmals mit dem TS3 Server verbunden ist, bitte sicherstellen,
das jetzt der richtige Reiter mit der neuen Identit�t aktiv ist!
Anschlie�end im TS3 Client auf Extras -> ServerQuery Login klicken und einen Loginnamen eingeben,
den man gerne haben m�chte. Schreibe sowohl den gew�hlten Loginnamen,
als auch das vom TS3 Client vergebene Passwort auf. Dies kann jetzt f�r den Bot verwendet werden.
Au�erdem sollte diese neue Identit�t nicht mehr mit dem normalen TS3 Client verwendet werden.
Behalte aber die Identit�t gespeichert, da dar�ber das Query Login Passwort ge�ndert werden kann,
falls dies irgendwann mal notwendig ist.


-= Ben�tigte Rechte f�r den Bot =-
Wenn der serveradmin Query Account verwendet wird, sind bereits alle Rechte gesetzt.
Selbst erstellte Query Accounts k�nnten weitere Rechte ben�tigen, selbst wenn diese in der Server Admin Gruppe sind.

Stelle sicher das der Query Account vom Bot �ber folgende Rechte verf�gt (in Klammern steht immer, wof�r das Recht ben�tigt wird):
- b_channel_delete_flag_force (Bad Channel Name Check)
- b_channel_delete_permanent (Bad Channel Name Check)
- b_channel_delete_semi_permanent (Bad Channel Name Check)
- b_channel_delete_temporary (Bad Channel Name Check)
- b_channel_join_ignore_password (Erlaube das Betreten aller Channel)
- b_channel_join_permanent (Erlaube das Betreten aller Channel)
- b_channel_join_semi_permanent (Erlaube das Betreten aller Channel)
- b_channel_join_temporary (Erlaube das Betreten aller Channel)
- b_channel_modify_name (Bad Channel Name Check)
- b_client_channel_textmessage_send (Advertising)
- b_client_delete_dbproperties (Inactive Clients Cleaner)
- b_client_ignore_sticky (Falls mit Sticky Gruppen gearbeitet wird)
- b_client_info_view (Immer ben�tigt)
- b_client_remoteaddress_view (F�r die Anzeige der IP Adresse)
- b_client_server_textmessage_send (Advertising)
- b_group_is_permanent (Der Bot bleibt Mitglied dieser Gruppe nach dem Neuverbinden)
- b_virtualserver_channel_list (Immer ben�tigt)
- b_virtualserver_channelgroup_client_list (Chat Befehl !removechannelgroups)
- b_virtualserver_client_dbinfo (Einige Chat Befehle)
- b_virtualserver_client_dblist (Immer ben�tigt)
- b_virtualserver_client_dbsearch (Einige Chat Befehle)
- b_virtualserver_client_list (Immer ben�tigt)
- b_virtualserver_info_view (Immer ben�tigt)
- b_virtualserver_notify_register (Immer ben�tigt)
- b_virtualserver_notify_unregister (Immer ben�tigt)
- b_virtualserver_servergroup_list (Immer ben�tigt)
- i_channel_join_power (Erlaube das Betreten aller Channel)
- i_channel_modify_power (Bad Channel Name Check)
- i_channel_subscribe_power (Um Clients in Channels sehen zu k�nnen)
- i_client_complain_power (Mehrere Funktionen, wenn der "Beschwerdeeintrag" aktiviert wurde)
- i_client_kick_from_channel_power (Bad Channel Name Check)
- i_client_kick_from_server_power (Mehrere Funktionen)
- i_client_move_power (Mehrere Funktionen)
- i_client_permission_modify_power (Server Group Protection)
- i_client_poke_power (Mehrere Funktionen, wenn "poke" als Benachrichtigungstyp verwendet wird)
- i_client_private_textmessage_power (Immer ben�tigt)
- i_group_member_add_power (Server Group Protection und Idle Check)
- i_group_member_remove_power (Server Group Protection und Idle Check)

Die "Guest Server Query" Gruppe ben�tigt au�erdem:
- b_serverquery_login (Zum Verbinden)
- b_virtualserver_select (Zum Verbinden)

Zus�tzliche optionale Rechte, vergebe es entweder an den Query Account vom Bot oder an die "Guest Server Query" Gruppe.
Wenn es an die "Guest Server Query" Gruppe vergeben wird, gilt es f�r alle virtuellen TS3 Server:
- b_serverinstance_permission_list (Anzeige der fehlenden Rechte Namen in der Log)


-= Sichtbarkeit vom Bot im Teamspeak =-
Im Normalfall ist der Bot unsichtbar auf dem Teamspeak 3 Server, weil es nur ein Telnet Client und
kein echter Teamspeak 3 Client ist. Mit den Standard Rechten ist es einfach den Bot f�r
Teamspeak 3 Server Administratoren sichtbar zu machen.
Dazu �ffne einfach im Teamspeak 3 Client die Favoriten -> Favoriten verwalten -> w�hle den entsprechenden Server aus
und klicke, falls nicht bereits geschehen, auf Mehr. Hier aktiviere die Einstellung "ServerQuery Clients anzeigen".
Nun sollte der Bot im Teamspeak 3 Client sichtbar sein. Falls nicht, pr�fe die Rechte,
wie im n�chsten Absatz beschrieben.

Wenn es auch anderen Server Gruppen erlaubt sein soll den Bot zu sehen, f�ge einfach das Recht
i_client_serverquery_view_power zu dieser Gruppe hinzu.
Verwende einen h�heren Wert als die i_client_needed_serverquery_view_power vom Bot.
Jeder Client muss nat�rlich ebenfalls die Einstellung in den Teamspeak 3 Client Einstellungen t�tigen.


-= Verschiedene Mitteilungsarten =-
Es k�nnen verschiedene Mitteilungsarten f�r die meisten Funktionen beim Bot ausgew�hlt werden,
pr�fe daf�r die Standard JTS3ServerMod_server.cfg Datei.
Derzeit sind die Werte chat und poke g�ltig, bei einigen Funktionen ebenfalls none um die Mitteilung zu deaktivieren.
Basierend auf den Teamspeak 3 Server gibt es maximal L�ngen f�r diese Mitteilungen,
es k�nnen lediglich 100 Zeichen f�r poke Mitteilungen verwendet werden,
einschlie�lich Leerzeichen und BBCode. Chat Mitteilungen haben ein viel h�heres Limit von 1023 Zeichen,
ebenfalls einschlie�lich Leerzeichen und BBCode. Diese Grenzen sollten unbedingt beachtet werden,
ansonsten kann der Bot keine Mitteilungen verschicken und man wird eine Fehlermeldung in der Logdatei vom Bot vorfinden.

Wenn eine Nachricht als Kickgrund verschickt wird, so darf der Kickgrund nicht mehr als 80 Zeichen beinhalten.


-= Globale Variablen f�r Texte =-
Wenn dies in der Bot Konfiguration aktiviert ist, k�nnen folgende globale Variablen f�r alle Texte verwendet werden:
%SERVER_NAME% - Server Name
%SERVER_PLATFORM% - Server Betriebssystem (Windows, Linux, ...)
%SERVER_VERSION% - Server Version
%SERVER_CREATED_DATE% - Server Erstellungsdatum
%SERVER_UPTIME% - Server Uptime in Tagen, Stunden, ...
%SERVER_UPTIME_DATE% - Server Uptime als Datum
%SERVER_UPLOAD_QUOTA% - Server Upload Quota
%SERVER_DOWNLOAD_QUOTA% - Server Download Quota
%SERVER_MONTH_BYTES_UPLOADED% - Menge hochgeladender Daten im aktuellen Monat (Dateitransfer und Avatar)
%SERVER_MONTH_BYTES_DOWNLOADED% - Menge heruntergeladender Daten im aktuellen Monat (Dateitransfer und Avatar)
%SERVER_TOTAL_BYTES_UPLOADED% - Menge hochgeladender Daten insgesamt (Dateitransfer und Avatar)
%SERVER_TOTAL_BYTES_DOWNLOADED% - Menge heruntergeladender Daten insgesamt (Dateitransfer und Avatar)
%SERVER_MAX_CLIENTS% - Maximale Clients (Slots)
%SERVER_RESERVED_SLOTS% - Reservierte Slots
%SERVER_CHANNEL_COUNT% - Aktuelle Channel Anzahl
%SERVER_CLIENT_COUNT% - Aktuelle Client Anzahl
%SERVER_CLIENT_DB_COUNT% - Vollst�ndige Client Anzahl in der TS3 Datenbank
%SERVER_CLIENT_CONNECTIONS_COUNT% - Server Client Verbindungen Anzahl
Die meisten Server Informationen werden nicht sofort aktualisiert, dies geschieht alle 60 Sekunden.
Wenn diese Variablen nicht ben�tigt werden, sollten diese in der Bot Konfiguration abgeschaltet werden,
um die daf�r ben�tigte Leistung einzusparen!


-= Benutzung auf dem Teamspeak Server / Chat Befehle =-
Auf dem Teamspeak 3 Server k�nnen Bot Befehle im Chat verwendet werden.
Es kann der Server-, Kanal- oder Privatchat verwendet werden. Nat�rlich muss man f�r den Kanalchat im selben Kanal sein.
Es sind zu viele Befehle um diese hier alle aufzulisten. Schreibe einfach !bothelp in den Server-, Kanal- oder Privatchat.
Dies gibt eine Liste aller Befehle aus. Um zu pr�fen ob der Bot l�uft, kann auch einfach !botinfo eingegeben werden.
Au�erdem befindet sich eine Liste aller Befehle in documents/ChatCommandHelp_deutsch.html

Derzeit sind drei verschiedene Bot Admins m�glich.
Die "Full Admins" werden in der Datei JTS3ServerMod_InstanceManager.cfg bei bot_fulladmin_list eingestellt,
normale und eingeschr�nkte Bot Admins werden in jeder virtuellen Bot Instanz Konfigurationsdatei von jedem Server
bei bot_admin_list und bot_lightadmingroup_list eingestellt.
"Full Admins" k�nnen alle Bot Befehle bei jeder virtuellen Bot Instanz verwenden, nur Personen denen man vertraut hinzuf�gen!
Normale Bot Admins sind auf die eigene virtuelle Bot Instanz limitiert und k�nnen folgende Befehle gar nicht verwenden:
!exec, !execwait, !botquit, !botinstancelist, !botinstancestart, !botinstancestop
Zus�tzlich k�nnen eingeschr�nkte Bot Admins die Bot Befehle wie !botreload, !botcfgset oder !botcfgget nicht verwenden.


-= Log Datei =-
Dieses Programm erstellt eine Log Datei mit dem Dateinamen JTS3ServerMod_InstanceManager.log.
Die Log Datei des InstanceManager enth�lt Informationen und Fehler bez�glich des Starten und Stoppen von virtuellen Bot Instanzen.

Jede virtuelle Bot Instanz erstellt ebenfalls eine eigene Log Datei, dies kann in der JTS3ServerMod_InstanceManager.cfg
f�r jede virtuelle Bot Instanz eingestellt werden. Voreinstellung f�r die erste virtuelle Bot Instanz ist der Name JTS3ServerMod_server1.log.
Die Log Datei von der virtuellen Bot Instanz protokolliert alle Aktionen auf dem Teamspeak Server und
nat�rlich auch alle Fehler die dabei auftreten k�nnen.


-= Wird Hilfe ben�tigt? =-
Nat�rlich kann man mir eine E-Mail schreiben und das Problem so genau wie m�glich beschreiben (was passiert wann?).
Aber bitte f�ge der E-Mail die Konfig und Log Dateien vom Bot als Anhang hinzu.

Wenn mehr Informationen ben�tigt werden, wie der Bot korrekt eingerichtet werden kann, lese bitte unbedingt diese Datei vollst�ndig.
F�r weitere Informationen zu den Konfig Dateien lese bitte auch die Datei documents/ConfigHelp_deutsch.html


-= Danke =-
Ein Danke f�r das Einsenden von Fehlermeldungen und Vorschl�gen, und das Testen neuer Funktionen geht an:
- 130ng0
- ADM24
- Adam M.
- Ahmet I.
- Andr� A. / Kartoffel-Stampfer
- Atranox / End-Gaming.eu
- BEN89
- Baggavy J.
- Benjamin B.
- Benjamin L.
- BoKo / WebShell
- Bralosch
- ChoosenEye
- Chris / Orange Bots
- Christoph
- Christopher / Lenzen Networks
- Corba
- DaRkBoZ
- Daniel L.
- DarRoe
- DarkGhost
- David K.
- Denden / TSforYOU
- Dr.No
- DunklerKeks / Dark Empire Clan
- EidEchse
- FRAGGYNZ
- Fabrice
- Felix R.
- Flavio
- Flofus
- FoXFTW
- Frank B.
- Fusionpot
- GWR
- Gamle / MainGaming.dk
- Giftzwerg
- Guus W.
- Heiko
- Hermann W.
- Hinken
- HoschY1987
- Invictus International / TS Server HQ
- IronMC
- Jay / Clanwarz
- Jeremy P.
- Johannes1509
- KingHunt / Gamers Platoon
- Kirbyfan1223
- Lore
- MajorThorn
- Mariuszeq
- Marko M.
- Mateusz Z.
- Megamaluco
- Micha5
- Mikolaj
- MrChicken
- NaTesTa10
- NanooTec
- Nate4ever
- Nobody_cbm / Software Galaxy
- Pascal / Fierlord-Hosting
- Patschi
- Philip H. / squaX
- Pierre N. / Futuregamers.eu
- Prototype
- Raiden4918 / Subculture-Gaming
- Robert M.
- Robin B. / TS3-4You
- Rowtag
- Sandro M. / TS Voice
- Saucenteufel
- Sebastian S.
- SkullDrago
- Slater
- Speddyroot
- St3v3
- Stefan R.
- Surf3rDud3
- TS-Coach
- Taishou / NLFS B�ndnis
- TeaTow
- Thomas / Science System
- ThomasHH / thl-online
- TotoIsBack
- Tukaa
- WaterFlow
- Yanek
- barricas
- cigaming
- dukio
- eggster
- elpoepel
- kadama / Oxivoice
- livedisco
- mastermax
- mathewitp / Old Dragons
- mthomas
- sojakfa
- thecrew
- tigerle
- whvler
- xeomueller / xgs.in
- xoun
Liste in Alphabetischer Reihenfolge.