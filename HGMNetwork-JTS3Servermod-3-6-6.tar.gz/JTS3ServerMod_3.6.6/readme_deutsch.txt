JTS3ServerMod
Author: Stefan Martens

E-Mail:
info@stefan1200.de

Homepage:
http://www.stefan1200.de


-= Copyright =-
Dieses Programm darf kostenlos verwendet werden, aber bitte informiere mich, wenn ein Fehler gefunden worden ist.
Der Autor von diesem Programm ist nicht verantwortlich f�r jede Art von Sch�den oder Datenverlust!
Es ist nicht erlaubt dieses Programm zu verkaufen, es muss frei erh�ltlich sein!
Es ist ebenfalls nicht erlaubt den Quellcode zu verwenden und mit dem eigenen Namen zu ver�ffentlichen!
Bitte frage mich zuerst um Erlaubnis wenn was ver�ffentlicht werden soll, das Teile von meinem Quellcode enth�lt!

Teamspeak 3 wird entwickelt von TeamSpeak Systems GmbH, Verkauf und Lizensierungen durch Triton CI & Associates, Inc.
Weitere Informationen zu Teamspeak 3: http://www.teamspeak.com


-= Informationen =-
Dieses Programm erweitert den Teamspeak 3 Server um einige weitere Funktionen. Hier die Liste:
- Server Gruppen k�nnen vor unerlaubten Clients besch�tzt werden.
- Client Namen k�nnen nach unerlaubten W�rtern oder Zeichen untersucht und ggf. gekickt werden.
- Channel Namen k�nnen nach unerlaubten W�rtern oder Zeichen untersucht und ggf. gel�scht werden.
- Unt�tige (Idle) Clients in einen bestimmten Raum bewegen oder vom Server werfen. In beiden F�llen bekommt dieser eine Nachricht.
- Verschickt eine Warnnachricht an unt�tige (Idle) Clients.
- Aufnehmende Clients in einen Raum bewegen oder vom Server werfen. In beiden F�llen bekommt dieser eine Nachricht.
- Nach kurzer Zeit k�nnen Clients mit aktivierten Abwesendheitsstatus (Away) in einen Raum bewegt werden.
  Das zur�ck bewegen, wenn der Client nicht mehr abwesend ist, ist einschaltbar.
- Nach kurzer Zeit k�nnen Clients mit stumm geschalteten Kopfh�hrern oder Mikrofon in einen Raum bewegt werden.
  Das zur�ck bewegen, wenn der Client nicht mehr stumm geschaltet ist, ist einschaltbar.
- Kann in Intervallen eine Textnachricht an den Server oder bestimmten Raum Chat senden.
- Jeder Client der sich mit dem Server verbindet, kann eine Willkommensnachricht bekommen.
  Auch spezielle Willkommensnachrichten f�r bestimmte Server Gruppen m�glich.
- !lastseen Chat Befehl um auszugeben, wann jemand zuletzt auf dem Teamspeak Server war.
Alles kann ausf�hrlich eingestellt oder abgeschaltet werden.

Weitere Funktionen sind:
- Viele Bot Instanzen f�r verschiedene Teamspeak 3 Server in einem Bot Prozess sind nutzbar.
- Automatisches Neuverbinden wenn die Verbindung zum Teamspeak 3 Server verloren geht.
- Viele Chat Befehle erm�glichen das �ndern der Einstellungen, das Neuladen der Einstellungen oder um den Bot zu beenden.
- Langsamer Modus um die Nutzung des Bots (mit eingeschr�nkten Funktionen) auch ohne �nderung der query_ip_whitelist.txt zu erm�glichen.


-= Systemanforderungen =-
Dieses Programm l�uft unter Windows und Linux (auch ohne X Server). Auf Mac OS X 10.4+ sollte es ebenfalls laufen, allerdings ungetestet.
Alles was ben�tigt wird ist die Java SE Laufzeitumgebung Version 5 oder neuer.
Die neuste Version ist auf www.java.com oder http://www.oracle.com/technetwork/java/javase/downloads/index.html zu bekommen.
Anwender von Mac OS X 10.4 oder neuer haben es wohlm�glich bereits installiert.
Linux Anwender sollten das Paket sun-java6-jre oder openjdk-6-jre
(auf �lteren Linux Versionen funktioniert auch sun-java5-jre) installieren.
Ein Beispiel f�r Debian oder Ubuntu Linux: apt-get install sun-java6-jre
Ein Beispiel f�r CentOS oder Fedora: yum install java-1.6.0-openjdk
Ein Beispiel f�r OpenSUSE: yast -i java-1_6_0-sun
Das Paket gcj-jre (GNU Java) wird nicht funktionieren!

Vielleicht soll der maximale Arbeitsspeicher, den der Bot benutzen soll, begrenzt werden.
Das kann auf einem virtuellen Server n�tzlich sein.
Dies kann mit einem Java Befehlszeilen Argument f�r die Java Virtuelle Machine erledigt werden.
Wenn zum Beispiel nur 30 MB Arbeitsspeicher maximal verwendet werden soll, starte den Bot mit folgendem Argument:
java -mx30M -jar JTS3ServerMod.jar
Hinweis: Wenn ein zu niedriger Wert gew�hlt wird, l�uft der Bot nicht oder nicht stabil.
Ich habe hierzu keine Langzeittests durchgef�hrt. Der Bot ben�tigt weniger Arbeitsspeicher,
wenn der Client Datenbank Cache deaktiviert wird und nur eine Bot Instanz verwendet wird.

Teamspeak 3 Server beta 19 oder neuer wird ben�tigt, aber empfohlen ist mindestens beta 28.
Nat�rlich wird auch eine Verbindung zum Teamspeak 3 Server ben�tigt.

Hinweis:
Die IP Adresse von diesem Programm sollte in die Datei query_ip_whitelist.txt des Teamspeak 3 Servers hinzugef�gt werden.
Dabei muss beachtet werden, das die query_ip_whitelist.txt eine Leerzeile am Ende der Datei ben�tigt.
Wenn der Bot auf dem selben Computer wie der TS3 Server l�uft, verwende 127.0.0.1 als TS3 Server Adresse beim Bot.
Diese ist in der Regel bereits freigeschaltet. Falls dies nicht beachtet wird, wird die Anti Spam Funktion
des Teamspeak 3 Server das Programm sehr oft f�r einige Minuten bannen. Falls ein Bearbeiten der query_ip_whitelist.txt
nicht m�glich ist, versuche in der Bot Server Konfigurationsdatei den bot_slowmode auf 1 zu setzen.
Dies verlangsamt den Bot beim Verbinden und schaltet einige Funktionen ab.


-= Allgemeine Informationen zur Installation und Benutzung =-
Einfach diese ZIP Datei komplett entpacken, behalte die Verzeichnisse so bei, wie diese in der ZIP Datei vorgegeben sind.
Es ist nicht n�tig den Bot in das selbe Verzeichnis zu legen, wie den Teamspeak 3 Server,
der Bot ist ein eigenst�ndiges Programm, welches einfach eine Verbindung zum Teamspeak 3 Server Telnet Query Port herstellt.

Standardm��ig gibt es zwei Hauptkonfigurationsdateien, JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_server1.cfg.
Die JTS3ServerMod_InstanceManager.cfg enth�lt alle Informationen �ber virtuelle Bot Instanzen die gestartet werden sollen.
Die JTS3ServerMod_server1.cfg enth�lt alle Bot Einstellungen einer virtuellen Instanz.

Beide Konfigurationsdateien sollten nach eigenem Wunsch ge�ndert werden. Alles ist direkt in den Dateien erkl�rt.
Auf jedenfall sollte beachtet werden das beide Dateien im ANSI Format (Kodierung ISO-8859-1) gespeichert werden.
Wichtig: Alle anderen Konfigurationsdateien (wie die advertising, record, idle und welcome Texte)
werden standardm��ig im Unicode (UTF-8 ohne BOM) Format gespeichert. Dies kann in der Hauptkonfigurationsdatei ge�ndert werden.

Hinweis: Es befindet sich eine deutsche �bersetzung der Konfigurationsdateien im "documents" Ordner.

Dies ist ein Kommandozeilen Programm, es ben�tigt also eine Shell um Informationen anzuzeigen.
Nat�rlich funktioniert es auch ohne aktives Shell Fenster, alle Informationen werden auch in die Log Datei geschrieben.

Unter Windows kann die cmd.exe oder die mitgelieferten EXE Dateien benutzt werden.
Linux Anwender k�nnen dieses Programm auch ohne X-Server verwenden, es wird keine GUI ge�ffnet.
Wird ein X-Server verwendet, sollte dieses Programm in der Terminal / Shell gestartet werden.
Mac OS X Anwender sollten ebenfalls die Terminal verwenden.

Wenn sich die JTS3ServerMod.jar und der config Ordner (welche die Datei JTS3ServerMod_InstanceManager.cfg enth�lt)
im selben Verzeichnis befinden, kann die Server Modifikation einfach durch folgende Eingabe gestartet werden:
java -jar JTS3ServerMod.jar

Sollen sich die Dateien JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_InstanceManager.log an einem anderen Ort befinden
oder einen anderen Dateinamen haben, dann kann das Argument -config und -log verwendet werden, hier ein Beispiel:
java -jar JTS3ServerMod.jar -config cfg/instance.cfg -log log/instance.log

Ein anderes Argument ist -help, welches lediglich eine Liste der Kommandozeilenargumente ausgibt und sich dann beendet.


-= Bot einrichten (alle Betriebssysteme) =-
Als Erstes sollte gepr�ft werden, ob Java bereits installiert ist.
Dies kann auf der Konsole / Terminal / Eingabeaufforderung mit folgenden Befehl gemacht werden:
java -version
Daraufhin sollte eine Ausgabe der installierten Java Version erscheinen.
Ist dies nicht der Fall, so muss Java noch erst installiert werden.
Weitere Informationen hierzu gibt es in dem Bereich "Systemanforderungen" dieser Anleitung.

Als Zweites muss die ZIP Datei, in der diese Datei zu finden war, vollst�ndig entpackt werden.
Es ist nicht n�tig den Bot in das selbe Verzeichnis zu legen, wie den Teamspeak 3 Server,
der Bot ist ein eigenst�ndiges Programm, welches einfach eine Verbindung zum Teamspeak 3 Server Telnet Query Port herstellt.
In dem Ordner config befinden sich alle Konfigdateien, welche nach den eigenen W�nschen angepasst werden m�ssen.

Hinweis: Es befindet sich eine deutsche �bersetzung der Konfigurationsdateien im "documents" Ordner.

Wichtige Einstellungen in der Konfigdatei JTS3ServerMod_server1.cfg,
diese m�ssen korrekt angegeben werden, um die Funktion vom Bot zu gew�hrleisten:
ts3_server_address
ts3_server_query_port
ts3_server_query_login
ts3_server_query_password
ts3_virtualserver_id / ts3_virtualserver_port
bot_slowmode

Standardm��ig sind alle Funktionen in der Konfigdatei abgeschaltet.
Diese m�ssen dann nach eigenen W�nschen aktiviert werden.
Aber geht mit folgenden Funktionen vorsichtig um, denn bei falschen Einstellungen k�nnen diese gro�e Probleme bereiten:
bad nickname check
bad channel name check
server group protection

Damit der Bot eine oder mehrere Personen als Admin erkennt, eines der beiden Einstellungen setzen:
Bot Full Admin (alle Admin Befehle): JTS3ServerMod_InstanceManager.cfg -> bot_fulladmin_list
Bot Admin (nur die Admin Befehle der virtuellen Bot Instanz): JTS3ServerMod_server1.cfg -> bot_admin_list

Damit sind die Grundeinstellungen gemacht. Alle Dateien speichern, dabei sollte beachtet werden
das die Dateien JTS3ServerMod_InstanceManager.cfg und JTS3ServerMod_server1.cfg im ANSI Format (Kodierung ISO-8859-1)
gespeichert werden m�ssen. Alle anderen Konfigurationsdateien (wie die advertising, record, idle und welcome Texte)
werden standardm��ig im Unicode (UTF-8 ohne BOM) Format gespeichert.
Dies kann jedoch in der Datei JTS3ServerMod_server1.cfg -> bot_messages_encoding ge�ndert werden.

Zum Starten des Bots das entsprechende folgende Kapitel lesen:
Bot unter Linux starten
Bot unter Windows starten


-= Bot unter Linux starten =-
Eine L�sung ist die Verwendung von screen. Das Installieren von screen ist einfach (wenn nicht bereits vorhanden):
Auf Debian oder Ubuntu:
apt-get install screen
Auf CentOS oder Fedora:
yum install screen
Auf OpenSUSE:
yast -i screen

Nach dem man das gemacht hat, mit cd in den JTS3ServerMod Ordner wechseln und starte folgenden Befehl:
screen -d -m -S ts3bot java -jar JTS3ServerMod.jar
Nun wird der Bot in einem speziellen Shell Screen mit dem Namen ts3bot ausgef�hrt.

Um den Shell Screen mit dem Namen ts3bot zu �ffnen, um vielleicht die Ausgabe vom Bot zu lesen,
einfach folgenden Befehl ausf�hren:
screen -r ts3bot

Um einen ge�ffneten Shell Screen zu schliessen ohne den Bot zu beenden, einfach folgende Tastenkombination dr�cken:
STRG + A + D

Falls es hierbei zu Problemen kommt, in dieser Anleitung unter dem Punkt "Systemanforderungen"
ist beschrieben, wie man den ben�tigten Arbeitsspeicher einschr�nken kann.
Dies ist besonders auf Linux VServern interessant.
Das dort beschriebene Beispiel f�r den Start des Bots mit dem screen Befehl geht dann so:
screen -d -m -S ts3bot java -mx30M -jar JTS3ServerMod.jar


-= Bot unter Windows starten =-
Zum Einen kann der Bot unter Windows nat�rlich als normales Programm gestartet werden.
Dazu einfach die JTS3ServerMod-Windows_NoWindow.exe mit einem Doppelklick starten.
Alle Ausgaben sind dann in der Log Datei, welche vom Bot erstellt wird, nachzulesen.

Wenn gew�nscht, kann man den Bot auch als Windows Dienst einrichten. Dies ist dann etwas komplizierter.
Dazu, wenn noch nicht vorhanden, die Windows Server 2003 Resource Kit Tools herunterladen:
http://www.microsoft.com/downloads/en/details.aspx?FamilyID=9d467a69-57ff-4ae7-96ee-b18c4790cffd&displaylang=en
Auf neueren Windows Versionen wird eventuell eine Warnung eingeblendet,
aber auf meinem Windows 7 System funktionierte es dennoch einwandfrei.
Die Windows Server 2003 Resource Kit Tools installieren.

F�r den folgenden Vorgang habe ich bereits ein Skript vorbereitet, was alles weitere erledigt.
Im Unterordner tools befindet sich das Skript InstallWindowsService.cmd, dieses Skript
muss allerdings noch angepasst werden. Dazu muss das Skript mit einem Texteditor ge�ffnet werden.
Die Pfade bei ResourceKitPath und JTS3ServerModPath m�ssen angepasst werden um mit der eigenen Installation �bereinzustimmen.
Nach dem Speichern dieser �nderungen kann das Skript mit Administrator Rechten gestartet werden.

Der letzte Schritt ist das Starten des Dienstes, wie vom Skript am Ende beschrieben.

Wichtig:
Der Dienst kann zwar den Bot starten, allerdings nicht wieder beenden.
Dies kann dann entweder per Chat Befehl an den Bot erfolgen, oder mit dem Task Manager.


-= Benutzung auf dem Teamspeak Server =-
Seit der Version 1.0 ist es m�glich einige Bot Befehle im Chat auf dem Teamspeak 3 Server zu verwenden.
Es kann der Server-, Kanal- oder Privatchat verwendet werden. Nat�rlich muss man f�r den Kanalchat im selben Kanal sein.
Es sind zu viele Befehle um diese hier alle aufzulisten. Schreibe einfach !bothelp in den Server-, Kanal- oder Privatchat.
Dies gibt eine Liste aller Befehle aus. Um zu pr�fen ob der Bot l�uft, kann auch einfach !botinfo eingegeben werden.
Um Bot Admin zu sein, muss die Einzigartige ID vom Client in der Bot Konfigurationsdatei angegeben werden.

Seit der Bot Version 3.1 sind zwei verschiedene Bot Admins m�glich.
Die "Full Admins" werden in der Datei JTS3ServerMod_InstanceManager.cfg eingestellt,
normale Bot Admins werden in jeder Bot Instanz Konfigurationsdatei bei jedem Server eingestellt.
"Full Admins" k�nnen alle Bot Befehle bei jeder Bot Instanz verwenden.
Normale Bot Admins sind auf die eigene Bot Instanz limitiert und k�nnen folgende Befehle gar nicht verwenden:
!exec, !execwait, !botquit, !botinstancelist, !botinstancestart, !botinstancestop


-= Ben�tigte Rechte f�r den Bot =-
Stelle sicher das der Bot �ber folgende Rechte verf�gt (in Klammern steht immer, wof�r das Recht ben�tigt wird):
b_virtualserver_channel_list (Immer ben�tigt)
b_virtualserver_client_list (Immer ben�tigt)
b_virtualserver_client_dblist (Client Datenbank Cache)
b_virtualserver_notify_register (Immer ben�tigt)
b_virtualserver_servergroup_list (Server Gruppen Benachrichtigung & Server Gruppen Schutz)
b_serverinstance_permission_list (Anzeige der fehlenden Rechte Namen in der Log)
b_channel_delete_permanent (Ung�ltige Channelnamen �berpr�fung)
b_channel_delete_semi_permanent (Ung�ltige Channelnamen �berpr�fung)
b_channel_delete_temporary (Ung�ltige Channelnamen �berpr�fung)
b_channel_delete_flag_force (Ung�ltige Channelnamen �berpr�fung)
b_channel_join_permanent (Erlaube das betreten aller Channel)
b_channel_join_semi_permanent (Erlaube das betreten aller Channel)
b_channel_join_temporary (Erlaube das betreten aller Channel)
b_channel_join_ignore_password (Erlaube das betreten aller Channel)
i_channel_join_power (Erlaube das betreten aller Channel)
i_group_member_remove_power (Server Gruppen Schutz)
i_group_member_add_power (Server Gruppen Schutz)
b_group_is_permanent (Der Bot bleibt Mitglied dieser Gruppe nach dem Neuverbinden)
i_client_modify_power (Server Gruppen Schutz)
i_client_kick_from_channel_power (Ung�ltige Channelnamen �berpr�fung)
i_client_kick_from_server_power (Mehrere Funktionen)
i_client_move_power (Mehrere Funktionen)
i_client_complain_power (Mehrere Funktionen, wenn der "Beschwerdeeintrag" aktiviert wurde)
i_client_poke_power (Mehrere Funktionen wenn "poke" als Benachrichtigungstyp verwendet wird)
i_client_private_textmessage_power (Immer ben�tigt)
b_client_channel_textmessage_send (Werbenachrichten)
b_client_server_textmessage_send (Werbenachrichten)
b_client_info_view (Willkommensnachricht)
b_virtualserver_select (Zum Verbinden)

Eventuell ben�tigt f�r zuk�nftige Versionen:
b_virtualserver_info_view

Die "Guest Server Query" Gruppe ben�tigt au�erdem:
b_serverquery_login (Zum Verbinden)


-= Sichtbarkeit vom Bot im Teamspeak =-
Im Normalfall ist der Bot unsichtbar auf dem Teamspeak 3 Server, weil es nur ein Telnet Client und
kein echter Teamspeak 3 Client ist. Mit den Standard Rechten ist es einfach den Bot f�r
Teamspeak 3 Server Administratoren sichtbar zu machen.
Dazu �ffne einfach im Teamspeak 3 Client die Favoriten -> Favoriten verwalten -> w�hle den entsprechenden Server aus
und klicke, falls nicht bereits geschehen, auf Mehr. Hier aktiviere die Einstellung "ServerQuery Clients anzeigen".
Nun sollte der Bot im Teamspeak 3 Client sichtbar sein. Falls nicht, pr�fe die Rechte,
wie im n�chsten Absatz beschrieben.

Wenn es auch anderen Server Gruppen erlaubt sein soll den Bot zu sehen, f�ge einfach das Recht
i_client_serverquery_view_power zu dieser Gruppe hinzu.
Verwende einen h�heren Wert als die i_client_needed_serverquery_view_power vom Bot.
Jeder Client muss nat�rlich ebenfalls die Einstellung in den Teamspeak 3 Client Einstellungen t�tigen.


-= Verschiedene Mitteilungsarten =-
Es k�nnen verschiedene Mitteilungsarten f�r die meisten Funktionen beim Bot ausgew�hlt werden,
pr�fe daf�r die Standard JTS3ServerMod_server1.cfg Datei.
Derzeit sind die Werte chat und poke g�ltig, bei einigen Funktionen ebenfalls none um die Mitteilung zu deaktivieren.
Basierend auf den Teamspeak 3 Server gibt es maximal L�ngen f�r diese Mitteilungen,
es k�nnen lediglich 100 Zeichen f�r poke Mitteilungen verwendet werden,
einschlie�lich Leerzeichen und BBCode. Chat Mitteilungen haben ein viel h�heres Limit von 1023 Zeichen,
ebenfalls einschlie�lich Leerzeichen und BBCode. Diese Grenzen sollten unbedingt beachtet werden,
ansonsten kann der Bot keine Mitteilungen verschicken und man wird eine Fehlermeldung in der Logdatei vom Bot vorfinden.

Wenn eine Nachricht als Kickgrund verschickt wird, so darf der Kickgrund nicht mehr als 80 Zeichen beinhalten.


-= Log Datei =-
Dieses Programm erstellt eine Log Datei mit dem Dateinamen JTS3ServerMod_InstanceManager.log.
Die Log Datei des InstanceManager enth�lt Informationen und Fehler bez�glich des Starten und Stoppen von Bot Instanzen.

Jede Bot Instanz erstellt ebenfalls eine eigene Log Datei, dies kann in der JTS3ServerMod_InstanceManager.cfg
f�r jede Bot Instanz eingestellt werden. Die Log Datei von der Bot Instanz protokolliert alle Aktionen
auf dem Teamspeak Server und nat�rlich auch alle Fehler die dabei auftreten k�nnen.


-= Danke =-
Ein Danke f�r das Einsenden von Fehlermeldungen und Vorschl�gen, und das Testen neuer Funktionen geht an:
- Benjamin
- BoKo / WebShell
- Corba
- Chris / Orange Bots
- Christoph
- DaRkBoZ
- DarRoe
- EidEchse
- Flavio
- Heiko
- HoschY1987
- KingHunt / Gamers Platoon
- MajorThorn
- mastermax
- Megamaluco
- Nate4ever
- Slater
- sojakfa
- St3v3
- Thomas / Science System
- tigerle
- TotoIsBack
Liste in Alphabetischer Reihenfolge.