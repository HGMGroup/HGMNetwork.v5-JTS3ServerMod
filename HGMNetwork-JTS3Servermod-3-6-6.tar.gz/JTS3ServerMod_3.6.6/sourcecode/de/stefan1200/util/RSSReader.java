package de.stefan1200.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

public class RSSReader
{
	private String sFeedURL = null;
	private String feedEncoding = null;
	private String lastURL = "";
	private Vector<String> itemTitle = new Vector<String>();
	private Vector<String> itemURL = new Vector<String>();
	
	private Timer feedTimer = null;
	private TimerTask timerCheck = null;
	
	public int getItemCount()
	{
		return itemTitle.size();
	}
	
	public String getItemTitle(int index)
	{
		return itemTitle.elementAt(index);
	}
	
	public String getItemURL(int index)
	{
		return itemURL.elementAt(index);
	}
	
	public void clearItemCache()
	{
		itemTitle.clear();
		itemURL.clear();
	}
	
	public void initFeed(String feedURL)
	{
		initFeed(feedURL, 5);
	}
	
	public void initFeed(String feedURL, int checkInterval)
	{
		sFeedURL = feedURL;
		
		feedTimer = new Timer();
		timerCheck = new TimerTask()
		{
			public void run()
			{
				readFeed();
			}
		};
		feedTimer.schedule(timerCheck, checkInterval*60*1000, checkInterval*60*1000);
		
		readFeed();
	}
	
	public void resetFeed()
	{
		timerCheck.cancel();
		feedTimer.cancel();
		timerCheck = null;
		feedTimer = null;
		sFeedURL = null;
		feedEncoding = null;
		lastURL = "";
		clearItemCache();
	}
	
	private boolean readFeed()
	{
		try
		{
			String tmp;
			if (feedEncoding == null)
			{
				URL feedUrl = new URL(sFeedURL);
				BufferedReader feedStream = new BufferedReader(new InputStreamReader(feedUrl.openStream()));
				
				String encoding = "UTF-8";
				int pos = 0;
				int pos2 = 0;
				while ((tmp = feedStream.readLine()) != null)
				{
					pos = tmp.indexOf(" encoding=");
					if (pos == -1) continue;
					else pos = pos + 11;
					
					pos2 = tmp.indexOf("?>", pos);
					if (pos == -1) break;
					else pos2 = pos2 - 1;
					
					encoding = tmp.substring(pos, pos2).trim();
				}
				
				feedStream.close();
				feedEncoding = encoding;
			}
			
			StringBuffer sb = new StringBuffer();
			URL feedUrl = new URL(sFeedURL);
			BufferedReader feedStream = new BufferedReader(new InputStreamReader(feedUrl.openStream(), feedEncoding));
			
			while ((tmp = feedStream.readLine()) != null)
			{
				sb.append(tmp);
			}
			
			feedStream.close();
			
			parseFeedItems(sb.toString());
			
			return true;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	
	private void parseFeedItems(String feed)
	{
		feed = feed.replace("&amp;", "&");
		feed = feed.replace("<![CDATA[", "");
		feed = feed.replace("]]>", "");
		String[] feedItems = feed.split("<item(>| .*?>)");
		
		boolean skipFirst = true;
		boolean saveLastURL = true;
		boolean addMode = (itemURL.size() == 0 ? true : false);
		int pos = 0;
		int pos2 = 0;
		int vecPos = -1;
		String tmpTitle = "";
		String tmpURL = "";
		for (String item : feedItems)
		{
			if (skipFirst)
			{
				skipFirst = false;
				continue;
			}
			
			pos = item.indexOf("<link>");
			pos2 = item.indexOf("</link>", pos);
			
			if (pos != -1 && pos2 != -1)
			{
				tmpURL = item.substring(pos + 6, pos2).trim();
				
				if (lastURL.equals(tmpURL))
				{
					break;
				}
				
				if (saveLastURL)
				{
					lastURL = tmpURL;
					saveLastURL = false;
				}
			}
			else
			{
				tmpURL = "";
			}
			
			pos = item.indexOf("<title>");
			pos2 = item.indexOf("</title>", pos);
			
			if (pos != -1 && pos2 != -1)
			{
				tmpTitle = item.substring(pos + 7, pos2).trim();
			}
			else
			{
				tmpTitle = "";
			}
			
			if (addMode)
			{
				itemURL.addElement(tmpURL);
				itemTitle.addElement(tmpTitle);
			}
			else
			{
				itemURL.insertElementAt(tmpURL, ++vecPos);
				itemTitle.insertElementAt(tmpTitle, ++vecPos);
			}
		}
	}
}
