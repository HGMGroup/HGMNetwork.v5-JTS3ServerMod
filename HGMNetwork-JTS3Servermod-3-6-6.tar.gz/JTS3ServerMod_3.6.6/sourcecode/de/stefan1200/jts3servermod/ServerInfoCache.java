package de.stefan1200.jts3servermod;

import java.util.HashMap;
import java.util.Vector;

public class ServerInfoCache
{
	private String serverName = null;
	private String serverVersion = null;
	private String serverPlatform = null;
	private long serverUptimeSince = -1;
	private long serverCreatedAt = -1;
	private long serverDownloadQuota = -1;
	private long serverUploadQuota = -1;
	private long serverMonthBytesDownloaded = -1;
	private long serverMonthBytesUploaded = -1;
	private long serverTotalBytesDownloaded = -1;
	private long serverTotalBytesUploaded = -1;
	private long serverClientConnectionsCount = -1;
	private int serverMaxClients = -1;
	private int serverReservedSlots = -1;
	private int serverChannelCount = -1;
	private int serverClientCount = -1;
	
	void updateServerInfo(HashMap<String,String> serverinfo)
	{
		if (serverinfo == null)
		{
			return;
		}
		
		serverName = serverinfo.get("virtualserver_name");
		if (serverVersion == null) serverVersion = serverinfo.get("virtualserver_version");
		if (serverPlatform == null) serverPlatform = serverinfo.get("virtualserver_platform");
		
		try
		{
			if (serverUptimeSince == -1) serverUptimeSince = System.currentTimeMillis() - (Long.parseLong(serverinfo.get("virtualserver_uptime")) * 1000);
			if (serverCreatedAt == -1) serverCreatedAt = Long.parseLong(serverinfo.get("virtualserver_created")) * 1000;
			
			serverMaxClients = Integer.parseInt(serverinfo.get("virtualserver_maxclients"));
			serverReservedSlots = Integer.parseInt(serverinfo.get("virtualserver_reserved_slots"));
			serverChannelCount = Integer.parseInt(serverinfo.get("virtualserver_channelsonline"));
			serverClientCount = Integer.parseInt(serverinfo.get("virtualserver_clientsonline")) - Integer.parseInt(serverinfo.get("virtualserver_queryclientsonline"));
			serverClientConnectionsCount = Long.parseLong(serverinfo.get("virtualserver_client_connections"));
			
			serverMonthBytesDownloaded = Long.parseLong(serverinfo.get("virtualserver_month_bytes_downloaded"));
			serverMonthBytesUploaded = Long.parseLong(serverinfo.get("virtualserver_month_bytes_uploaded"));
			serverTotalBytesDownloaded = Long.parseLong(serverinfo.get("virtualserver_total_bytes_downloaded"));
			serverTotalBytesUploaded = Long.parseLong(serverinfo.get("virtualserver_total_bytes_uploaded"));
			serverDownloadQuota = Long.parseLong(serverinfo.get("virtualserver_download_quota"));
			serverUploadQuota = Long.parseLong(serverinfo.get("virtualserver_upload_quota"));
		}
		catch (Exception e)
		{
		}
	}
	
	void updateClientCount(Vector<HashMap<String, String>> clientList)
	{
		int clientCountTemp = 0;
		for (HashMap<String, String> clientInfo : clientList)
		{
			if (clientInfo.get("client_type").equals("0"))
			{
				++clientCountTemp;
			}
		}
		serverClientCount = clientCountTemp;
	}
	
	String getServerName()
	{
		return serverName;
	}
	String getServerVersion()
	{
		return serverVersion;
	}
	String getServerPlatform()
	{
		return serverPlatform;
	}
	long getServerUptime()
	{
		return System.currentTimeMillis() - serverUptimeSince;
	}
	long getServerUptimeTimestamp()
	{
		return serverUptimeSince;
	}
	long getServerCreatedAt()
	{
		return serverCreatedAt;
	}
	long getServerDownloadQuota()
	{
		return serverDownloadQuota;
	}
	long getServerUploadQuota()
	{
		return serverUploadQuota;
	}
	long getServerMonthBytesDownloaded()
	{
		return serverMonthBytesDownloaded;
	}
	long getServerMonthBytesUploaded()
	{
		return serverMonthBytesUploaded;
	}
	long getServerTotalBytesDownloaded()
	{
		return serverTotalBytesDownloaded;
	}
	long getServerTotalBytesUploaded()
	{
		return serverTotalBytesUploaded;
	}
	int getServerMaxClients()
	{
		return serverMaxClients;
	}
	int getServerReservedSlots()
	{
		return serverReservedSlots;
	}
	int getServerChannelCount()
	{
		return serverChannelCount;
	}
	int getServerClientCount()
	{
		return serverClientCount;
	}
	long getServerClientConnectionsCount()
	{
		return serverClientConnectionsCount;
	}
}
