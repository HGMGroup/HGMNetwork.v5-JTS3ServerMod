package de.stefan1200.jts3servermod;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.URL;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.BitSet;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.stefan1200.jts3serverquery.JTS3ServerQuery;
import de.stefan1200.jts3serverquery.TeamspeakActionListener;
import de.stefan1200.util.ArrangedPropertiesWriter;

public class JTS3ServerMod implements TeamspeakActionListener
{
	final static int LIST_AWAY = 0;
	final static int LIST_GROUPS = 1;
	final static int LIST_INFO = 2;
	final static int LIST_TIMES = 3;
	final static int LIST_UID = 4;
	final static int LIST_VOICE = 5;
	final static int LIST_COUNTRY = 6;
	final static String[] LIST_OPTIONS = {"-away", "-groups", "-info", "-times", "-uid", "-voice", "-country"};
	
	public static String DEFAULT_CONFIG_FILE_NAME = "server_bot.cfg";
	public static final String VERSION = "3.6.6 Final (06.04.2013)";
	public static final String VERSIONCHECK_URL = "http://www.stefan1200.de/versioncheck/JTS3ServerMod.version";
	private int reloadState = 2;
	private int reconnectTime = 65000;
	private String CONFIG_FILE_NAME = "server_bot.cfg";
	
	private String TS3_ADDRESS;
	private int TS3_QUERY_PORT = 10011;
	private String TS3_LOGIN;
	private String TS3_PASSWORD;
	private int TS3_VIRTUALSERVER_ID;
	private int TS3_VIRTUALSERVER_PORT;
	private int BOT_CHANNEL_ID;

	private boolean SLOW_MODE = false;
	private int CHECK_INTERVAL;
	private String MESSAGE_ENCODING;
	private String SERVER_QUERY_NAME;
	private String SERVER_QUERY_NAME_2;
	private boolean RECONNECT_FOREVER;
	private boolean CLIENT_DATABASE_CACHE = false;
	private boolean COMMAND_EXEC_ENABLED = false;
	private boolean COMMAND_LASTSEEN_PUBLIC = false;
	private Vector<String> FULL_ADMIN_UID_LIST = new Vector<String>();
	private Vector<String> ADMIN_UID_LIST = new Vector<String>();
	
	private int RECORD_CHECK_ENABLE;
	private String RECORD_FILE;
	private boolean RECORD_COMPLAINADD;
	private String RECORD_MESSAGE_MODE;
	private String RECORD_MESSAGE;
	private Vector<Integer> RECORD_CHANNEL_LIST = new Vector<Integer>();
	private boolean RECORD_CHANNEL_LIST_IGNORE = true;
	private Vector<Integer> RECORD_GROUP_LIST = new Vector<Integer>();
	private boolean RECORD_GROUP_LIST_IGNORE = true;
	private int RECORD_MOVE_CHANNELID = -1;
	
	private int IDLE_CHECK_ENABLE;
	private String IDLE_FILE;
	private Vector<Integer> IDLE_CHANNEL_LIST = new Vector<Integer>();
	private boolean IDLE_CHANNEL_LIST_IGNORE = true;
	private Vector<Integer> IDLE_GROUP_LIST = new Vector<Integer>();
	private boolean IDLE_GROUP_LIST_IGNORE = true;
	private int IDLE_MOVE_CHANNELID;
	private String IDLE_MESSAGE_MODE;
	private String IDLE_MESSAGE;
	private String IDLE_SECOND_MESSAGE;
	private long IDLE_MAX_TIME = -1;
	private long IDLE_SECOND_MAX_TIME = -1;
	private String IDLE_WARN_MESSAGE_MODE;
	private String IDLE_WARN_MESSAGE;
	private long IDLE_WARN_TIME = -1;
	private int IDLE_MIN_CLIENTS = 0;
	private Vector<Integer> IDLE_CLIENTS_WARN_SENT = new Vector<Integer>();
	private Vector<Integer> idleClientsWarnSentTemp = new Vector<Integer>();
	private boolean IDLE_MOVE_BACK = false;
	private Vector<Integer> IDLE_CLIENTS_MOVED = new Vector<Integer>();
	private Vector<Integer> IDLE_CLIENTS_MOVED_CHANNEL = new Vector<Integer>();
	
	private int AWAY_CHECK_ENABLE;
	private Vector<Integer> AWAY_CHANNEL_LIST = new Vector<Integer>();
	private boolean AWAY_CHANNEL_LIST_IGNORE = true;
	private int AWAY_MOVE_CHANNELID;
	private int AWAY_MOVE_DELAY;
	private Vector<Integer> AWAY_CLIENTS_MOVED = new Vector<Integer>();
	private Vector<Integer> AWAY_CLIENTS_MOVED_CHANNEL = new Vector<Integer>();
	private Vector<Integer> AWAY_GROUP_LIST = new Vector<Integer>();
	private boolean AWAY_GROUP_LIST_IGNORE = true;
	private String AWAY_MESSAGE_MODE;
	private String AWAY_MESSAGE;
	private String AWAY_FILE;
	
	private int MUTE_CHECK_ENABLE;
	private Vector<Integer> MUTE_CHANNEL_LIST = new Vector<Integer>();
	private boolean MUTE_CHANNEL_LIST_IGNORE = true;
	private int MUTE_MOVE_CHANNELID;
	private int MUTE_MOVE_DELAY;
	private boolean MUTE_MOVE_MICROPHONE;
	private boolean MUTE_MOVE_HEADPHONE;
	private boolean MUTE_MOVE_MICROPHONE_HARDWARE;
	private boolean MUTE_MOVE_HEADPHONE_HARDWARE;
	private Vector<Integer> MUTE_CLIENTS_MOVED = new Vector<Integer>();
	private Vector<Integer> MUTE_CLIENTS_MOVED_CHANNEL = new Vector<Integer>();
	private Vector<Integer> MUTE_GROUP_LIST = new Vector<Integer>();
	private boolean MUTE_GROUP_LIST_IGNORE = true;
	private String MUTE_MESSAGE_MODE;
	private String MUTE_MESSAGE;
	private String MUTE_FILE;
	
	private int AUTOMOVE_ENABLE;
	private HashMap<Integer, Integer> AUTOMOVE_SGCHANNEL_LIST = new HashMap<Integer, Integer>();
	private String AUTOMOVE_MESSAGE_MODE;
	private String AUTOMOVE_MESSAGE;
	private String AUTOMOVE_FILE;
	
	private int ADVERTISING_ENABLE;
	private int ADVERTISING_CHANNELID = -1;
	private int ADVERTISING_INTERVAL = -1;
	private String ADVERTISING_FILE;
	private Vector<String> ADVERTISING_MESSAGES = new Vector<String>();
	
	private int WELCOMEMESSAGE_ENABLE;
	private String WELCOMEMESSAGE_FILE;
	private Vector<Integer> WELCOMEMESSAGE_GROUPS = new Vector<Integer>();
	private String WELCOMEMESSAGE_MESSAGE_MODE;
	private String WELCOMEMESSAGE_MESSAGE;
	private int WELCOMEMESSAGE_DEFAULT_ENABLE;
	private String WELCOMEMESSAGE_DEFAULT_MESSAGE_MODE;
	private String WELCOMEMESSAGE_DEFAULT_MESSAGE;
	
	private int BADNICKNAME_CHECK_ENABLE;
	private String BADNICKNAME_FILE;
	private boolean BADNICKNAME_COMPLAINADD;
	private Vector<Integer> BADNICKNAME_GROUP_LIST = new Vector<Integer>();
	private boolean BADNICKNAME_GROUP_LIST_IGNORE = true;
	private String BADNICKNAME_KICK_MESSAGE;
	private Vector<Pattern> BADNICKNAME_RULES = new Vector<Pattern>();
	
	private int BADCHANNELNAME_CHECK_ENABLE;
	private Vector<Integer> BADCHANNELNAME_CHANNEL_LIST = new Vector<Integer>();
	private String BADCHANNELNAME_FILE;
	private Vector<Pattern> BADCHANNELNAME_RULES = new Vector<Pattern>();
	
	private int SERVERGROUPPROTECTION_ENABLE;
	private String SERVERGROUPPROTECTION_FILE;
	private String SERVERGROUPPROTECTION_MESSAGE_MODE;
	private String SERVERGROUPPROTECTION_MESSAGE;
	private boolean SERVERGROUPPROTECTION_ADD_MISSING_GROUPS;
	private boolean SERVERGROUPPROTECTION_KICK;
	private boolean SERVERGROUPPROTECTION_COMPLAINADD;
	private Vector<Integer> SERVERGROUPPROTECTION_GROUPS = new Vector<Integer>();
	private Vector<Vector<String>> SERVERGROUPPROTECTION_CLIENTS = new Vector<Vector<String>>();
	
	private int SERVERGROUPNOTIFY_ENABLE;
	private Vector<Integer> SERVERGROUPNOTIFY_GROUPS = new Vector<Integer>();
	private Vector<Integer> SERVERGROUPNOTIFY_GROUPTARGETS = new Vector<Integer>();
	private String SERVERGROUPNOTIFY_MESSAGE_MODE;
	private String SERVERGROUPNOTIFY_FILE;
	private String SERVERGROUPNOTIFY_MESSAGE;
	private Vector<Integer> SERVERGROUPNOTIFY_CHANNEL_LIST = new Vector<Integer>();
	private boolean SERVERGROUPNOTIFY_CHANNEL_LIST_IGNORE = true;
	
	private String IDLE_CHANNEL_NAME = null;
	private String RECORD_CHANNEL_NAME = null;
	private String ADVERTISING_CHANNEL_NAME = null;
	private String AWAY_CHANNEL_NAME = null;
	private String MUTE_CHANNEL_NAME = null;
	private int DEFAULT_CHANNEL_ID = -1;
	private String lastNumberValueAtConfigLoad = null;
	private boolean updateServerInfoCache = false;
	private boolean updateServerGroupListCache = false;
	private boolean advertiseNow = false;
	private short currentAdvertiseMessage = 0;
	private boolean DEBUG = false;
	private boolean configCheckMode = false;
	private SimpleDateFormat sdf;
	private SimpleDateFormat sdfDebug = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private long startTime = 0;
	private String instanceName;
	private String listArguments = null;
	private Vector<HashMap<String, String>> permissionListCache = null;
	private Vector<HashMap<String, String>> serverGroupListCache = null;
	private Vector<HashMap<String, String>> clientList = null;
	
	private ArrangedPropertiesWriter config = new ArrangedPropertiesWriter();
	private JTS3ServerQuery queryLib;
	private InstanceManager manager;
	private ClientDatabaseCache clientCache = null;
	private ServerInfoCache serverInfoCache = null;
	private ChatCommands chatCommands = null;
	private PrintStream logFile = null;
	private Timer botTimer;
	private TimerTask timerCheck;
	private TimerTask timerAdvertising;
	private TimerTask timerReconnect;
	private TimerTask timerServerInfoCache;
	private TimerTask timerServerGroupListCache;
	private BitSet listOptions = new BitSet(10);
	
	public JTS3ServerMod(String configFile)
	{
		initVars();
		this.CONFIG_FILE_NAME = configFile;
		this.configCheckMode = true;
		initConfig();
	}
	
	public JTS3ServerMod(ArrangedPropertiesWriter apw)
	{
		initVars();
		config = apw;
		this.configCheckMode = true;
	}
	
	public JTS3ServerMod(InstanceManager manager, String instanceName, String configFile, String logFilePath, boolean debug, Vector<String> fulladminList, boolean commandExec)
	{
		this.DEBUG = debug;
		this.configCheckMode = false;
		this.CONFIG_FILE_NAME = configFile;
		this.manager = manager;
		this.instanceName = instanceName;
		this.FULL_ADMIN_UID_LIST = fulladminList;
		this.COMMAND_EXEC_ENABLED = commandExec;
		
		if (logFilePath != null)
		{
			try
			{
				logFile = new PrintStream(new FileOutputStream(logFilePath, true), true, "UTF-8");
			}
			catch (Exception e)
			{
				logFile = null;
			}
		}
		
		initConfig();
		queryLib = new JTS3ServerQuery(instanceName);
	}
	
	static void showHelp()
	{
		System.out.println("JTS3ServerMod " + VERSION);
		System.out.println("-help\t\tShows this help message");
		System.out.println("-version\tShows installed and latest version of JTS3ServerMod");
		System.out.println("-config <path>\tSet a different config file for the instance manager, default " + InstanceManager.DEFAULT_CONFIG_FILE_PATH);
		System.out.println("-log <path>\tSet a different path for the instance manager logfile, default " + InstanceManager.DEFAULT_LOG_FILE_PATH);
	}

	public static void main(String[] args)
	{
		String configFilePath = null;
		String logFilePath = null;
		if (args != null && args.length > 0)
		{
			for (int i=0; i<args.length; i++)
			{
				if (args[i].equalsIgnoreCase("-config") || args[i].equalsIgnoreCase("/config") || args[i].equalsIgnoreCase("--config"))
				{
					if (args.length > (i+1))
					{
						configFilePath = args[i+1];
						++i;
					}
				}
				else if (args[i].equalsIgnoreCase("-log") || args[i].equalsIgnoreCase("/log") || args[i].equalsIgnoreCase("--log"))
				{
					if (args.length > (i+1))
					{
						logFilePath = args[i+1];
						++i;
					}
				}
				else if (args[i].equalsIgnoreCase("-help") || args[i].equalsIgnoreCase("/help") || args[i].equalsIgnoreCase("--help"))
				{
					showHelp();
					System.exit(0);
				}
				else if (args[i].equalsIgnoreCase("-version") || args[i].equalsIgnoreCase("/version") || args[i].equalsIgnoreCase("--version"))
				{
					showVersionCheck();
					System.exit(0);
				}
				else if (args[i].equalsIgnoreCase("-versioncheck") || args[i].equalsIgnoreCase("/versioncheck") || args[i].equalsIgnoreCase("--versioncheck"))
				{
					showVersionCheck();
					System.exit(0);
				}
			}
		}
		
		new InstanceManager(configFilePath, logFilePath);
	}
	
	static void showVersionCheck()
	{
		System.out.println("JTS3ServerMod");
		System.out.println("Current installed version:");
		System.out.println(JTS3ServerMod.VERSION);
		
		HashMap<String, String> versionData = JTS3ServerMod.getVersionCheckData();
		if (versionData != null)
		{
			if (versionData.get("final.version") != null)
			{
				System.out.println("Latest final version:");
				System.out.println(versionData.get("final.version"));
			}
			
			if (versionData.get("dev.version") != null)
			{
				System.out.println("Latest development version:");
				System.out.println(versionData.get("dev.version"));
			}
		}
	}
	
	static HashMap<String, String> getVersionCheckData()
	{
		HashMap<String, String> versionData = new HashMap<String, String>();
		
		try
		{
			URL versionCheckUrl = new URL(JTS3ServerMod.VERSIONCHECK_URL);
			BufferedReader versionCheckStream = new BufferedReader(new InputStreamReader(versionCheckUrl.openStream()));
			
			StringTokenizer st;
			String tmp;
			String modeLine;
			while ((tmp = versionCheckStream.readLine()) != null)
			{
				st = new StringTokenizer(tmp, ";", false);
				modeLine = st.nextToken();
				if (modeLine.equalsIgnoreCase("final"))
				{
					versionData.put("final.version", st.nextToken());
					versionData.put("final.url", st.nextToken());
				}
				
				if (modeLine.equalsIgnoreCase("development"))
				{
					versionData.put("dev.version", st.nextToken());
					versionData.put("dev.url", st.nextToken());
				}
			}
			
			versionCheckStream.close();
		}
		catch (Exception e)
		{
		}
		
		return versionData;
	}
	
	private String getPermissionName(int permissionID)
	{
		if (permissionListCache == null)
		{
			return null;
		}
		
		String sPermissionID = Integer.toString(permissionID);
		String retValue = null;
		for (HashMap<String, String> permission : permissionListCache)
		{
			if (permission.get("permid").equals(sPermissionID))
			{
				retValue = permission.get("permname");
				break;
			}
		}
		return retValue;
	}
	
	private void initConfig()
	{
		config.addKey("ts3_server_address", "Teamspeak 3 server address");
		config.addKey("ts3_server_query_port", "Teamspeak 3 server query port, default is 10011");
		config.addKey("ts3_server_query_login", "Teamspeak 3 server query admin account name");
		config.addKey("ts3_server_query_password", "Teamspeak 3 server query admin password");
		config.addKey("ts3_virtualserver_id", "Teamspeak 3 virtual server ID or -1 to use ts3_virtualserver_port");
		config.addKey("ts3_virtualserver_port", "Teamspeak 3 virtual server port, only needed if ts3_virtualserver_id is set to -1");
		config.addSeparator();
		config.addKey("bot_channel_id", "Channel id, the bot will join into it after connecting. If not wanted, use a negative number like -1.\nDon't set the default channel here, because the bot is already in the default channel after connecting.");
		config.addKey("bot_slowmode", "Activate the slow mode of the bot, 0 = disable, 1 = enable.\nIf slow mode is activated, the bot connects slower to the server\nand disables some bot features to reduce the amount of needed commands.\nThis feature may allow you to use the bot without whitelist the bot IP address.\nSlow mode disables the bad channel name check, welcome message, client database cache\nand do not allow the bot check interval to be lower than 3 seconds.");
		config.addKey("bot_check_interval", "Check every X seconds, default is 1. Values between 1 and 30 are allowed.\nIf slow mode is activated, 3 is the lowest possible value.");
		config.addKey("bot_messages_encoding", "A different encoding of the messages config files.\nDefault is UTF-8 which should be good for all EU and US languages.\nChange this only if you know what you are doing!\nFor english or german language you can also use the encoding ISO-8859-1\nA list of all valid ones: http://java.sun.com/j2se/1.5.0/docs/guide/intl/encoding.doc.html");
		config.addKey("bot_clientdblist_cache", "This enables the client database list cache. This cache is needed for commands like !lastseen. 1 = Enable, 0 = Disable");
		config.addKey("bot_server_query_name", "Server Query name, this will be displayed as name of the connection.");
		config.addKey("bot_server_query_name_2", "Second Server Query name, this will be displayed as name of the connection.\nThis name will be used, if the first name is already in use.");
		config.addKey("bot_date_pattern", "Change the date pattern, which will be used to format a date in chat functions and welcome message.\nTo get help how to make such a pattern, look here: http://java.sun.com/j2se/1.5.0/docs/api/java/text/SimpleDateFormat.html");
		config.addKey("bot_connect_forever", "Should the bot try to connect forever if the Teamspeak server or the bot is offline? 0 = disable, 1 = enable");
		config.addKey("bot_admin_list", "A comma seperated list (without spaces) of unique user ids, which should be able to use bot admin commands.\nThe unique user ids looks like this: mBbHRXwDAG7R19Rv3PorhMwbZW4=");
		config.addSeparator();
		config.addKey("command_lastseen", "Allow !lastseen command for all clients? 1 = Yes, 0 = No");
		config.addSeparator();
		config.addKey("record_check_enable", "Choose record check mode, 0 = disable, 1 = kick, 2 = move\nThis feature will move or kick a recording client (of course only the record function of the Teamspeak client is detected).");
		config.addKey("record_file", "Path to file which contains the record messages");
		config.addKey("record_move_channel_id", "If mode 2 selected, set channel id to move recording clients into it");
		config.addKey("record_channel_list", "A comma seperated list (without spaces) of channel ids.\nDepends on the given mode, this channels can be ignored or only this channels will be checked!");
		config.addKey("record_channel_list_mode", "Select one of the two modes for the channel list.\nignore = The selected channels will be ignored.\nonly = Only the selected channels will be checked.");
		config.addKey("record_group_list", "A comma seperated list (without spaces) of server group ids.\nDepends on the given mode, this server groups can be ignored or only this server groups will be checked!");
		config.addKey("record_group_list_mode", "Select one of the two modes for the server group list.\nignore = The selected server groups will be ignored.\nonly = Only the selected server groups will be checked.");
		config.addKey("record_add_complain", "Add complain entry to the user, 0 = No, 1 = Yes");
		config.addKey("record_message_mode", "Select the message mode, how the client should get the message (useless if kick is enabled).\npoke, chat or none are valid values!");
		config.addSeparator();
		config.addKey("idle_check_enable", "Enable idle check, 0 = disable, 1 = kick, 2 = move\nThis feature will move or kick an idle client.");
		config.addKey("idle_file", "Path to file which contains the idle messages");
		config.addKey("idle_move_back", "Move client back if not idle anymore, 0 = No, 1 = Yes");
		config.addKey("idle_move_channel_id", "If mode 2 selected, set channel id to move idle clients into it");
		config.addKey("idle_channel_list", "A comma seperated list (without spaces) of channel ids.\nDepends on the given mode, this channels can be ignored or only this channels will be checked!");
		config.addKey("idle_channel_list_mode", "Select one of the two modes for the channel list.\nignore = The selected channels will be ignored.\nonly = Only the selected channels will be checked.");
		config.addKey("idle_group_list", "A comma seperated list (without spaces) of server group ids.\nDepends on the given mode, this server groups can be ignored or only this server groups will be checked!");
		config.addKey("idle_group_list_mode", "Select one of the two modes for the server group list.\nignore = The selected server groups will be ignored.\nonly = Only the selected server groups will be checked.");
		config.addKey("idle_max_time", "Set the max idle time in minutes.\nIf mode 1 selected, the client will be kicked after being idle for this time.\nIf mode 2 selected, the client will be moved to idle_move_channel_id after being idle for this time!");
		config.addKey("idle_second_max_time", "If mode 2 selected, set the max idle time in minutes to kick someone.\nHas to be greater than idle_max_time or -1 to disable this feature!");
		config.addKey("idle_warn_time", "Set the idle warn time in minutes or set -1 to disable this feature.\nThe idle warn time has to be smaller than the max idle time");
		config.addKey("idle_min_clients", "A minimum client count to activate idle check (telnet and TS3 clients counted together).\nIf less clients online, idle check does nothing.");
		config.addKey("idle_message_mode", "Select the message mode, how the client should get the message (useless if kick is enabled).\npoke, chat or none are valid values!");
		config.addKey("idle_warn_message_mode", "Select the message mode, how the client should get the message.\npoke or chat are valid values!");
		config.addSeparator();
		config.addKey("away_check_enable", "Enable away mover, 0 = disable, 1 = enable, 2 = enable with move back\nThis feature will move the client as soon as away status is set for longer than X seconds, specified below.");
		config.addKey("away_move_channel_id", "Channel id to move away clients into it");
		config.addKey("away_move_delay", "Idle time in seconds after the client with away status will be moved to the channel.\nHas between 0 and 10000 seconds!");
		config.addKey("away_channel_list", "A comma seperated list (without spaces) of channel ids.\nDepends on the given mode, this channels can be ignored or only this channels will be checked!");
		config.addKey("away_channel_list_mode", "Select one of the two modes for the channel list.\nignore = The selected channels will be ignored.\nonly = Only the selected channels will be checked.");
		config.addKey("away_group_list", "A comma seperated list (without spaces) of server group ids.\nDepends on the given mode, this server groups can be ignored or only this server groups will be checked!");
		config.addKey("away_group_list_mode", "Select one of the two modes for the server group list.\nignore = The selected server groups will be ignored.\nonly = Only the selected server groups will be checked.");
		config.addKey("away_message_mode", "Select the message mode, how the client should get the message.\npoke, chat or none are valid values!");
		config.addKey("away_file", "Path to file which contains the away mover message");
		config.addSeparator();
		config.addKey("advertising_enable", "Enable advertising, 0 = disable, 1 = send to virtual server, 2 = send to channel");
		config.addKey("advertising_channel_id", "If mode 2 selected, set channel id to write advertising message into it");
		config.addKey("advertising_repeat_time", "Advertise every X minutes");
		config.addKey("advertising_file", "Path to file which contains the advertising messages.");
		config.addSeparator();
		config.addKey("default_welcomemessage_enable", "Enable default welcome message, 0 = disable, 1 = enable\nThis welcome message, if enabled, will be used for all other groups than specified for welcomemessage_groups.\nIf welcomemessage_enable is disabled, then this will be used for all clients in all groups.");
		config.addKey("default_welcomemessage_message_mode", "Select the message mode, how the client should get the message.\npoke or chat are valid values!");
		config.addKey("welcomemessage_enable", "You can set another welcome message for specified server groups.");
		config.addKey("welcomemessage_groups", "A comma seperated list (without spaces) of server group ids, which should get this welcome message.");
		config.addKey("welcomemessage_file", "Path to file which contains the welcome messages.");
		config.addKey("welcomemessage_message_mode", "Select the message mode, how the client should get the message.\npoke or chat are valid values!");
		config.addSeparator();
		config.addKey("badnickname_check_enable", "Enable bad nickname check, 0 = disable, 1 = enable\nThis feature will kick every client which match one of the bad nickname rules.");
		config.addKey("badnickname_add_complain", "Add complain entry to the user, 0 = No, 1 = Yes");
		config.addKey("badnickname_group_list", "A comma seperated list (without spaces) of server group ids.\nDepends on the given mode, this server groups can be ignored or only this server groups will be checked!");
		config.addKey("badnickname_group_list_mode", "Select one of the two modes for the server group list.\nignore = The selected server groups will be ignored.\nonly = Only the selected server groups will be checked.");
		config.addKey("badnickname_file", "Path to file which contains the bad nickname kick message and check rules.");
		config.addSeparator();
		config.addKey("badchannelname_check_enable", "Enable bad channel name check, 0 = disable, 1 = enable\nThis feature will force delete every channel which match one of the bad channel name rules.");
		config.addKey("badchannelname_channel_list", "A comma seperated list (without spaces) of channel ids.\nThis channels will be ignored!");
		config.addKey("badchannelname_file", "Path to file which contains the bad channel name check rules.");
		config.addSeparator();
		config.addKey("servergroupprotection_enable", "Enable server group protection, 0 = disable, 1 = enable\nIf enabled, this function will check all server groups from clients on the server, which are currently online.\nIf a client use a protected server group and is not on the list of the bot, it will be removed from the server group.");
		config.addKey("servergroupprotection_groups", "A comma seperated list (without spaces) of server group ids, which should be protected.");
		config.addKey("servergroupprotection_kick", "Enable this to kick every client which using a protected server group and are not on the list of the bot, 0 = disable, 1 = enable");
		config.addKey("servergroupprotection_add_complain", "Add complain entry to the user, 0 = No, 1 = Yes\nThis would only add a complaint, if the bot has to remove a server group.");
		config.addKey("servergroupprotection_add_missing_groups", "If a client is listed in the servergroupprotection_file and miss a server group, they get added to the server group.\n0 = disable, 1 = enable");
		config.addKey("servergroupprotection_message_mode", "Select the message mode, how the client should get the message (useless if kick is enabled).\npoke, chat or none are valid values!");
		config.addKey("servergroupprotection_file", "Path to file which contains the server group protection client list and kick message.");
		config.addSeparator();
		config.addKey("mute_check_enable", "Enable mute mover, 0 = disable, 1 = enable, 2 = enable with move back\nThis feature will move the client as soon as the specified mute status is set for longer than X seconds, specified below.");
		config.addKey("mute_move_headphone", "Enable move if headphone is muted, 0 = disable, 1 = enable");
		config.addKey("mute_move_microphone", "Enable move if microphone is muted, 0 = disable, 1 = enable");
		config.addKey("mute_move_headphone_hardware", "Enable move if headphone hardware is disabled, 0 = disable, 1 = enable");
		config.addKey("mute_move_microphone_hardware", "Enable move if microphone hardware is disabled, 0 = disable, 1 = enable\nThis also happen if someone is speaking in another TS3 client server tab.");
		config.addKey("mute_move_channel_id", "Channel id to move muted clients into it");
		config.addKey("mute_move_delay", "Idle time in seconds after the client with a specified mute status will be moved to the channel.\nHas between 0 and 10000 seconds!");
		config.addKey("mute_channel_list", "A comma seperated list (without spaces) of channel ids.\nDepends on the given mode, this channels can be ignored or only this channels will be checked!");
		config.addKey("mute_channel_list_mode", "Select one of the two modes for the channel list.\nignore = The selected channels will be ignored.\nonly = Only the selected channels will be checked.");
		config.addKey("mute_group_list", "A comma seperated list (without spaces) of server group ids.\nDepends on the given mode, this server groups can be ignored or only this server groups will be checked!");
		config.addKey("mute_group_list_mode", "Select one of the two modes for the server group list.\nignore = The selected server groups will be ignored.\nonly = Only the selected server groups will be checked.");
		config.addKey("mute_message_mode", "Select the message mode, how the client should get the message.\npoke, chat or none are valid values!");
		config.addKey("mute_file", "Path to file which contains the mute mover message");
		config.addSeparator();
		config.addKey("servergroupnotify_enable", "Enable server group notify, 0 = disable, 1 = enable\nIf enabled, this function will notify specified server groups about joining clients in a specified server group.");
		config.addKey("servergroupnotify_message_mode", "Select the message mode, how the clients should get the message (useless if kick is enabled).\npoke or chat are valid values!");
		config.addKey("servergroupnotify_groups", "A comma seperated list (without spaces) of server group ids, which should be watched on joining.");
		config.addKey("servergroupnotify_grouptargets", "A comma seperated list (without spaces) of server group ids, which should be notified about joining clients.");
		config.addKey("servergroupnotify_channel_list", "A comma seperated list (without spaces) of channel ids.\nDepends on the given mode, target clients in this channels can be ignored or only clients in this channels receive the notify message!");
		config.addKey("servergroupnotify_channel_list_mode", "Select one of the two modes for the channel list.\nignore = Clients in the selected channels will be ignored.\nonly = Only clients in the selected channels receive the notify message.");
		config.addKey("servergroupnotify_file", "Path to file which contains the server group notify message");
		config.addSeparator();
		config.addKey("automove_enable", "Enable auto move, 0 = disable, 1 = enable\nIf enabled, this function will move connecting clients of a specified server group to a specified channel. This function ignores clients with an own default channel set.");
		config.addKey("automove_message_mode", "Select the message mode, how the clients should get the message.\npoke, chat or none are valid values!");
		config.addKey("automove_file", "Path to file which contains the auto move configuration and message.");
	}
	
	private void initVars()
	{
		config.removeAllValues();
		TS3_ADDRESS = null;
		TS3_QUERY_PORT = 10011;
		TS3_LOGIN = null;
		TS3_PASSWORD = null;
		TS3_VIRTUALSERVER_ID = -1;
		TS3_VIRTUALSERVER_PORT = -1;
		BOT_CHANNEL_ID = -1;

		SLOW_MODE = false;
		CHECK_INTERVAL = 1;
		MESSAGE_ENCODING = "UTF-8";
		SERVER_QUERY_NAME = null;
		SERVER_QUERY_NAME_2 = null;
		RECONNECT_FOREVER = false;
		COMMAND_LASTSEEN_PUBLIC = false;
		ADMIN_UID_LIST = new Vector<String>();
			
		RECORD_CHECK_ENABLE = 0;
		RECORD_FILE = null;
		RECORD_COMPLAINADD = false;
		RECORD_MESSAGE_MODE = null;
		RECORD_MESSAGE = null;
		RECORD_CHANNEL_LIST = new Vector<Integer>();
		RECORD_CHANNEL_LIST_IGNORE = true;
		RECORD_GROUP_LIST = new Vector<Integer>();
		RECORD_GROUP_LIST_IGNORE = true;
		RECORD_MOVE_CHANNELID = -1;
			
		IDLE_CHECK_ENABLE = 0;
		IDLE_FILE = null;
		IDLE_CHANNEL_LIST = new Vector<Integer>();
		IDLE_CHANNEL_LIST_IGNORE = true;
		IDLE_GROUP_LIST = new Vector<Integer>();
		IDLE_GROUP_LIST_IGNORE = true;
		IDLE_MOVE_CHANNELID = -1;
		IDLE_MESSAGE_MODE = null;
		IDLE_MESSAGE = null;
		IDLE_SECOND_MESSAGE = null;
		IDLE_MAX_TIME = -1;
		IDLE_SECOND_MAX_TIME = -1;
		IDLE_WARN_MESSAGE_MODE = null;
		IDLE_WARN_MESSAGE = null;
		IDLE_WARN_TIME = -1;
		IDLE_MIN_CLIENTS = 0;
		IDLE_CLIENTS_WARN_SENT = new Vector<Integer>();
		idleClientsWarnSentTemp = new Vector<Integer>();
		IDLE_MOVE_BACK = false;
		IDLE_CLIENTS_MOVED = new Vector<Integer>();
		IDLE_CLIENTS_MOVED_CHANNEL = new Vector<Integer>();
			
		AWAY_CHECK_ENABLE = 0;
		AWAY_CHANNEL_LIST = new Vector<Integer>();
		AWAY_CHANNEL_LIST_IGNORE = true;
		AWAY_MOVE_CHANNELID = -1;
		AWAY_GROUP_LIST = new Vector<Integer>();
		AWAY_GROUP_LIST_IGNORE = true;
		AWAY_MESSAGE_MODE = null;
		AWAY_MESSAGE = null;
		AWAY_FILE = null;
		AWAY_CLIENTS_MOVED = new Vector<Integer>();
		AWAY_CLIENTS_MOVED_CHANNEL = new Vector<Integer>();
		
		MUTE_CHECK_ENABLE = 0;
		MUTE_CHANNEL_LIST = new Vector<Integer>();
		MUTE_CHANNEL_LIST_IGNORE = true;
		MUTE_MOVE_CHANNELID = -1;
		MUTE_GROUP_LIST = new Vector<Integer>();
		MUTE_GROUP_LIST_IGNORE = true;
		MUTE_MESSAGE_MODE = null;
		MUTE_MESSAGE = null;
		MUTE_FILE = null;
		MUTE_CLIENTS_MOVED = new Vector<Integer>();
		MUTE_CLIENTS_MOVED_CHANNEL = new Vector<Integer>();
			
		ADVERTISING_ENABLE = 0;
		ADVERTISING_CHANNELID = -1;
		ADVERTISING_FILE = null;
			
		WELCOMEMESSAGE_ENABLE = 0;
		WELCOMEMESSAGE_FILE = null;
		WELCOMEMESSAGE_GROUPS = new Vector<Integer>();
		WELCOMEMESSAGE_MESSAGE_MODE = null;
		WELCOMEMESSAGE_MESSAGE = null;
		WELCOMEMESSAGE_DEFAULT_ENABLE = 0;
		WELCOMEMESSAGE_DEFAULT_MESSAGE_MODE = null;
		WELCOMEMESSAGE_DEFAULT_MESSAGE = null;
		
		BADNICKNAME_COMPLAINADD = false;
		BADNICKNAME_GROUP_LIST = new Vector<Integer>();
		BADNICKNAME_GROUP_LIST_IGNORE = true;
		
		BADCHANNELNAME_CHANNEL_LIST = new Vector<Integer>();
		
		SERVERGROUPPROTECTION_MESSAGE_MODE = null;
		SERVERGROUPPROTECTION_ADD_MISSING_GROUPS = false;
		SERVERGROUPPROTECTION_KICK = false;
		SERVERGROUPPROTECTION_COMPLAINADD = false;
		
		SERVERGROUPNOTIFY_ENABLE = 0;
		SERVERGROUPNOTIFY_GROUPS = new Vector<Integer>();
		SERVERGROUPNOTIFY_GROUPTARGETS = new Vector<Integer>();
		SERVERGROUPNOTIFY_MESSAGE_MODE = null;
		SERVERGROUPNOTIFY_MESSAGE = null;
		SERVERGROUPNOTIFY_FILE = null;
		SERVERGROUPNOTIFY_CHANNEL_LIST = new Vector<Integer>();
		SERVERGROUPNOTIFY_CHANNEL_LIST_IGNORE = true;
		
		AUTOMOVE_ENABLE = 0;
		AUTOMOVE_SGCHANNEL_LIST = new HashMap<Integer, Integer>();
		AUTOMOVE_MESSAGE_MODE = null;
		AUTOMOVE_MESSAGE = null;
		AUTOMOVE_FILE = null;

		IDLE_CHANNEL_NAME = null;
		RECORD_CHANNEL_NAME = null;
		ADVERTISING_CHANNEL_NAME = null;
		AWAY_CHANNEL_NAME = null;
		MUTE_CHANNEL_NAME = null;
		DEFAULT_CHANNEL_ID = -1;
		lastNumberValueAtConfigLoad = null;
		updateServerInfoCache = false;
		advertiseNow = false;
		permissionListCache = null;
		clientCache = null;
		serverInfoCache = null;
		serverGroupListCache = null;
		
		listArguments = null;
		listOptions.clear();
		
		botTimer = new Timer(true);
	}
	
	int loadAndCheckConfig(boolean fromFile)
	{
		int errorCode = loadConfig(fromFile);
		if (errorCode != 0)
		{
			return errorCode;
		}
		
		if (CHECK_INTERVAL < 1)
		{
			return 22;
		}
		
		return 0;
	}
	
	String getErrorMessage(int errorCode)
	{
		if (errorCode == 20)
		{
			if (lastNumberValueAtConfigLoad != null)
			{
				return "Critical: An expected number value in config is not a number or is completely missing! Look at value " + lastNumberValueAtConfigLoad + " in config file: " + CONFIG_FILE_NAME;
			}
			else
			{
				return "Critical: An expected number value in config is not a number! Config file: " + CONFIG_FILE_NAME;
			}
		}
		
		if (errorCode == 21)
		{
			return "Critical: Advertising messages file does not exists or error while loading! Please set a valid path to the advertising config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 22)
		{
			return "Critical: Check interval in config file has to be greater than zero! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 23)
		{
			return "Critical: Teamspeak 3 server address, loginname or password missing in config file! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 24)
		{
			return "Critical: Idle check message could not be loaded! Please set a valid path to the idle check config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 25)
		{
			return "Critical: Record check message could not be loaded! Please set a valid path to the record check config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 26)
		{
			return "Critical: Bad Nickname message and rules file does not exists or error while loading! Please set a valid path to the bad nickname check config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 27)
		{
			return "Critical: Welcome message or default welcome message could not be loaded! Please set a valid path to the welcome message config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 28)
		{
			return "Critical: IDLE_MAX_TIME must be greater than IDLE_WARN_TIME! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 29)
		{
			return "Critical: Welcome message server groups missing! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 30)
		{
			return "Critical: Date pattern in config file is invalid, using default one! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 31)
		{
			return "Critical: Server query name in config file need at least 3 characters! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 32)
		{
			return "Critical: Config file missing or is not readable, check: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 33)
		{
			return "Critical: IDLE_SECOND_MAX_TIME must be greater than IDLE_MAX_TIME! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 34)
		{
			return "Critical: Second idle check message missing in config file! Please set a valid path to the idle check config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 35)
		{
			return "Critical: Idle warn message missing in config file! Please set a valid path to the idle check config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 36)
		{
			return "Critical: Bad Channel Name rules file does not exists or error while loading! Please set a valid path to the bad channel name check config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 37)
		{
			return "Critical: Advertising repeat time in config file has to be greater than zero! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 38)
		{
			return "Critical: Server Group Protection file does not exists or error while loading! Please set a valid path to the server group protection config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 39)
		{
			return "Critical: Server Group Protection needs at least one server group set! Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 40)
		{
			return "Critical: Unexpected error occurred in config file: " + CONFIG_FILE_NAME + "! Send logfile to stefan-1983@arcor.de";
		}
		
		if (errorCode == 41)
		{
			return "Critical: Away Mover message could not be loaded! Please set a valid path to the away mover config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 42)
		{
			return "Critical: Mute Mover message could not be loaded! Please set a valid path to the mute mover config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 43)
		{
			return "Critical: Server Group Notify message could not be loaded! Please set a valid path to the server group notify config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 44)
		{
			return "Critical: Auto Move file does not exists or error while loading! Please set a valid path to the auto move config file. Config file: " + CONFIG_FILE_NAME;
		}
		
		if (errorCode == 45)
		{
			return "Critical: Auto Move needs at least one server group set! Config file: " + AUTOMOVE_FILE;
		}
		
		return "Unknown";
	}
	
	private int loadConfig(boolean fromFile)
	{
		String temp;
		String lastNumerValue = null;
		
		if (fromFile)
		{
			if (!config.loadValues(CONFIG_FILE_NAME))
			{
				return 32;
			}
		}
		
		try
		{
			temp = config.getValue("bot_slowmode", "0");
			if (temp.equals("1"))
			{
				SLOW_MODE = true;
			}
			else
			{
				SLOW_MODE = false;
			}

			lastNumerValue = "bot_check_interval";
			CHECK_INTERVAL = Integer.parseInt(config.getValue("bot_check_interval", "1").trim());
			
			if (CHECK_INTERVAL > 30)
			{
				CHECK_INTERVAL = 30;
			}
			
			if (SLOW_MODE)
			{
				if (CHECK_INTERVAL < 3)
				{
					CHECK_INTERVAL = 3;
				}
			}
			else
			{
				if (CHECK_INTERVAL < 1)
				{
					CHECK_INTERVAL = 1;
				}
			}
			
			SERVER_QUERY_NAME = config.getValue("bot_server_query_name", "JTS3ServerMod");
			SERVER_QUERY_NAME_2 = config.getValue("bot_server_query_name_2");
			MESSAGE_ENCODING = config.getValue("bot_messages_encoding", "UTF-8");
			
			if (SERVER_QUERY_NAME.length() < 3)
			{
				return 31;
			}
			
			temp = config.getValue("bot_clientdblist_cache", "0");
			if (temp.equals("1"))
			{
				if (SLOW_MODE)
				{
					CLIENT_DATABASE_CACHE = false;
				}
				else
				{
					CLIENT_DATABASE_CACHE = true;
				}
			}
			else
			{
				CLIENT_DATABASE_CACHE = false;
			}
			
			temp = config.getValue("bot_connect_forever", "0");
			if (temp.equals("1"))
			{
				RECONNECT_FOREVER = true;
			}
			else
			{
				RECONNECT_FOREVER = false;
			}
			
			temp = config.getValue("command_lastseen", "0");
			if (temp.equals("1"))
			{
				COMMAND_LASTSEEN_PUBLIC = true;
			}
			else
			{
				COMMAND_LASTSEEN_PUBLIC = false;
			}
			
			try
			{
				sdf = new SimpleDateFormat(config.getValue("bot_date_pattern", "yyyy-MM-dd HH:mm:ss"));
			}
			catch (Exception eSDF)
			{
				return 30;
			}
			
			String adminListTemp = config.getValue("bot_admin_list");
			if (adminListTemp != null)
			{
				StringTokenizer adminListTokenizer = new StringTokenizer(adminListTemp, ",", false);
				while (adminListTokenizer.hasMoreTokens())
				{
					ADMIN_UID_LIST.addElement(adminListTokenizer.nextToken().trim());
				}
			}
			
			TS3_ADDRESS = config.getValue("ts3_server_address").trim();
			lastNumerValue = "ts3_server_query_port";
			temp = config.getValue("ts3_server_query_port");
			if (temp == null) throw new NumberFormatException();
			TS3_QUERY_PORT = Integer.parseInt(temp.trim());
			TS3_LOGIN = config.getValue("ts3_server_query_login");
			TS3_PASSWORD = config.getValue("ts3_server_query_password");
			lastNumerValue = "ts3_virtualserver_id";
			temp = config.getValue("ts3_virtualserver_id");
			if (temp == null) throw new NumberFormatException();
			TS3_VIRTUALSERVER_ID = Integer.parseInt(temp.trim());
			lastNumerValue = "bot_channel_id";
			BOT_CHANNEL_ID = Integer.parseInt(config.getValue("bot_channel_id", "-1").trim());
			
			if (TS3_VIRTUALSERVER_ID < 1)
			{
				lastNumerValue = "ts3_virtualserver_port";
				temp = config.getValue("ts3_virtualserver_port");
				if (temp == null) throw new NumberFormatException();
				TS3_VIRTUALSERVER_PORT = Integer.parseInt(temp.trim());
			}
			
			if (TS3_ADDRESS == null || TS3_LOGIN == null || TS3_PASSWORD == null)
			{
				return 23;
			}

			lastNumerValue = "idle_check_enable";
			IDLE_CHECK_ENABLE = Integer.parseInt(config.getValue("idle_check_enable", "0").trim());
			if (IDLE_CHECK_ENABLE == 1 || IDLE_CHECK_ENABLE == 2)
			{
				lastNumerValue = "idle_max_time";
				temp = config.getValue("idle_max_time");
				if (temp == null) throw new NumberFormatException();
				IDLE_MAX_TIME = ((Long.parseLong(temp.trim()) * 60) * 1000);

				lastNumerValue = "idle_min_clients";
				IDLE_MIN_CLIENTS = Integer.parseInt(config.getValue("idle_min_clients", "0").trim());
				
				if (IDLE_CHECK_ENABLE == 1)
				{
					IDLE_MESSAGE_MODE = "kick";
				}
				else if (IDLE_CHECK_ENABLE == 2)
				{
					IDLE_MESSAGE_MODE = config.getValue("idle_message_mode", "chat").trim();
				}
				
				lastNumerValue = "idle_warn_time";
				IDLE_WARN_TIME = Long.parseLong(config.getValue("idle_warn_time", "-1").trim());
				if (IDLE_WARN_TIME > 0)
				{
					IDLE_WARN_MESSAGE_MODE = config.getValue("idle_warn_message_mode", "chat").trim();
				}
				
				IDLE_FILE = config.getValue("idle_file");
				if (!loadIdleMessages())
				{
					return 24;
				}
				
				if (IDLE_CHECK_ENABLE == 2)
				{
					lastNumerValue = "idle_move_channel_id";
					temp = config.getValue("idle_move_channel_id");
					if (temp == null) throw new NumberFormatException();
					IDLE_MOVE_CHANNELID = Integer.parseInt(temp.trim());
					
					IDLE_MOVE_BACK = (config.getValue("idle_move_back", "0").trim().equals("1"));

					lastNumerValue = "idle_second_max_time";
					IDLE_SECOND_MAX_TIME = Long.parseLong(config.getValue("idle_second_max_time", "-1").trim());
					if (IDLE_SECOND_MAX_TIME > 0)
					{
						IDLE_SECOND_MAX_TIME = ((IDLE_SECOND_MAX_TIME * 60) * 1000);
						
						if (IDLE_SECOND_MAX_TIME <= IDLE_MAX_TIME)
						{
							return 33;
						}
						
						if (IDLE_SECOND_MESSAGE == null || IDLE_SECOND_MESSAGE.length() == 0)
						{
							return 34;
						}
					}
				}
				
				if (IDLE_WARN_TIME > 0)
				{
					IDLE_WARN_TIME = ((IDLE_WARN_TIME * 60) * 1000);
					
					if (IDLE_WARN_TIME >= IDLE_MAX_TIME)
					{
						return 28;
					}
					
					if (IDLE_WARN_MESSAGE == null)
					{
						return 35;
					}
				}
				IDLE_CLIENTS_WARN_SENT.clear();
				
				temp = null;
				IDLE_CHANNEL_LIST.clear();
				temp = config.getValue("idle_channel_list");
				lastNumerValue = "idle_channel_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						IDLE_CHANNEL_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
				
				temp = null;
				IDLE_GROUP_LIST.clear();
				temp = config.getValue("idle_group_list");
				lastNumerValue = "idle_group_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						IDLE_GROUP_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
				
				IDLE_CHANNEL_LIST_IGNORE = !config.getValue("idle_channel_list_mode", "ignore").trim().equalsIgnoreCase("only");
				IDLE_GROUP_LIST_IGNORE = !config.getValue("idle_group_list_mode", "ignore").trim().equalsIgnoreCase("only");
				
				if (IDLE_MESSAGE == null)
				{
					return 24;
				}
			}

			lastNumerValue = "away_check_enable";
			AWAY_CHECK_ENABLE = Integer.parseInt(config.getValue("away_check_enable", "0").trim());
			if (AWAY_CHECK_ENABLE == 1 || AWAY_CHECK_ENABLE == 2)
			{
				lastNumerValue = "away_move_channel_id";
				temp = config.getValue("away_move_channel_id");
				if (temp == null) throw new NumberFormatException();
				AWAY_MOVE_CHANNELID = Integer.parseInt(temp.trim());

				lastNumerValue = "away_move_delay";
				AWAY_MOVE_DELAY = Integer.parseInt(config.getValue("away_move_delay", "5").trim());
				
				if (AWAY_MOVE_DELAY < 0 || AWAY_MOVE_DELAY > 10000)
				{
					AWAY_MOVE_DELAY = 5;
				}
				
				temp = null;
				AWAY_CHANNEL_LIST.clear();
				temp = config.getValue("away_channel_list");
				lastNumerValue = "away_channel_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						AWAY_CHANNEL_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
				
				AWAY_CHANNEL_LIST_IGNORE = !config.getValue("away_channel_list_mode", "ignore").trim().equalsIgnoreCase("only");
				
				temp = null;
				AWAY_GROUP_LIST.clear();
				temp = config.getValue("away_group_list");
				lastNumerValue = "away_group_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						AWAY_GROUP_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}

				AWAY_GROUP_LIST_IGNORE = !config.getValue("away_group_list_mode", "ignore").trim().equalsIgnoreCase("only");
				
				AWAY_MESSAGE_MODE = config.getValue("away_message_mode", "none").trim();
				
				if (!AWAY_MESSAGE_MODE.equalsIgnoreCase("none"))
				{
					AWAY_FILE = config.getValue("away_file");
					if (!loadAwayMessages())
					{
						return 41;
					}
				}
			}

			lastNumerValue = "mute_check_enable";
			MUTE_CHECK_ENABLE = Integer.parseInt(config.getValue("mute_check_enable", "0").trim());
			if (MUTE_CHECK_ENABLE == 1 || MUTE_CHECK_ENABLE == 2)
			{
				MUTE_MOVE_HEADPHONE = (config.getValue("mute_move_headphone", "0").trim().equals("1"));
				MUTE_MOVE_MICROPHONE = (config.getValue("mute_move_microphone", "0").trim().equals("1"));
				MUTE_MOVE_HEADPHONE_HARDWARE = (config.getValue("mute_move_headphone_hardware", "0").trim().equals("1"));
				MUTE_MOVE_MICROPHONE_HARDWARE = (config.getValue("mute_move_microphone_hardware", "0").trim().equals("1"));
				
				if (!MUTE_MOVE_HEADPHONE && !MUTE_MOVE_MICROPHONE && !MUTE_MOVE_HEADPHONE_HARDWARE && !MUTE_MOVE_MICROPHONE_HARDWARE)
				{
					MUTE_CHECK_ENABLE = 0;
				}
				
				if (MUTE_CHECK_ENABLE != 0)
				{
					lastNumerValue = "mute_move_channel_id";
					temp = config.getValue("mute_move_channel_id");
					if (temp == null) throw new NumberFormatException();
					MUTE_MOVE_CHANNELID = Integer.parseInt(temp.trim());

					lastNumerValue = "mute_move_delay";
					MUTE_MOVE_DELAY = Integer.parseInt(config.getValue("mute_move_delay", "5").trim());
					
					if (MUTE_MOVE_DELAY < 0 || MUTE_MOVE_DELAY > 10000)
					{
						MUTE_MOVE_DELAY = 5;
					}
					
					temp = null;
					MUTE_CHANNEL_LIST.clear();
					temp = config.getValue("mute_channel_list");
					lastNumerValue = "mute_channel_list";
					if (temp != null && temp.length() > 0)
					{
						StringTokenizer st = new StringTokenizer(temp, ",", false);
						while (st.hasMoreTokens())
						{
							MUTE_CHANNEL_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
						}
					}
					
					MUTE_CHANNEL_LIST_IGNORE = !config.getValue("mute_channel_list_mode", "ignore").trim().equalsIgnoreCase("only");
					
					temp = null;
					MUTE_GROUP_LIST.clear();
					temp = config.getValue("mute_group_list");
					lastNumerValue = "mute_group_list";
					if (temp != null && temp.length() > 0)
					{
						StringTokenizer st = new StringTokenizer(temp, ",", false);
						while (st.hasMoreTokens())
						{
							MUTE_GROUP_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
						}
					}

					MUTE_GROUP_LIST_IGNORE = !config.getValue("mute_group_list_mode", "ignore").trim().equalsIgnoreCase("only");
					
					MUTE_MESSAGE_MODE = config.getValue("mute_message_mode", "none").trim();
					
					if (!MUTE_MESSAGE_MODE.equalsIgnoreCase("none"))
					{
						MUTE_FILE = config.getValue("mute_file");
						if (!loadMuteMessages())
						{
							return 42;
						}
					}
				}
			}

			lastNumerValue = "record_check_enable";
			RECORD_CHECK_ENABLE = Integer.parseInt(config.getValue("record_check_enable", "0").trim());
			if (RECORD_CHECK_ENABLE == 1 || RECORD_CHECK_ENABLE == 2)
			{
				if (RECORD_CHECK_ENABLE == 1)
				{
					RECORD_MESSAGE_MODE = "kick";
				}
				else if (RECORD_CHECK_ENABLE == 2)
				{
					RECORD_MESSAGE_MODE = config.getValue("record_message_mode", "poke").trim();
				}
				
				RECORD_FILE = config.getValue("record_file");
				if (!loadRecordMessages())
				{
					return 25;
				}
				
				if (RECORD_CHECK_ENABLE == 2)
				{
					lastNumerValue = "record_move_channel_id";
					temp = config.getValue("record_move_channel_id");
					if (temp == null) throw new NumberFormatException();
					RECORD_MOVE_CHANNELID = Integer.parseInt(temp.trim());
				}
				
				RECORD_COMPLAINADD = (config.getValue("record_add_complain", "0").trim().equals("1"));
							
				temp = null;
				RECORD_CHANNEL_LIST.clear();
				temp = config.getValue("record_channel_list");
				lastNumerValue = "record_channel_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						RECORD_CHANNEL_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
							
				temp = null;
				RECORD_GROUP_LIST.clear();
				temp = config.getValue("record_group_list");
				lastNumerValue = "record_group_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						RECORD_GROUP_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
				
				RECORD_CHANNEL_LIST_IGNORE = !config.getValue("record_channel_list_mode", "ignore").trim().equalsIgnoreCase("only");
				RECORD_GROUP_LIST_IGNORE = !config.getValue("record_group_list_mode", "ignore").trim().equalsIgnoreCase("only");
				
				if (RECORD_MESSAGE == null)
				{
					return 25;
				}
			}

			lastNumerValue = "servergroupnotify_enable";
			SERVERGROUPNOTIFY_ENABLE = Integer.parseInt(config.getValue("servergroupnotify_enable", "0").trim());
			if (SERVERGROUPNOTIFY_ENABLE == 1 && SLOW_MODE)
			{
				SERVERGROUPNOTIFY_ENABLE = 0;
			}
			else if (SERVERGROUPNOTIFY_ENABLE == 1)
			{
				SERVERGROUPNOTIFY_FILE = config.getValue("servergroupnotify_file");
				if (!loadServerGroupNotifyMessages())
				{
					return 43;
				}
				
				temp = null;
				SERVERGROUPNOTIFY_GROUPS.clear();
				temp = config.getValue("servergroupnotify_groups");
				lastNumerValue = "servergroupnotify_groups";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						SERVERGROUPNOTIFY_GROUPS.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}

				temp = null;
				SERVERGROUPNOTIFY_GROUPTARGETS.clear();
				temp = config.getValue("servergroupnotify_grouptargets");
				lastNumerValue = "servergroupnotify_grouptargets";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						SERVERGROUPNOTIFY_GROUPTARGETS.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
							
				temp = null;
				SERVERGROUPNOTIFY_CHANNEL_LIST.clear();
				temp = config.getValue("servergroupnotify_channel_list");
				lastNumerValue = "servergroupnotify_channel_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						SERVERGROUPNOTIFY_CHANNEL_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
				
				SERVERGROUPNOTIFY_CHANNEL_LIST_IGNORE = !config.getValue("servergroupnotify_channel_list_mode", "ignore").trim().equalsIgnoreCase("only");
				
				SERVERGROUPNOTIFY_MESSAGE_MODE = config.getValue("servergroupnotify_message_mode", "chat").trim();
				
				if (SERVERGROUPNOTIFY_GROUPS.size() == 0 || SERVERGROUPNOTIFY_GROUPTARGETS.size() == 0)
				{
					SERVERGROUPNOTIFY_ENABLE = 0;
				}
				
				if (SERVERGROUPNOTIFY_MESSAGE == null)
				{
					return 43;
				}
			}

			lastNumerValue = "advertising_enable";
			ADVERTISING_ENABLE = Integer.parseInt(config.getValue("advertising_enable", "0").trim());
			if (ADVERTISING_ENABLE == 1 || ADVERTISING_ENABLE == 2)
			{
				ADVERTISING_FILE = config.getValue("advertising_file");
				
				if (ADVERTISING_ENABLE == 2)
				{
					lastNumerValue = "advertising_channel_id";
					temp = config.getValue("advertising_channel_id");
					if (temp == null) throw new NumberFormatException();
					ADVERTISING_CHANNELID = Integer.parseInt(temp.trim());
				}
				
				if (!loadAdvertisingMessages())
				{
					return 21;
				}

				lastNumerValue = "advertising_repeat_time";
				temp = config.getValue("advertising_repeat_time");
				if (temp == null) throw new NumberFormatException();
				ADVERTISING_INTERVAL = Integer.parseInt(temp.trim());
				
				if (ADVERTISING_INTERVAL < 1)
				{
					return 37;
				}
				
				timerAdvertising = new TimerTask()
				{
					public void run()
					{
						advertiseNow = true;
					}
				};
				botTimer.schedule(timerAdvertising, (ADVERTISING_INTERVAL * 60) * 1000, (ADVERTISING_INTERVAL * 60) * 1000);
			}

			lastNumerValue = "welcomemessage_enable";
			WELCOMEMESSAGE_ENABLE = Integer.parseInt(config.getValue("welcomemessage_enable", "0").trim());
			if (WELCOMEMESSAGE_ENABLE == 1 && SLOW_MODE)
			{
				WELCOMEMESSAGE_ENABLE = 0;
			}
			else if (WELCOMEMESSAGE_ENABLE == 1)
			{
				temp = null;
				WELCOMEMESSAGE_GROUPS.clear();
				temp = config.getValue("welcomemessage_groups");
				lastNumerValue = "welcomemessage_groups";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						WELCOMEMESSAGE_GROUPS.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
				else
				{
					return 29;
				}
				
				WELCOMEMESSAGE_MESSAGE_MODE = config.getValue("welcomemessage_message_mode", "chat").trim();
			}

			lastNumerValue = "default_welcomemessage_enable";
			WELCOMEMESSAGE_DEFAULT_ENABLE = Integer.parseInt(config.getValue("default_welcomemessage_enable", "0").trim());
			if (WELCOMEMESSAGE_DEFAULT_ENABLE == 1 && SLOW_MODE)
			{
				WELCOMEMESSAGE_DEFAULT_ENABLE = 0;
			}
			else if (WELCOMEMESSAGE_DEFAULT_ENABLE == 1)
			{
				WELCOMEMESSAGE_DEFAULT_MESSAGE_MODE = config.getValue("default_welcomemessage_message_mode", "chat").trim();
			}
			
			if (WELCOMEMESSAGE_ENABLE == 1 || WELCOMEMESSAGE_DEFAULT_ENABLE == 1)
			{
				WELCOMEMESSAGE_FILE = config.getValue("welcomemessage_file");
				if (!loadWelcomeMessages())
				{
					return 27;
				}
				
				if (WELCOMEMESSAGE_MESSAGE == null)
				{
					return 27;
				}
				
				if (WELCOMEMESSAGE_DEFAULT_MESSAGE == null)
				{
					return 27;
				}
			}

			lastNumerValue = "badnickname_check_enable";
			BADNICKNAME_CHECK_ENABLE = Integer.parseInt(config.getValue("badnickname_check_enable", "0").trim());
			if (BADNICKNAME_CHECK_ENABLE == 1)
			{
				BADNICKNAME_FILE = config.getValue("badnickname_file");
				
				if (!loadBadNicknameFile())
				{
					return 26;
				}
				
				temp = null;
				BADNICKNAME_GROUP_LIST.clear();
				temp = config.getValue("badnickname_group_list");
				lastNumerValue = "badnickname_group_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						BADNICKNAME_GROUP_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}

				BADNICKNAME_GROUP_LIST_IGNORE = !config.getValue("badnickname_group_list_mode", "ignore").trim().equalsIgnoreCase("only");
				
				BADNICKNAME_COMPLAINADD = (config.getValue("badnickname_add_complain", "0").trim().equals("1"));
				
				if (BADNICKNAME_RULES.size() == 0)
				{
					addLogEntry("CONFIG_LOAD_ERROR", "No bad nickname rules was found! Config file: " + BADNICKNAME_FILE, true);
					return 26;
				}
			}

			lastNumerValue = "badchannelname_check_enable";
			BADCHANNELNAME_CHECK_ENABLE = Integer.parseInt(config.getValue("badchannelname_check_enable", "0").trim());
			if (BADCHANNELNAME_CHECK_ENABLE == 1 && SLOW_MODE)
			{
				BADCHANNELNAME_CHECK_ENABLE = 0;
			}
			else if (BADCHANNELNAME_CHECK_ENABLE == 1)
			{
				BADCHANNELNAME_FILE = config.getValue("badchannelname_file");
				
				if (!loadBadChannelNameFile())
				{
					return 36;
				}
				
				temp = null;
				BADCHANNELNAME_CHANNEL_LIST.clear();
				temp = config.getValue("badchannelname_channel_list");
				lastNumerValue = "badchannelname_channel_list";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						BADCHANNELNAME_CHANNEL_LIST.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
				
				if (BADCHANNELNAME_RULES.size() == 0)
				{
					addLogEntry("CONFIG_LOAD_ERROR", "No bad channel name rules was found! Config file: " + BADCHANNELNAME_FILE, true);
					return 36;
				}
			}

			lastNumerValue = "servergroupprotection_enable";
			SERVERGROUPPROTECTION_ENABLE = Integer.parseInt(config.getValue("servergroupprotection_enable", "0").trim());
			if (SERVERGROUPPROTECTION_ENABLE == 1)
			{
				temp = null;
				SERVERGROUPPROTECTION_GROUPS.clear();
				temp = config.getValue("servergroupprotection_groups");
				lastNumerValue = "servergroupprotection_groups";
				if (temp != null && temp.length() > 0)
				{
					StringTokenizer st = new StringTokenizer(temp, ",", false);
					while (st.hasMoreTokens())
					{
						SERVERGROUPPROTECTION_GROUPS.addElement(Integer.parseInt(st.nextToken().trim()));
					}
				}
				else
				{
					return 39;
				}
				
				SERVERGROUPPROTECTION_COMPLAINADD = (config.getValue("servergroupprotection_add_complain", "0").trim().equals("1"));
				
				SERVERGROUPPROTECTION_MESSAGE_MODE = config.getValue("servergroupprotection_message_mode", "chat").trim();
				
				SERVERGROUPPROTECTION_FILE = config.getValue("servergroupprotection_file");
				
				temp = config.getValue("servergroupprotection_kick", "0");
				if (temp.equals("1"))
				{
					SERVERGROUPPROTECTION_KICK = true;
					SERVERGROUPPROTECTION_MESSAGE_MODE = "kick";
				}
				
				temp = config.getValue("servergroupprotection_add_missing_groups", "0");
				if (temp.equals("1"))
				{
					SERVERGROUPPROTECTION_ADD_MISSING_GROUPS = true;
				}
				
				if (!loadServerGroupProtectionFile())
				{
					return 38;
				}
				
				if (SERVERGROUPPROTECTION_GROUPS.size() == 0)
				{
					return 39;
				}
			}

			lastNumerValue = "automove_enable";
			AUTOMOVE_ENABLE = Integer.parseInt(config.getValue("automove_enable", "0").trim());
			if (AUTOMOVE_ENABLE == 1 && SLOW_MODE)
			{
				AUTOMOVE_ENABLE = 0;
			}
			else if (AUTOMOVE_ENABLE == 1)
			{
				AUTOMOVE_MESSAGE_MODE = config.getValue("automove_message_mode", "none").trim();
				
				AUTOMOVE_FILE = config.getValue("automove_file");
				
				if (!loadAutoMoveFile())
				{
					return 44;
				}
				
				if (AUTOMOVE_SGCHANNEL_LIST.size() == 0)
				{
					return 45;
				}
			}
		}
		catch (NumberFormatException nfe)
		{
			addLogEntry(nfe, false);
			lastNumberValueAtConfigLoad = new String(lastNumerValue);
			
			if (configCheckMode)
			{
				System.out.println("A number conversion error occurred while checking config file:");
				System.out.println(nfe.toString());
				System.out.println("Check if you set the config value " + lastNumerValue + " and if you really set a number!");
				
				if (DEBUG) nfe.printStackTrace();
			}
			
			return 20;
		}
		catch (Exception e1)
		{
			addLogEntry(e1, false);
			
			if (configCheckMode)
			{
				System.out.println("The following error occurred while checking config file:");
				System.out.println(e1.toString());
				
				if (DEBUG) e1.printStackTrace();
			}
			
			return 40;
		}
		
		return 0;
	}
	
	boolean loadAdvertisingMessages()
	{
		if (ADVERTISING_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to advertising config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		ADVERTISING_FILE = ADVERTISING_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(ADVERTISING_FILE), MESSAGE_ENCODING));
			
			ADVERTISING_MESSAGES.clear();
			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at advertising config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+ADVERTISING_FILE, true);
				br.close();
				return false;
			}
			
			int warningCount = 0;
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					line = line.replace("\\n", "\n");
					
					if (line.length() > getMaxMessageLength("chat"))
					{
						++warningCount;
					}
					
					ADVERTISING_MESSAGES.addElement(line);
				}
			}
			
			br.close();
			
			if (warningCount > 0)
			{
				addLogEntry("MESSAGE_WARNING", Integer.toString(warningCount) + " advertising messages are to long! Make sure that chat messages are not longer than "+Short.toString(getMaxMessageLength("chat"))+" characters (including spaces and BBCode), check file: "+ADVERTISING_FILE, true);
			}
			
			currentAdvertiseMessage = 0;
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Advertising config file does not exist or missing permission for reading, check file: "+ADVERTISING_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading advertising config file, check file: "+ADVERTISING_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadIdleMessages()
	{
		if (IDLE_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to idle check config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		IDLE_FILE = IDLE_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(IDLE_FILE), MESSAGE_ENCODING));

			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at idle check config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+IDLE_FILE, true);
				br.close();
				return false;
			}
			
			int count = 0;
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					line = line.replace("\\n", "\n");
					
					if (count == 0) IDLE_MESSAGE = line;
					if (count == 1) IDLE_SECOND_MESSAGE = line;
					if (count == 2) IDLE_WARN_MESSAGE = line;
					
					++count;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Idle check config file does not exist or missing permission for reading, check file: "+IDLE_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading idle check config file, check file: "+IDLE_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadRecordMessages()
	{
		if (RECORD_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to record check config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		RECORD_FILE = RECORD_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(RECORD_FILE), MESSAGE_ENCODING));

			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at record check config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+RECORD_FILE, true);
				br.close();
				return false;
			}
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					line = line.replace("\\n", "\n");
					
					RECORD_MESSAGE = line;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Record check config file does not exist or missing permission for reading, check file: "+RECORD_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading record check config file, check file: "+RECORD_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadAwayMessages()
	{
		if (AWAY_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to away mover config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		AWAY_FILE = AWAY_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(AWAY_FILE), MESSAGE_ENCODING));

			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at away mover config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+AWAY_FILE, true);
				br.close();
				return false;
			}
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					line = line.replace("\\n", "\n");
					
					AWAY_MESSAGE = line;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Away mover config file does not exist or missing permission for reading, check file: "+AWAY_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading away mover config file, check file: "+AWAY_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadMuteMessages()
	{
		if (MUTE_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to mute mover config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		MUTE_FILE = MUTE_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(MUTE_FILE), MESSAGE_ENCODING));

			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at mute mover config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+MUTE_FILE, true);
				br.close();
				return false;
			}
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					line = line.replace("\\n", "\n");
					
					MUTE_MESSAGE = line;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Mute mover config file does not exist or missing permission for reading, check file: "+MUTE_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading mute mover config file, check file: "+MUTE_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadWelcomeMessages()
	{
		if (WELCOMEMESSAGE_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to welcome message config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		WELCOMEMESSAGE_FILE = WELCOMEMESSAGE_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(WELCOMEMESSAGE_FILE), MESSAGE_ENCODING));

			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at welcome message config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+WELCOMEMESSAGE_FILE, true);
				br.close();
				return false;
			}
			int count = 0;
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					line = line.replace("\\n", "\n");
					
					if (count == 0) WELCOMEMESSAGE_DEFAULT_MESSAGE = line;
					if (count == 1) WELCOMEMESSAGE_MESSAGE = line;
					
					++count;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Welcome message config file does not exist or missing permission for reading, check file: "+WELCOMEMESSAGE_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading welcome message config file, check file: "+WELCOMEMESSAGE_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadAutoMoveFile()
	{
		if (AUTOMOVE_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to auto move config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		AUTOMOVE_FILE = AUTOMOVE_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(AUTOMOVE_FILE), MESSAGE_ENCODING));

			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at auto move config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+AUTOMOVE_FILE, true);
				br.close();
				return false;
			}
			
			AUTOMOVE_SGCHANNEL_LIST.clear();
			int count = 0;
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() >= 3)
				{
					if (count == 0)
					{
						line = line.replace("\\n", "\n");
						
						AUTOMOVE_MESSAGE = line;
					}
					if (count >= 1)
					{
						int pos = line.indexOf(",");
						
						if (pos == -1 || pos == 0)
						{
							continue;
						}
						
						try
						{
							AUTOMOVE_SGCHANNEL_LIST.put(Integer.parseInt(line.substring(0, pos).trim()), Integer.parseInt(line.substring(pos+1).trim()));
						}
						catch (Exception e) { continue; }
					}
					
					++count;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Auto move config file does not exist or missing permission for reading, check file: "+AUTOMOVE_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading auto move config file, check file: "+AUTOMOVE_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadBadNicknameFile()
	{
		if (BADNICKNAME_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to bad nickname config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		BADNICKNAME_FILE = BADNICKNAME_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(BADNICKNAME_FILE), MESSAGE_ENCODING));
			
			BADNICKNAME_RULES.clear();
			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at bad nickname config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+BADNICKNAME_FILE, true);
				br.close();
				return false;
			}
			int count = 0;
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					if (count == 0)
					{
						line = line.replace("\\n", "\n");
						
						BADNICKNAME_KICK_MESSAGE = line;
					}
					if (count >= 1)
					{
						BADNICKNAME_RULES.addElement(Pattern.compile(line, Pattern.CASE_INSENSITIVE + Pattern.UNICODE_CASE));
					}
					
					++count;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Bad nickname config file does not exist or missing permission for reading, check file: "+BADNICKNAME_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading bad nickname config file, check file: "+BADNICKNAME_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadBadChannelNameFile()
	{
		if (BADCHANNELNAME_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to bad channel name config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		BADCHANNELNAME_FILE = BADCHANNELNAME_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(BADCHANNELNAME_FILE), MESSAGE_ENCODING));
			
			BADCHANNELNAME_RULES.clear();
			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at bad channel name config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+BADCHANNELNAME_FILE, true);
				br.close();
				return false;
			}
			int count = 0;
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					if (count >= 0)
					{
						BADCHANNELNAME_RULES.addElement(Pattern.compile(line, Pattern.CASE_INSENSITIVE + Pattern.UNICODE_CASE));
					}
					
					++count;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Bad channel name config file does not exist or missing permission for reading, check file: "+BADCHANNELNAME_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading bad channel name config file, check file: "+BADCHANNELNAME_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadServerGroupNotifyMessages()
	{
		if (SERVERGROUPNOTIFY_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to server group notify config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		SERVERGROUPNOTIFY_FILE = SERVERGROUPNOTIFY_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(SERVERGROUPNOTIFY_FILE), MESSAGE_ENCODING));

			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at server group notify config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+SERVERGROUPNOTIFY_FILE, true);
				br.close();
				return false;
			}
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					line = line.replace("\\n", "\n");
					
					SERVERGROUPNOTIFY_MESSAGE = line;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Server group notify config file does not exist or missing permission for reading, check file: "+SERVERGROUPNOTIFY_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading server group notify config file, check file: "+SERVERGROUPNOTIFY_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	boolean loadServerGroupProtectionFile()
	{
		if (SERVERGROUPPROTECTION_FILE == null)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Path to server group protection config file was not set in bot config! Config file: " + CONFIG_FILE_NAME, true);
			return false;
		}
		
		SERVERGROUPPROTECTION_FILE = SERVERGROUPPROTECTION_FILE.trim();
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(SERVERGROUPPROTECTION_FILE), MESSAGE_ENCODING));

			String line = br.readLine();
			
			if (MESSAGE_ENCODING.equalsIgnoreCase("UTF-8") && line != null && line.charAt(0) == 65279)
			{
				line = line.substring(1);
			}
			
			if (line == null || !line.equals("# JTS3ServerMod Config File"))
			{
				addLogEntry("CONFIG_LOAD_ERROR", "Special config file header is missing at server group protection config file!", true);
				addLogEntry("CONFIG_LOAD_ERROR", "Check if you set the right file: "+SERVERGROUPPROTECTION_FILE, true);
				br.close();
				return false;
			}
			
			SERVERGROUPPROTECTION_CLIENTS.clear();
			for (int i=0; i<SERVERGROUPPROTECTION_GROUPS.size(); i++)
			{
				SERVERGROUPPROTECTION_CLIENTS.addElement(new Vector<String>());
			}
			int count = 0;
			
			while ((line = br.readLine()) != null)
			{
				if (line.startsWith("#"))
				{
					continue;
				}
				
				if (line.length() > 3)
				{
					if (count == 0)
					{
						line = line.replace("\\n", "\n");
						
						SERVERGROUPPROTECTION_MESSAGE = line;
					}
					if (count >= 1)
					{
						int pos = line.indexOf(",");
						
						if (pos == -1 || pos == 0)
						{
							continue;
						}
						
						try
						{
							int indexPos = SERVERGROUPPROTECTION_GROUPS.indexOf(Integer.parseInt(line.substring(0, pos)));
							
							if (indexPos == -1)
							{
								continue;
							}
							
							SERVERGROUPPROTECTION_CLIENTS.elementAt(indexPos).addElement(line.substring(pos+1).trim());
						}
						catch (Exception e) { continue; }
					}
					
					++count;
				}
			}
			
			br.close();
		}
		catch (FileNotFoundException fnfe)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Server group protection config file does not exist or missing permission for reading, check file: "+SERVERGROUPPROTECTION_FILE, true);
			return false;
		}
		catch (Exception e)
		{
			addLogEntry("CONFIG_LOAD_ERROR", "Unknown error while loading server group protection config file, check file: "+SERVERGROUPPROTECTION_FILE, true);
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	private boolean saveServerGroupProtectionFile()
	{
		if (SERVERGROUPPROTECTION_FILE == null)
		{
			return false;
		}
		
		try
		{
			PrintStream ps = new PrintStream(SERVERGROUPPROTECTION_FILE, MESSAGE_ENCODING);
			
			ps.println("# JTS3ServerMod Config File");
			ps.println("# The first line is the kick or chat message for the server group protection.");
			ps.println("# You can use the following keywords, which will be replaced:");
			ps.println("# %SERVER_GROUP_ID% - Replaced with the server group id.");
			ps.println("# Typical BBCode like in Teamspeak 3 Client possible.");
			
			if (SERVERGROUPPROTECTION_MESSAGE == null)
			{
				ps.println();
			}
			else
			{
				ps.println(SERVERGROUPPROTECTION_MESSAGE.replace("\n", "\\n"));
			}
			
			ps.println();
			ps.println("# This is the list of allowed clients in the protected server groups.");
			ps.println("# One line per client starting with the server group id, followed by a comma,");
			ps.println("# and ends with the unique id of the client.");
			ps.println("# If a client is member of two protected groups, make two lines with the");
			ps.println("# same unique id, but different server group id.");
			
			if (SERVERGROUPPROTECTION_CLIENTS != null && SERVERGROUPPROTECTION_GROUPS != null)
			{
				for (int i = 0; i < SERVERGROUPPROTECTION_CLIENTS.size(); i++)
				{
					for (int j = 0; j < SERVERGROUPPROTECTION_CLIENTS.elementAt(i).size(); j++)
					{
						ps.print(SERVERGROUPPROTECTION_GROUPS.elementAt(i));
						ps.print(",");
						ps.println(SERVERGROUPPROTECTION_CLIENTS.elementAt(i).elementAt(j));
					}
				}
			}

			ps.flush();
			ps.close();
		}
		catch (Exception e)
		{
			addLogEntry(e, true);
			return false;
		}
		return true;
	}
	
	int addServerGroupProtectionEntry(int serverGroupID, String clientUniqueID)
	{
		if (SERVERGROUPPROTECTION_CLIENTS == null || SERVERGROUPPROTECTION_GROUPS == null)
		{
			return -3;
		}
		
		int posGroup = SERVERGROUPPROTECTION_GROUPS.indexOf(serverGroupID);
		if (posGroup < 0)
		{
			return -2;
		}
		
		int posClient = SERVERGROUPPROTECTION_CLIENTS.elementAt(posGroup).indexOf(clientUniqueID);
		if (posClient >= 0)
		{
			return 0;
		}
		
		SERVERGROUPPROTECTION_CLIENTS.elementAt(posGroup).addElement(clientUniqueID);
		return (saveServerGroupProtectionFile() ? 1 : -1);
	}
	
	int removeServerGroupProtectionEntry(int serverGroupID, String clientUniqueID)
	{
		if (SERVERGROUPPROTECTION_CLIENTS == null || SERVERGROUPPROTECTION_GROUPS == null)
		{
			return -3;
		}
		
		int posGroup = SERVERGROUPPROTECTION_GROUPS.indexOf(serverGroupID);
		if (posGroup < 0)
		{
			return -2;
		}
		
		int posClient = SERVERGROUPPROTECTION_CLIENTS.elementAt(posGroup).indexOf(clientUniqueID);
		if (posClient < 0)
		{
			return 0;
		}
		
		SERVERGROUPPROTECTION_CLIENTS.elementAt(posGroup).remove(posClient);
		return (saveServerGroupProtectionFile() ? 1 : -1);
	}
	
	void createMessages()
	{
		if (IDLE_CHECK_ENABLE == 1 || IDLE_CHECK_ENABLE == 2)
		{
			if (IDLE_MESSAGE != null)
			{
				IDLE_MESSAGE = IDLE_MESSAGE.replace("%IDLE_MAX_TIME%", Long.toString((IDLE_MAX_TIME / 1000) / 60));
				if (IDLE_CHECK_ENABLE == 2) IDLE_MESSAGE = IDLE_MESSAGE.replace("%IDLE_CHANNEL_NAME%", IDLE_CHANNEL_NAME);
				
				if (!isMessageLengthValid(IDLE_MESSAGE_MODE, IDLE_MESSAGE))
				{
					addLogEntry("MESSAGE_WARNING", "Idle message is to long! Make sure that "+IDLE_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(IDLE_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+IDLE_FILE, true);
				}
			}
			
			if (IDLE_WARN_TIME > 0 && IDLE_WARN_MESSAGE != null)
			{
				IDLE_WARN_MESSAGE = IDLE_WARN_MESSAGE.replace("%IDLE_WARN_TIME%", Long.toString((IDLE_WARN_TIME / 1000) / 60));
				IDLE_WARN_MESSAGE = IDLE_WARN_MESSAGE.replace("%IDLE_MAX_TIME%", Long.toString((IDLE_MAX_TIME / 1000) / 60));
				if (IDLE_CHECK_ENABLE == 2) IDLE_WARN_MESSAGE = IDLE_WARN_MESSAGE.replace("%IDLE_CHANNEL_NAME%", IDLE_CHANNEL_NAME);
				
				if (!isMessageLengthValid(IDLE_WARN_MESSAGE_MODE, IDLE_WARN_MESSAGE))
				{
					addLogEntry("MESSAGE_WARNING", "Idle Warn message is to long! Make sure that "+IDLE_WARN_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(IDLE_WARN_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+IDLE_FILE, true);
				}
			}
			
			if (IDLE_SECOND_MAX_TIME > 0 && IDLE_SECOND_MESSAGE != null)
			{
				IDLE_SECOND_MESSAGE = IDLE_SECOND_MESSAGE.replace("%IDLE_SECOND_MAX_TIME%", Long.toString((IDLE_SECOND_MAX_TIME / 1000) / 60));
				IDLE_SECOND_MESSAGE = IDLE_SECOND_MESSAGE.replace("%IDLE_MAX_TIME%", Long.toString((IDLE_MAX_TIME / 1000) / 60));
				
				if (!isMessageLengthValid("kick", IDLE_SECOND_MESSAGE))
				{
					addLogEntry("MESSAGE_WARNING", "Second Idle message is to long! Make sure that kick messages are not longer than "+Short.toString(getMaxMessageLength("kick"))+" characters (including spaces and BBCode), check file: "+IDLE_FILE, true);
				}
			}
		}
		
		if ((RECORD_CHECK_ENABLE == 1 || RECORD_CHECK_ENABLE == 2) && RECORD_MESSAGE != null)
		{
			if (RECORD_CHECK_ENABLE == 2) RECORD_MESSAGE = RECORD_MESSAGE.replace("%RECORD_CHANNEL_NAME%", RECORD_CHANNEL_NAME);
			
			if (!isMessageLengthValid(RECORD_MESSAGE_MODE, RECORD_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Record message is to long! Make sure that "+RECORD_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(RECORD_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+RECORD_FILE, true);
			}
		}
		
		if ((AWAY_CHECK_ENABLE == 1 || AWAY_CHECK_ENABLE == 2) && AWAY_MESSAGE != null)
		{
			AWAY_MESSAGE = AWAY_MESSAGE.replace("%AWAY_CHANNEL_NAME%", AWAY_CHANNEL_NAME);
			
			if (!isMessageLengthValid(AWAY_MESSAGE_MODE, AWAY_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Away Mover message is to long! Make sure that "+AWAY_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(AWAY_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+AWAY_FILE, true);
			}
		}
		
		if ((MUTE_CHECK_ENABLE == 1 || MUTE_CHECK_ENABLE == 2) && MUTE_MESSAGE != null)
		{
			MUTE_MESSAGE = MUTE_MESSAGE.replace("%MUTE_CHANNEL_NAME%", MUTE_CHANNEL_NAME);
			
			if (!isMessageLengthValid(MUTE_MESSAGE_MODE, MUTE_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Mute Mover message is to long! Make sure that "+MUTE_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(MUTE_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+MUTE_FILE, true);
			}
		}
		
		if (BADNICKNAME_CHECK_ENABLE == 1 && BADNICKNAME_KICK_MESSAGE != null)
		{
			if (!isMessageLengthValid("kick", BADNICKNAME_KICK_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Bad Nickname message is to long! Make sure that kick messages are not longer than "+Short.toString(getMaxMessageLength("kick"))+" characters (including spaces and BBCode), check file: "+BADNICKNAME_FILE, true);
			}
		}
		
		if (SERVERGROUPPROTECTION_ENABLE == 1 && SERVERGROUPPROTECTION_MESSAGE != null)
		{
			if (!isMessageLengthValid(SERVERGROUPPROTECTION_MESSAGE_MODE, SERVERGROUPPROTECTION_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Server Group Protection message is to long! Make sure that "+SERVERGROUPPROTECTION_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(SERVERGROUPPROTECTION_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+SERVERGROUPPROTECTION_FILE, true);
			}
		}
		
		if (AUTOMOVE_ENABLE == 1 && AUTOMOVE_MESSAGE != null)
		{
			if (!isMessageLengthValid(AUTOMOVE_MESSAGE_MODE, AUTOMOVE_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Auto Move message is to long! Make sure that "+AUTOMOVE_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(AUTOMOVE_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+AUTOMOVE_FILE, true);
			}
		}
		
		if (SERVERGROUPNOTIFY_ENABLE == 1 && SERVERGROUPNOTIFY_MESSAGE != null)
		{
			if (!isMessageLengthValid(SERVERGROUPNOTIFY_MESSAGE_MODE, SERVERGROUPNOTIFY_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Server Group Notify message is to long! Make sure that "+SERVERGROUPNOTIFY_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(SERVERGROUPNOTIFY_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+SERVERGROUPNOTIFY_FILE, true);
			}
		}
		
		if (WELCOMEMESSAGE_DEFAULT_ENABLE == 1 && WELCOMEMESSAGE_DEFAULT_MESSAGE != null)
		{
			if (!isMessageLengthValid(WELCOMEMESSAGE_DEFAULT_MESSAGE_MODE, WELCOMEMESSAGE_DEFAULT_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Default Welcome Message is to long! Make sure that "+WELCOMEMESSAGE_DEFAULT_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(WELCOMEMESSAGE_DEFAULT_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+WELCOMEMESSAGE_FILE, true);
			}
		}
		
		if (WELCOMEMESSAGE_ENABLE == 1 && WELCOMEMESSAGE_MESSAGE != null)
		{
			if (!isMessageLengthValid(WELCOMEMESSAGE_MESSAGE_MODE, WELCOMEMESSAGE_MESSAGE))
			{
				addLogEntry("MESSAGE_WARNING", "Welcome Message is to long! Make sure that "+WELCOMEMESSAGE_MESSAGE_MODE+" messages are not longer than "+Short.toString(getMaxMessageLength(WELCOMEMESSAGE_MESSAGE_MODE))+" characters (including spaces and BBCode), check file: "+WELCOMEMESSAGE_FILE, true);
			}
		}
	}
	
	private boolean getChannelNames()
	{
		Vector<HashMap<String, String>> channelList = queryLib.getList(JTS3ServerQuery.LISTMODE_CHANNELLIST, "-flags");
		
		if (channelList == null)
		{
			addLogEntry("CHANNELLIST_ERROR", "Critical: Error while getting channel list!", true);
			addLogEntry("CHANNELLIST_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
			return false;
		}
		
		for (HashMap<String, String> hashMap : channelList)
		{
			if (hashMap.get("channel_flag_default").equals("1"))
			{
				DEFAULT_CHANNEL_ID = Integer.parseInt(hashMap.get("cid"));
			}
			
			if (IDLE_CHECK_ENABLE == 2)
			{
				if (Integer.parseInt(hashMap.get("cid")) == IDLE_MOVE_CHANNELID)
				{
					IDLE_CHANNEL_NAME = hashMap.get("channel_name");
				}
			}
			
			if (RECORD_CHECK_ENABLE == 2)
			{
				if (Integer.parseInt(hashMap.get("cid")) == RECORD_MOVE_CHANNELID)
				{
					RECORD_CHANNEL_NAME = hashMap.get("channel_name");
				}
			}
			
			if (ADVERTISING_ENABLE == 2)
			{
				if (Integer.parseInt(hashMap.get("cid")) == ADVERTISING_CHANNELID)
				{
					ADVERTISING_CHANNEL_NAME = hashMap.get("channel_name");
				}
			}
			
			if (AWAY_CHECK_ENABLE == 1 || AWAY_CHECK_ENABLE == 2)
			{
				if (Integer.parseInt(hashMap.get("cid")) == AWAY_MOVE_CHANNELID)
				{
					AWAY_CHANNEL_NAME = hashMap.get("channel_name");
				}
			}
			
			if (MUTE_CHECK_ENABLE == 1 || MUTE_CHECK_ENABLE == 2)
			{
				if (Integer.parseInt(hashMap.get("cid")) == MUTE_MOVE_CHANNELID)
				{
					MUTE_CHANNEL_NAME = hashMap.get("channel_name");
				}
			}
		}
		
		if (IDLE_CHECK_ENABLE == 2 && IDLE_CHANNEL_NAME == null)
		{
			addLogEntry("IDLE_CHANNEL", "Warning: Idle check channel ID " + Integer.toString(IDLE_MOVE_CHANNELID) + " does not exist! Idle check disabled!", true);
			IDLE_CHECK_ENABLE = 0;
		}
		
		if (RECORD_CHECK_ENABLE == 2 && RECORD_CHANNEL_NAME == null)
		{
			addLogEntry("RECORD_CHANNEL", "Warning: Record check channel ID " + Integer.toString(RECORD_MOVE_CHANNELID) + " does not exist! Record check disabled!", true);
			RECORD_CHECK_ENABLE = 0;
		}
		
		if (ADVERTISING_ENABLE == 2 && ADVERTISING_CHANNEL_NAME == null)
		{
			addLogEntry("ADVERTISING_CHANNEL", "Warning: Advertising channel ID " + Integer.toString(ADVERTISING_CHANNELID) + " does not exist! Advertising disabled!", true);
			ADVERTISING_ENABLE = 0;
		}
		
		if ((AWAY_CHECK_ENABLE == 1 || AWAY_CHECK_ENABLE == 2) && AWAY_CHANNEL_NAME == null)
		{
			addLogEntry("AWAY_CHANNEL", "Warning: Away check channel ID " + Integer.toString(AWAY_MOVE_CHANNELID) + " does not exist! Away check disabled!", true);
			AWAY_CHECK_ENABLE = 0;
		}
		
		if ((MUTE_CHECK_ENABLE == 1 || MUTE_CHECK_ENABLE == 2) && MUTE_CHANNEL_NAME == null)
		{
			addLogEntry("MUTE_CHANNEL", "Warning: Mute check channel ID " + Integer.toString(MUTE_MOVE_CHANNELID) + " does not exist! Mute check disabled!", true);
			MUTE_CHECK_ENABLE = 0;
		}
		
		return true;
	}
	
	private void outputStartMSG()
	{	
		String msg;
		
		if (WELCOMEMESSAGE_DEFAULT_ENABLE == 1)
		{
			msg = "All new connecting clients get the default welcome message";
			addLogEntry("DEFAULT_WELCOMEMESSAGE_MODE", msg, true);
		}
		
		if (WELCOMEMESSAGE_ENABLE == 1)
		{
			StringBuffer groupTmp = new StringBuffer();
			for (int groupID : WELCOMEMESSAGE_GROUPS)
			{
				if (groupTmp.length() != 0)
				{
					groupTmp.append(", ");
				}
				
				groupTmp.append(groupID);
			}
			
			msg = "New connecting clients of selected server groups (id: " + groupTmp.toString() + ") get the special welcome message";
			addLogEntry("WELCOMEMESSAGE_MODE", msg, true);
		}
		
		if (RECORD_CHECK_ENABLE == 1)
		{
			msg = "Client get kicked from Server after start recording" + (RECORD_COMPLAINADD ? " (complaint will be added)" : "");
			addLogEntry("RECORD_MODE", msg, true);
			
			listOptions.set(LIST_GROUPS);
			listOptions.set(LIST_VOICE);
		}
		
		if (RECORD_CHECK_ENABLE == 2)
		{
			msg = "Clients will be moved into Channel \"" + RECORD_CHANNEL_NAME + "\" (" + Integer.toString(RECORD_MOVE_CHANNELID) + ") after start recording" + (RECORD_COMPLAINADD ? " (complaint will be added)" : "");
			addLogEntry("RECORD_MODE", msg, true);
			
			listOptions.set(LIST_GROUPS);
			listOptions.set(LIST_VOICE);
		}
		
		if (ADVERTISING_ENABLE == 1)
		{
			msg = "Advertising will be send to virtual server every " + Integer.toString(ADVERTISING_INTERVAL) + " minutes (" + ADVERTISING_MESSAGES.size() + " messages found)";
			addLogEntry("ADVERTISING_MODE", msg, true);
		}
		
		if (ADVERTISING_ENABLE == 2)
		{
			msg = "Advertising will be send to channel \"" + ADVERTISING_CHANNEL_NAME + "\" (" + Integer.toString(ADVERTISING_CHANNELID) + ") every " + Integer.toString(ADVERTISING_INTERVAL) + " minutes (" + ADVERTISING_MESSAGES.size() + " messages found)";
			addLogEntry("ADVERTISING_MODE", msg, true);
		}
		
		if (IDLE_CHECK_ENABLE == 1)
		{
			msg = "Clients will be kicked from server after being idle for " + Long.toString((IDLE_MAX_TIME / 1000) / 60) + " minutes" + (IDLE_MIN_CLIENTS > 0 ? " (if min " + Integer.toString(IDLE_MIN_CLIENTS) + " clients online)" : "");
			addLogEntry("IDLE_MODE", msg, true);
			
			listOptions.set(LIST_GROUPS);
			listOptions.set(LIST_TIMES);
		}

		if (IDLE_CHECK_ENABLE == 2)
		{
			msg = "Clients will be moved into Channel \"" + IDLE_CHANNEL_NAME + "\" (" + Integer.toString(IDLE_MOVE_CHANNELID) + ") after being idle for " + Long.toString((IDLE_MAX_TIME / 1000) / 60) + " minutes" + (IDLE_MIN_CLIENTS > 0 ? " (if min " + Integer.toString(IDLE_MIN_CLIENTS) + " clients online)" : "") + (IDLE_MOVE_BACK ? ". Clients will be moved back, if not idle anymore." : ".");
			addLogEntry("IDLE_MODE", msg, true);
			
			listOptions.set(LIST_GROUPS);
			listOptions.set(LIST_TIMES);
			
			if (IDLE_MOVE_BACK)
			{
				listOptions.set(LIST_VOICE);
				listOptions.set(LIST_AWAY);
			}
		}
		
		if (IDLE_CHECK_ENABLE == 2 && IDLE_SECOND_MAX_TIME > 0)
		{
			msg = "Clients will be kicked from server after being idle for " + Long.toString((IDLE_SECOND_MAX_TIME / 1000) / 60) + " minutes" + (IDLE_MIN_CLIENTS > 0 ? " (if min " + Integer.toString(IDLE_MIN_CLIENTS) + " clients online)" : "");
			addLogEntry("IDLE_MODE", msg, true);
		}
		
		if ((IDLE_CHECK_ENABLE == 1 || IDLE_CHECK_ENABLE == 2) && IDLE_WARN_TIME > 0)
		{
			msg = "Clients get a warning message after being idle for " + Long.toString((IDLE_WARN_TIME / 1000) / 60) + " minutes";
			addLogEntry("IDLE_WARN_MODE", msg, true);
		}
		
		if (AWAY_CHECK_ENABLE == 1 || AWAY_CHECK_ENABLE == 2)
		{
			msg = "Clients with away status will be moved to Channel \"" + AWAY_CHANNEL_NAME + "\" (" + Integer.toString(AWAY_MOVE_CHANNELID) + ") after " + AWAY_MOVE_DELAY + " seconds" + (AWAY_CHECK_ENABLE == 2 ? " and moved back if not away anymore!" : "");
			addLogEntry("AWAY_MODE", msg, true);
			
			listOptions.set(LIST_AWAY);
			listOptions.set(LIST_GROUPS);
			listOptions.set(LIST_TIMES);
		}
		
		if ((MUTE_MOVE_HEADPHONE || MUTE_MOVE_MICROPHONE || MUTE_MOVE_HEADPHONE_HARDWARE || MUTE_MOVE_MICROPHONE_HARDWARE) && (MUTE_CHECK_ENABLE == 1 || MUTE_CHECK_ENABLE == 2))
		{
			String extmsg = "";
			if ((MUTE_MOVE_HEADPHONE || MUTE_MOVE_HEADPHONE_HARDWARE) && (MUTE_MOVE_MICROPHONE || MUTE_MOVE_MICROPHONE_HARDWARE))
			{
				extmsg = "headphone or microphone";
			}
			else if (MUTE_MOVE_HEADPHONE || MUTE_MOVE_HEADPHONE_HARDWARE)
			{
				extmsg = "headphone";
			}
			else if (MUTE_MOVE_MICROPHONE || MUTE_MOVE_MICROPHONE_HARDWARE)
			{
				extmsg = "microphone";
			}
			
			msg = "Clients with " + extmsg + " muted will be moved to Channel \"" + MUTE_CHANNEL_NAME + "\" (" + Integer.toString(MUTE_MOVE_CHANNELID) + ") after " + MUTE_MOVE_DELAY + " seconds" + (MUTE_CHECK_ENABLE == 2 ? " and moved back if not muted anymore!" : "");
			addLogEntry("MUTE_MODE", msg, true);
			
			listOptions.set(LIST_GROUPS);
			listOptions.set(LIST_VOICE);
			listOptions.set(LIST_TIMES);
		}
		
		if (BADNICKNAME_CHECK_ENABLE == 1)
		{
			msg = "Bad Nickname Check is enabled, " + Integer.toString(BADNICKNAME_RULES.size()) + " rules loaded" + (BADNICKNAME_COMPLAINADD ? " (complaint will be added)" : "");
			addLogEntry("BADNICKNAME_MODE", msg, true);
			
			listOptions.set(LIST_GROUPS);
		}
		
		if (BADCHANNELNAME_CHECK_ENABLE == 1)
		{
			msg = "Bad Channel Name Check is enabled, " + Integer.toString(BADCHANNELNAME_RULES.size()) + " rules loaded";
			addLogEntry("BADCHANNELNAME_MODE", msg, true);
		}
		
		if (SERVERGROUPPROTECTION_ENABLE == 1)
		{
			StringBuffer sb = new StringBuffer();
			for (int groupID : SERVERGROUPPROTECTION_GROUPS)
			{
				if (sb.length() != 0)
				{
					sb.append(", ");
				}
				
				sb.append(groupID);
			}
			
			msg = "Server Group Protection will remove not allowed members from protected server groups (id: " + sb.toString() + ")" + (SERVERGROUPPROTECTION_KICK ? " and kick them" : " but they will not kicked") + (SERVERGROUPPROTECTION_COMPLAINADD ? " (complaint will be added)" : "");
			addLogEntry("SERVERGROUPPROTECTION_MODE", msg, true);
			
			listOptions.set(LIST_GROUPS);
			listOptions.set(LIST_UID);
		}

		if (SERVERGROUPNOTIFY_ENABLE == 1)
		{
			StringBuffer groupTmp = new StringBuffer();
			for (int groupID : SERVERGROUPNOTIFY_GROUPS)
			{
				if (groupTmp.length() != 0)
				{
					groupTmp.append(", ");
				}
				
				groupTmp.append(groupID);
			}
			
			StringBuffer groupTmp2 = new StringBuffer();
			for (int groupID : SERVERGROUPNOTIFY_GROUPTARGETS)
			{
				if (groupTmp2.length() != 0)
				{
					groupTmp2.append(", ");
				}
				
				groupTmp2.append(groupID);
			}
			
			msg = "Watching for new connecting clients of selected server groups (id: " + groupTmp.toString() + "), sending message to all online clients of server group ids: " + groupTmp2.toString();
			addLogEntry("SERVERGROUPNOTIFY_MODE", msg, true);
			
			listOptions.set(LIST_GROUPS);
		}
		
		if (AUTOMOVE_ENABLE == 1)
		{
			msg = "Auto Move is enabled, default channels for " + Integer.toString(AUTOMOVE_SGCHANNEL_LIST.size()) + " server groups set";
			addLogEntry("AUTOMOVE_MODE", msg, true);
		}
	}
	
	private void createListArguments()
	{
		listArguments = "";
		for (int i = listOptions.nextSetBit(0); i >= 0; i = listOptions.nextSetBit(i+1))
		{
			if (listArguments.equals(""))
			{
				listArguments += LIST_OPTIONS[i];
			}
			else
			{
				listArguments += "," + LIST_OPTIONS[i];
			}
		}
	}
	
	void runThread()
	{
		Thread t = new Thread(new Runnable()
		{
			public void run()
			{
				do
				{
					if (reloadState == 2)
					{
						initVars();
						runMod();
					}
					
					try
					{
						Thread.sleep(100);
					}
					catch (Exception e)
					{
					}
				}
				while (reloadState != 0);
				
				addLogEntry("STOP_MOD", "Virtual bot instance \"" + instanceName + "\" stopped", true);
			}
		});
		t.setName(instanceName);
		t.start();
	}
	
	private void runMod()
	{
		reloadState = 1;
		startTime = System.currentTimeMillis();
		addLogEntry("START_MOD", "Virtual bot instance \"" + instanceName + "\" starts now" + (DEBUG ? " - Debug mode activated!" : ""), true);
		int configOK = loadAndCheckConfig(true);
		
		if (configOK != 0)
		{
			addLogEntry("START_ERROR", getErrorMessage(configOK), true);
			stopBotInstance(0);
			return;
		}
		
		if (SLOW_MODE)
		{
			addLogEntry("START_INFO", "Slow mode activated (using less commands at once)", true);
		}
		
		if (!queryLib.connectTS3Query(TS3_ADDRESS, TS3_QUERY_PORT))
		{
			addLogEntry("START_ERROR", "Critical: Unable to connect to Teamspeak 3 server at " + TS3_ADDRESS + "!", true);
			addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);

			reconnectBot(false);
			return;
		}
		else
		{
			addLogEntry("START_INFO", "Successful connected to " + TS3_ADDRESS + "!", true);
		}
		
		if (!queryLib.loginTS3(TS3_LOGIN, TS3_PASSWORD))
		{
			addLogEntry("START_ERROR", "Critical: Unable to login as \"" + TS3_LOGIN + "\"! Maybe this IP address is banned for some minutes on that server!", true);
			addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
			stopBotInstance(0);
			return;
		}
		else
		{
			addLogEntry("START_INFO", "Login as \"" + TS3_LOGIN + "\" successful!", true);
		}
		
		permissionListCache = queryLib.getList(JTS3ServerQuery.LISTMODE_PERMISSIONLIST);
		if (permissionListCache == null)
		{
			addLogEntry("PERMISSION_CACHE", "Warning: Unable to receive permission list! If wanted, set permission b_serverinstance_permission_list.", true);
			addLogEntry("PERMISSION_CACHE", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), false);
		}
		
		if (SLOW_MODE)
		{
			try
			{
				Thread.sleep(3000);
			}
			catch (Exception e)
			{
			}
			
			if (botTimer == null)
			{
				return;
			}
		}
		
		if (TS3_VIRTUALSERVER_ID >= 1)
		{
			if (!queryLib.selectVirtualServer(TS3_VIRTUALSERVER_ID, false))
			{
				addLogEntry("START_ERROR", "Critical: Unable to select virtual server " + Integer.toString(TS3_VIRTUALSERVER_ID) + "!", true);
				addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
				
				reconnectBot(false);
				return;
			}
			else
			{
				addLogEntry("START_INFO", "Successful selected virtual server " + Integer.toString(TS3_VIRTUALSERVER_ID) + "!", true);
			}
		}
		else
		{
			if (!queryLib.selectVirtualServer(TS3_VIRTUALSERVER_PORT, true))
			{
				addLogEntry("START_ERROR", "Critical: Unable to select virtual server on port " + Integer.toString(TS3_VIRTUALSERVER_PORT) + "!", true);
				addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
				
				reconnectBot(false);
				return;
			}
			else
			{
				addLogEntry("START_INFO", "Successful selected virtual server on port " + Integer.toString(TS3_VIRTUALSERVER_PORT) + "!", true);
			}
		}
		
		if (!queryLib.setDisplayName(SERVER_QUERY_NAME))
		{
			addLogEntry("START_ERROR", "Warning: Unable to change name to \"" + SERVER_QUERY_NAME + "\"!", true);
			addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
			if (SERVER_QUERY_NAME_2 != null && SERVER_QUERY_NAME_2.length() >=3)
			{
				addLogEntry("START_INFO", "Try using \"" + SERVER_QUERY_NAME_2 + "\"...", true);
				if (!queryLib.setDisplayName(SERVER_QUERY_NAME_2))
				{
					addLogEntry("START_ERROR", "Warning: Unable to change name to \"" + SERVER_QUERY_NAME_2 + "\"!", true);
					addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
				}
			}
		}
		
		if (SLOW_MODE)
		{
			try
			{
				Thread.sleep(3000);
			}
			catch (Exception e)
			{
			}
			
			if (botTimer == null)
			{
				return;
			}
		}
		
		if (BOT_CHANNEL_ID > 0)
		{
			if (queryLib.getCurrentQueryClientID() == -1) reconnectBot(false);
			
			if (!queryLib.moveClient(queryLib.getCurrentQueryClientID(), BOT_CHANNEL_ID, null))
			{
				addLogEntry("START_ERROR", "Warning: Unable to switch channel (own client ID: " + Integer.toString(queryLib.getCurrentQueryClientID()) + ")!", true);
				addLogEntry("START_ERROR", "Notice: If channel ID " + Integer.toString(BOT_CHANNEL_ID) + " is the default channel, use -1 in bot config!", true);
				addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
			}
		}
		
		if (SLOW_MODE)
		{
			try
			{
				Thread.sleep(3000);
			}
			catch (Exception e)
			{
			}
			
			if (botTimer == null)
			{
				return;
			}
		}
		
		queryLib.setTeamspeakActionListener(this);
		
		if (WELCOMEMESSAGE_ENABLE == 1 || WELCOMEMESSAGE_DEFAULT_ENABLE == 1 || SERVERGROUPNOTIFY_ENABLE == 1 || AUTOMOVE_ENABLE == 1)
		{
			if (!queryLib.addEventNotify(JTS3ServerQuery.EVENT_MODE_SERVER, 0))
			{
				addLogEntry("START_ERROR", "Warning: Unable to see joining players! Welcome message, server group notify and auto move disabled!", true);
				addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
				WELCOMEMESSAGE_ENABLE = 0;
				WELCOMEMESSAGE_DEFAULT_ENABLE = 0;
				SERVERGROUPNOTIFY_ENABLE = 0;
				AUTOMOVE_ENABLE = 0;
			}
			else
			{
				if (WELCOMEMESSAGE_ENABLE == 1 || WELCOMEMESSAGE_DEFAULT_ENABLE == 1) serverInfoCache = new ServerInfoCache();
				if (SERVERGROUPNOTIFY_ENABLE == 1 || SERVERGROUPPROTECTION_ENABLE == 1)
				{
					timerServerGroupListCache = new TimerTask()
					{
						public void run()
						{
							updateServerGroupListCache = true;
						}
					};
					botTimer.schedule(timerServerGroupListCache, 6*60*1000, 10*60*1000);
					updateServerGroupListCache = true;
				}
			}
		}
		
		if (!queryLib.addEventNotify(JTS3ServerQuery.EVENT_MODE_TEXTCHANNEL, 0))
		{
			addLogEntry("START_ERROR", "Warning: Unable to receive channel chat messages!", true);
			addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
		}
		if (!queryLib.addEventNotify(JTS3ServerQuery.EVENT_MODE_TEXTPRIVATE, 0))
		{
			addLogEntry("START_ERROR", "Warning: Unable to receive private chat messages!", true);
			addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
		}
		
		if (SLOW_MODE)
		{
			try
			{
				Thread.sleep(3000);
			}
			catch (Exception e)
			{
			}
			
			if (botTimer == null)
			{
				return;
			}
		}
		
		if (!queryLib.addEventNotify(JTS3ServerQuery.EVENT_MODE_TEXTSERVER, 0))
		{
			addLogEntry("START_ERROR", "Warning: Unable to receive private chat messages!", true);
			addLogEntry("START_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
		}
		
		if (!getChannelNames())
		{
			reconnectBot(false);
			return;
		}
		
		if (SLOW_MODE)
		{
			try
			{
				Thread.sleep(3000);
			}
			catch (Exception e)
			{
			}
			
			if (botTimer == null)
			{
				return;
			}
		}
		
		if (!SLOW_MODE)
		{
			serverGroupListCache = queryLib.getList(JTS3ServerQuery.LISTMODE_SERVERGROUPLIST);
		}
		
		outputStartMSG();
		createListArguments();
		createMessages();
		
		if (CLIENT_DATABASE_CACHE)
		{
			clientCache = new ClientDatabaseCache(queryLib, this);
		}
		
		chatCommands = new ChatCommands(queryLib, this, clientCache, sdf, config, manager);
		
		timerCheck = new TimerTask()
		{
			public void run()
			{
				runCheck();
			}
		};
		botTimer.schedule(timerCheck, CHECK_INTERVAL*1000);
		
		if (serverInfoCache != null)
		{
			timerServerInfoCache = new TimerTask()
			{
				public void run()
				{
					updateServerInfoCache = true;
				}
			};
			botTimer.schedule(timerServerInfoCache, 10*60*1000, 10*60*1000);
			updateServerInfoCache = true;
		}
		
		addLogEntry("START_SUCCESSFUL", "Bot started and connected successful, write !botinfo in server chat to get an answer!", true);
	}
	
	private void reconnectBot(boolean force)
	{
		if (RECONNECT_FOREVER || force)
		{
			prepareStopBot();
			
			addLogEntry("RECONNECT_INFO", "Reconnecting in " + Integer.toString(reconnectTime / 1000) + " seconds...", true);

			timerReconnect = new TimerTask()
			{
				public void run()
				{
					if (botTimer != null) botTimer.cancel();
					botTimer = null;
					reloadState = 2;
				}
			};
			botTimer.schedule(timerReconnect, reconnectTime);
			return;
		}
		else
		{
			stopBotInstance(0);
			return;
		}
	}
	
	private void prepareStopBot()
	{
		if (timerCheck != null) timerCheck.cancel();
		timerCheck = null;
		if (clientCache != null) clientCache.stopUpdating();
		clientCache = null;
		if (timerAdvertising != null) timerAdvertising.cancel();
		timerAdvertising = null;
		if (timerServerInfoCache != null) timerServerInfoCache.cancel();
		timerServerInfoCache = null;
		queryLib.removeTeamspeakActionListener();
		queryLib.closeTS3Connection();
	}
	
	void stopBotInstance(int mode)
	{
		if (mode == 2) addLogEntry("RESTART_MOD", "Virtual bot instance \"" + instanceName + "\" restarts", true);
		
		prepareStopBot();
		if (timerReconnect != null) timerReconnect.cancel();
		timerReconnect = null;
		if (botTimer != null) botTimer.cancel();
		botTimer = null;
		reloadState = mode;
		
		if (mode == 0)
		{
			manager.removeInstance(this);
		}
	}
	
	private void checkTS3Clients()
	{
		if (!queryLib.isConnected())
		{
			String msg = "Connection to Teamspeak 3 server lost...";
			addLogEntry("CONNECTION_LOST", msg, true);
			
			reconnectBot(true);
			return;
		}
		
		if (CLIENT_DATABASE_CACHE || ADVERTISING_ENABLE == 1 || ADVERTISING_ENABLE == 2 || RECORD_CHECK_ENABLE == 1 || RECORD_CHECK_ENABLE == 2 || IDLE_CHECK_ENABLE == 1 || IDLE_CHECK_ENABLE == 2 || AWAY_CHECK_ENABLE == 1 || AWAY_CHECK_ENABLE == 2 || MUTE_CHECK_ENABLE == 1 || MUTE_CHECK_ENABLE == 2 || SERVERGROUPPROTECTION_ENABLE == 1 || BADNICKNAME_CHECK_ENABLE == 1 || SERVERGROUPNOTIFY_ENABLE == 1)
		{
			clientList = queryLib.getList(JTS3ServerQuery.LISTMODE_CLIENTLIST, listArguments);
			if (clientList == null)
			{
				addLogEntry("CLIENTLIST_ERROR", "Critical: Error while getting client list!", true);
				addLogEntry("CLIENTLIST_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
				
				reconnectBot(true);
				return;
			}
			
			if (clientCache != null) clientCache.updateClientList(clientList);
			if (serverInfoCache != null) serverInfoCache.updateClientCount(clientList);
			
			for (HashMap<String, String> clientInfo : clientList)
			{
				if (clientInfo.get("client_type").equals("0"))
				{
					int clientID = Integer.parseInt(clientInfo.get("clid"));
					
					if (updateServerInfoCache)
					{
						handleServerInfoCacheUpdate();
					}
					
					if (updateServerGroupListCache)
					{
						handleServerGroupListCacheUpdate();
					}
					
					if (IDLE_CHECK_ENABLE == 1 || IDLE_CHECK_ENABLE == 2)
					{
						handleIdleUser(clientID, clientInfo, clientList.size());
					}
					
					if (AWAY_CHECK_ENABLE == 1 || AWAY_CHECK_ENABLE == 2)
					{
						handleAwayUser(clientID, clientInfo);
					}
					
					if (MUTE_CHECK_ENABLE == 1 || MUTE_CHECK_ENABLE == 2)
					{
						handleMuteUser(clientID, clientInfo);
					}
					
					if (RECORD_CHECK_ENABLE == 1 || RECORD_CHECK_ENABLE == 2)
					{
						handleRecordUser(clientID, clientInfo);
					}
					
					if (ADVERTISING_ENABLE == 1 || ADVERTISING_ENABLE == 2)
					{
						handleAdvertising();
					}
					
					if (BADNICKNAME_CHECK_ENABLE == 1)
					{
						handleBadNickname(clientID, clientInfo);
					}
					
					if (SERVERGROUPPROTECTION_ENABLE == 1)
					{
						handleServerGroupProtection(clientID, clientInfo);
					}
				}
			}
			
			if ((IDLE_CHECK_ENABLE == 1 || IDLE_CHECK_ENABLE == 2) && IDLE_WARN_TIME > 0)
			{
				IDLE_CLIENTS_WARN_SENT.clear();
				IDLE_CLIENTS_WARN_SENT.addAll(idleClientsWarnSentTemp);
				idleClientsWarnSentTemp.clear();
			}
			
			if (IDLE_CHECK_ENABLE == 2 && IDLE_MOVE_BACK)
			{
				boolean found;
				for (int i=0; i<IDLE_CLIENTS_MOVED.size(); i++)
				{
					found = false;
					for (HashMap<String, String> hashMap : clientList)
					{
						if (Integer.parseInt(hashMap.get("clid")) == IDLE_CLIENTS_MOVED.elementAt(i))
						{
							found = true;
							break;
						}
					}
					
					if (!found)
					{
						IDLE_CLIENTS_MOVED.removeElementAt(i);
						IDLE_CLIENTS_MOVED_CHANNEL.removeElementAt(i);
					}
				}
			}
			
			if (AWAY_CHECK_ENABLE == 2)
			{
				boolean found;
				for (int i=0; i<AWAY_CLIENTS_MOVED.size(); i++)
				{
					found = false;
					for (HashMap<String, String> hashMap : clientList)
					{
						if (Integer.parseInt(hashMap.get("clid")) == AWAY_CLIENTS_MOVED.elementAt(i))
						{
							found = true;
							break;
						}
					}
					
					if (!found)
					{
						AWAY_CLIENTS_MOVED.removeElementAt(i);
						AWAY_CLIENTS_MOVED_CHANNEL.removeElementAt(i);
					}
				}
			}
			
			if (MUTE_CHECK_ENABLE == 2)
			{
				boolean found;
				for (int i=0; i<MUTE_CLIENTS_MOVED.size(); i++)
				{
					found = false;
					for (HashMap<String, String> hashMap : clientList)
					{
						if (Integer.parseInt(hashMap.get("clid")) == MUTE_CLIENTS_MOVED.elementAt(i))
						{
							found = true;
							break;
						}
					}
					
					if (!found)
					{
						MUTE_CLIENTS_MOVED.removeElementAt(i);
						MUTE_CLIENTS_MOVED_CHANNEL.removeElementAt(i);
					}
				}
			}
		}
		
		if (BADCHANNELNAME_CHECK_ENABLE == 1)
		{
			handleBadChannelName();
		}
	}
	
	private void handleServerGroupProtection(int clientID, HashMap<String, String> clientInfo)
	{
		if (DEBUG) System.out.println("handleServerGroupProtection() Checking client id " + clientID);
		
		StringTokenizer groupTokenizer = new StringTokenizer(clientInfo.get("client_servergroups"), ",", false);
		int groupID = -1;
		String sgpMessage = "";
		Vector<Integer> clientHasGroups = new Vector<Integer>();
		HashMap<String, String> response;
		
		while (groupTokenizer.hasMoreTokens())
		{
			groupID = Integer.parseInt(groupTokenizer.nextToken());
			clientHasGroups.addElement(groupID);
			
			for (int i=0; i<SERVERGROUPPROTECTION_GROUPS.size(); i++)
			{
				if (groupID == SERVERGROUPPROTECTION_GROUPS.elementAt(i))
				{
					if (SERVERGROUPPROTECTION_CLIENTS.elementAt(i).indexOf(clientInfo.get("client_unique_identifier")) == -1)
					{
						response = queryLib.doCommand("servergroupdelclient sgid=" + Integer.toString(groupID) + " cldbid=" + clientInfo.get("client_database_id"));
						if (response.get("id").equals("0"))
						{
							addLogEntry("SERVERGROUPPROTECTION_REMOVE_GROUP", clientInfo, groupID, false);
						}
						else
						{
							int permissionID = -1;
							try { if (response.get("failed_permid") != null) permissionID = Integer.parseInt(response.get("failed_permid")); } catch (Exception e) {}
							addLogEntry("SERVERGROUPPROTECTION_REMOVE_GROUP_ERROR", clientInfo, groupID, false);
							addLogEntry("SERVERGROUPPROTECTION_REMOVE_GROUP_ERROR", "ServerQuery Error " + response.get("id") + ": " + response.get("msg") + (response.get("failed_permid") == null ? "" : " - Permission ID: " + response.get("failed_permid")), permissionID, false);
						}
						
						if (SERVERGROUPPROTECTION_COMPLAINADD) addComplainToUser("Not allowed server group (id: " + Integer.toString(groupID) + "): " + clientInfo.get("client_nickname"), "SERVERGROUPPROTECTION_COMPLAINADD", clientInfo);
						
						String sgName = getServerGroupName(groupID);
						sgpMessage = new String(SERVERGROUPPROTECTION_MESSAGE);
						sgpMessage = sgpMessage.replace("%SERVER_GROUP_ID%", Integer.toString(groupID));
						sgpMessage = sgpMessage.replace("%SERVER_GROUP_NAME%", (sgName == null ? "Unknown" : sgName));
						if (SERVERGROUPPROTECTION_KICK)
						{
							if (!queryLib.kickClient(clientID, false, sgpMessage))
							{
								addLogEntry("KICK_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
							}
							else
							{
								addLogEntry("SERVERGROUPPROTECTION_KICK", clientInfo, false);
							}
						}
						else
						{
							sendMessageToClient(SERVERGROUPPROTECTION_MESSAGE_MODE, clientID, sgpMessage);
						}
					}
				}
			}
		}
		
		if (SERVERGROUPPROTECTION_ADD_MISSING_GROUPS)
		{
			for (int i=0; i<SERVERGROUPPROTECTION_GROUPS.size(); i++)
			{
				if (SERVERGROUPPROTECTION_CLIENTS.elementAt(i).indexOf(clientInfo.get("client_unique_identifier")) != -1)
				{
					if (clientHasGroups.indexOf(SERVERGROUPPROTECTION_GROUPS.elementAt(i)) == -1)
					{
						response = queryLib.doCommand("servergroupaddclient sgid=" + Integer.toString(SERVERGROUPPROTECTION_GROUPS.elementAt(i)) + " cldbid=" + clientInfo.get("client_database_id")); 
						if (response.get("id").equals("0"))
						{
							addLogEntry("SERVERGROUPPROTECTION_ADD_GROUP", clientInfo, SERVERGROUPPROTECTION_GROUPS.elementAt(i), false);
						}
						else
						{
							int permissionID = -1;
							try { if (response.get("failed_permid") != null) permissionID = Integer.parseInt(response.get("failed_permid")); } catch (Exception e) {}
							addLogEntry("SERVERGROUPPROTECTION_ADD_GROUP_ERROR", clientInfo, SERVERGROUPPROTECTION_GROUPS.elementAt(i), false);
							addLogEntry("SERVERGROUPPROTECTION_ADD_GROUP_ERROR", "ServerQuery Error " + response.get("id") + ": " + response.get("msg") + (response.get("failed_permid") == null ? "" : " - Permission ID: " + response.get("failed_permid")), permissionID, false);
						}
					}
				}
			}
		}
	}
	
	private void handleBadChannelName()
	{
		if (DEBUG) System.out.println("handleBadChannelName() Checking channel list...");
		
		Matcher ruleCheck;
		int channelID;
		Vector<HashMap<String, String>> channelList = queryLib.getList(JTS3ServerQuery.LISTMODE_CHANNELLIST);
		if (channelList == null)
		{
			addLogEntry("CHANNELLIST_ERROR", "Critical: Error while getting channel list!", true);
			addLogEntry("CHANNELLIST_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), true);
			
			reconnectBot(true);
			return;
		}
		
		for (HashMap<String, String> channel : channelList)
		{
			try
			{
				channelID = Integer.parseInt(channel.get("cid"));
				if (!isIDListed(channelID, BADCHANNELNAME_CHANNEL_LIST))
				{
					for (Pattern rule : BADCHANNELNAME_RULES)
					{
						ruleCheck = rule.matcher(channel.get("channel_name"));
						if (ruleCheck.matches())
						{
							if (!queryLib.deleteChannel(channelID, true))
							{
								addLogEntry("CHANNELDELETE_ERROR", queryLib.getLastError() + " - Channel ID: " + Integer.toString(channelID), queryLib.getLastErrorPermissionID(), false);
							}
							else
							{
								addLogEntry("BADCHANNELNAME_DELETE", "Channel was deleted, name: " + channel.get("channel_name"), false);
							}
						}
					}
				}
			}
			catch (Exception e)
			{
				addLogEntry("BADCHANNELNAME_ERROR", "Problem getting channel ID of channel name: " + channel.get("channel_name"), false);
			}
		}
	}
	
	private void handleBadNickname(int clientID, HashMap<String, String> clientInfo)
	{
		if (DEBUG) System.out.println("handleBadNickname() Checking client id " + clientID);
		
		boolean result = isGroupListed(clientInfo.get("client_servergroups"), BADNICKNAME_GROUP_LIST);
		if ((BADNICKNAME_GROUP_LIST_IGNORE ? !result : result))
		{
			Matcher ruleCheck;
			for (Pattern rule : BADNICKNAME_RULES)
			{
				ruleCheck = rule.matcher(clientInfo.get("client_nickname"));
				if (ruleCheck.matches())
				{
					if (BADNICKNAME_COMPLAINADD) addComplainToUser("Bad Nickname: " + clientInfo.get("client_nickname"), "BADNICKNAME_COMPLAINADD", clientInfo);
					
					if (!queryLib.kickClient(clientID, false, BADNICKNAME_KICK_MESSAGE))
					{
						addLogEntry("KICK_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
					}
					else
					{
						addLogEntry("BADNICKNAME_KICK", clientInfo, false);
					}
				}
			}
		}
	}
	
	private void handleAwayUser(int clientID, HashMap<String, String> clientInfo)
	{
		if (DEBUG) System.out.println("handleAwayUser() Checking client id " + clientID);
		
		int cachePos = -1;
		if (AWAY_CHECK_ENABLE == 2)
		{
			cachePos = AWAY_CLIENTS_MOVED.indexOf(clientID);
		}
		
		if (clientInfo.get("client_away").equals("1") && getIdleTime(clientInfo, AWAY_MOVE_CHANNELID) > (AWAY_MOVE_DELAY * 1000))
		{
			if (DEBUG) System.out.println("handleAwayUser() Client id " + clientID + " is away");
			
			int channelID = Integer.parseInt(clientInfo.get("cid"));
			boolean result = isIDListed(channelID, AWAY_CHANNEL_LIST);
			if (channelID != AWAY_MOVE_CHANNELID && (AWAY_CHANNEL_LIST_IGNORE ? !result : result))
			{
				result = isGroupListed(clientInfo.get("client_servergroups"), AWAY_GROUP_LIST);
				if ((AWAY_GROUP_LIST_IGNORE ? !result : result))
				{
					if (!queryLib.moveClient(clientID, AWAY_MOVE_CHANNELID, null))
					{
						addLogEntry("MOVE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
					}
					else
					{
						if (AWAY_CHECK_ENABLE == 2)
						{
							AWAY_CLIENTS_MOVED.addElement(clientID);
							AWAY_CLIENTS_MOVED_CHANNEL.addElement(channelID);
						}
						addLogEntry("AWAY_MOVE", clientInfo, false);
						sendMessageToClient(AWAY_MESSAGE_MODE, clientID, AWAY_MESSAGE);
					}
				}
			}
		}
		else if (cachePos != -1 && clientInfo.get("client_away").equals("0"))
		{
			if (Integer.parseInt(clientInfo.get("cid")) != AWAY_MOVE_CHANNELID)
			{
				AWAY_CLIENTS_MOVED.removeElementAt(cachePos);
				AWAY_CLIENTS_MOVED_CHANNEL.removeElementAt(cachePos);
			}
			else
			{
				if (!queryLib.moveClient(clientID, AWAY_CLIENTS_MOVED_CHANNEL.elementAt(cachePos), null))
				{
					addLogEntry("MOVE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
				}
				else
				{
					AWAY_CLIENTS_MOVED.removeElementAt(cachePos);
					AWAY_CLIENTS_MOVED_CHANNEL.removeElementAt(cachePos);
					addLogEntry("AWAY_MOVE_BACK", clientInfo, false);
				}
			}
		}
	}
	
	private void handleMuteUser(int clientID, HashMap<String, String> clientInfo)
	{
		if (DEBUG) System.out.println("handleMuteUser() Checking client id " + clientID);
		
		int cachePos = -1;
		if (MUTE_CHECK_ENABLE == 2)
		{
			cachePos = MUTE_CLIENTS_MOVED.indexOf(clientID);
		}
		
		if (isClientMuted(clientInfo) && getIdleTime(clientInfo, MUTE_MOVE_CHANNELID) > (MUTE_MOVE_DELAY * 1000))
		{
			if (DEBUG) System.out.println("handleMuteUser() Client id " + clientID + " is muted");
			
			int channelID = Integer.parseInt(clientInfo.get("cid"));
			boolean result = isIDListed(channelID, MUTE_CHANNEL_LIST);
			if (channelID != MUTE_MOVE_CHANNELID && (MUTE_CHANNEL_LIST_IGNORE ? !result : result))
			{
				result = isGroupListed(clientInfo.get("client_servergroups"), MUTE_GROUP_LIST);
				if ((MUTE_GROUP_LIST_IGNORE ? !result : result))
				{
					if (!queryLib.moveClient(clientID, MUTE_MOVE_CHANNELID, null))
					{
						addLogEntry("MOVE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
					}
					else
					{
						if (MUTE_CHECK_ENABLE == 2)
						{
							MUTE_CLIENTS_MOVED.addElement(clientID);
							MUTE_CLIENTS_MOVED_CHANNEL.addElement(channelID);
						}
						addLogEntry("MUTE_MOVE", clientInfo, false);
						sendMessageToClient(MUTE_MESSAGE_MODE, clientID, MUTE_MESSAGE);
					}
				}
			}
		}
		else if (cachePos != -1 && !isClientMuted(clientInfo))
		{
			if (Integer.parseInt(clientInfo.get("cid")) != MUTE_MOVE_CHANNELID)
			{
				MUTE_CLIENTS_MOVED.removeElementAt(cachePos);
				MUTE_CLIENTS_MOVED_CHANNEL.removeElementAt(cachePos);
			}
			else
			{
				if (!queryLib.moveClient(clientID, MUTE_CLIENTS_MOVED_CHANNEL.elementAt(cachePos), null))
				{
					addLogEntry("MOVE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
				}
				else
				{
					MUTE_CLIENTS_MOVED.removeElementAt(cachePos);
					MUTE_CLIENTS_MOVED_CHANNEL.removeElementAt(cachePos);
					addLogEntry("MUTE_MOVE_BACK", clientInfo, false);
				}
			}
		}
	}
	
	private void handleServerInfoCacheUpdate()
	{
		updateServerInfoCache = false;
		if (serverInfoCache != null)
		{
			serverInfoCache.updateServerInfo(queryLib.getInfo(JTS3ServerQuery.INFOMODE_SERVERINFO, -1));
		}
	}
	
	private void handleServerGroupListCacheUpdate()
	{
		updateServerGroupListCache = false;
		serverGroupListCache = queryLib.getList(JTS3ServerQuery.LISTMODE_SERVERGROUPLIST);
	}
	
	private void handleAdvertising()
	{
		if (advertiseNow && ADVERTISING_MESSAGES.size() > 0)
		{
			advertiseNow = false;
			
			if (currentAdvertiseMessage == ADVERTISING_MESSAGES.size())
			{
				currentAdvertiseMessage = 0;
			}
			
			if (ADVERTISING_ENABLE == 1)
			{
				if (!queryLib.sendTextMessage(queryLib.getCurrentQueryClientServerID(), JTS3ServerQuery.TEXTMESSAGE_TARGET_VIRTUALSERVER, ADVERTISING_MESSAGES.elementAt(currentAdvertiseMessage)))
				{
					addLogEntry("ADVERTISING_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), false);
				}
				else
				{
					++currentAdvertiseMessage;
				}
			}
			else if (ADVERTISING_ENABLE == 2)
			{
				if (!queryLib.sendTextMessage(ADVERTISING_CHANNELID, JTS3ServerQuery.TEXTMESSAGE_TARGET_CHANNEL, ADVERTISING_MESSAGES.elementAt(currentAdvertiseMessage)))
				{
					addLogEntry("ADVERTISING_ERROR", queryLib.getLastError(), queryLib.getLastErrorPermissionID(), false);
				}
				else
				{
					++currentAdvertiseMessage;
				}
			}
		}
	}
	
	private void handleRecordUser(int clientID, HashMap<String, String> clientInfo)
	{
		if (DEBUG) System.out.println("handleRecordUser() Checking client id " + clientID);
		
		if (clientInfo.get("client_is_recording").equals("1"))
		{
			if (DEBUG) System.out.println("handleRecordUser() Client id " + clientID + " is recording");
			
			int channelID = Integer.parseInt(clientInfo.get("cid"));
			boolean result = isIDListed(channelID, RECORD_CHANNEL_LIST);
			if (RECORD_CHECK_ENABLE == 1)
			{
				if ((RECORD_CHANNEL_LIST_IGNORE ? !result : result))
				{
					result = isGroupListed(clientInfo.get("client_servergroups"), RECORD_GROUP_LIST);
					if ((RECORD_GROUP_LIST_IGNORE ? !result : result))
					{
						if (RECORD_COMPLAINADD) addComplainToUser("Recording client: " + clientInfo.get("client_nickname"), "RECORD_COMPLAINADD", clientInfo);
						if (!queryLib.kickClient(clientID, false, RECORD_MESSAGE))
						{
							addLogEntry("KICK_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
						}
						else
						{
							addLogEntry("RECORD_KICK", clientInfo, false);
						}
					}
				}
			}
			else if (RECORD_CHECK_ENABLE == 2)
			{
				if (channelID != RECORD_MOVE_CHANNELID && (RECORD_CHANNEL_LIST_IGNORE ? !result : result))
				{
					result = isGroupListed(clientInfo.get("client_servergroups"), RECORD_GROUP_LIST);
					if ((RECORD_GROUP_LIST_IGNORE ? !result : result))
					{
						if (RECORD_COMPLAINADD) addComplainToUser("Recording client: " + clientInfo.get("client_nickname"), "RECORD_COMPLAINADD", clientInfo);
						if (!queryLib.moveClient(clientID, RECORD_MOVE_CHANNELID, null))
						{
							addLogEntry("MOVE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
						}
						else
						{
							addLogEntry("RECORD_MOVE", clientInfo, false);
							sendMessageToClient(RECORD_MESSAGE_MODE, clientID, RECORD_MESSAGE);
						}
					}
				}
			}
		}
	}
	
	private void handleIdleUser(int clientID, HashMap<String, String> clientInfo, int currentClientCount)
	{
		if (DEBUG) System.out.println("handleIdleUser() Checking client id " + clientID);
		
		int cachePos = -1;
		if (IDLE_MOVE_BACK)
		{
			cachePos = IDLE_CLIENTS_MOVED.indexOf(clientID);
		}

		long idleTime = getIdleTime(clientInfo, IDLE_MOVE_CHANNELID);
		if (currentClientCount >= IDLE_MIN_CLIENTS)
		{
			if (idleTime > IDLE_MAX_TIME)
			{
				if (DEBUG) System.out.println("handleIdleUser() Client id " + clientID + " is idle");
				
				int channelID = Integer.parseInt(clientInfo.get("cid"));
				boolean result = isIDListed(channelID, IDLE_CHANNEL_LIST);
				if (IDLE_CHECK_ENABLE == 1)
				{
					if ((IDLE_CHANNEL_LIST_IGNORE ? !result : result))
					{
						result = isGroupListed(clientInfo.get("client_servergroups"), IDLE_GROUP_LIST);
						if ((IDLE_GROUP_LIST_IGNORE ? !result : result))
						{
							if (!queryLib.kickClient(clientID, false, IDLE_MESSAGE))
							{
								addLogEntry("KICK_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), false);
							}
							else
							{
								addLogEntry("IDLE_KICK", clientInfo, false);
							}
						}
					}
				}
				else if (IDLE_CHECK_ENABLE == 2)
				{
					if (IDLE_SECOND_MAX_TIME > 0 && idleTime > IDLE_SECOND_MAX_TIME)
					{
						if ((IDLE_CHANNEL_LIST_IGNORE ? !result : result))
						{
							result = isGroupListed(clientInfo.get("client_servergroups"), IDLE_GROUP_LIST);
							if ((IDLE_GROUP_LIST_IGNORE ? !result : result))
							{
								if (!queryLib.kickClient(clientID, false, IDLE_SECOND_MESSAGE))
								{
									addLogEntry("KICK_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
								}
								else
								{
									addLogEntry("IDLE_KICK", clientInfo, false);
								}
							}
						}
					}
					else if (channelID != IDLE_MOVE_CHANNELID && (IDLE_CHANNEL_LIST_IGNORE ? !result : result))
					{
						result = isGroupListed(clientInfo.get("client_servergroups"), IDLE_GROUP_LIST);
						if ((IDLE_GROUP_LIST_IGNORE ? !result : result))
						{
							if (!queryLib.moveClient(clientID, IDLE_MOVE_CHANNELID, null))
							{
								addLogEntry("MOVE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
							}
							else
							{
								if (IDLE_MOVE_BACK)
								{
									IDLE_CLIENTS_MOVED.addElement(clientID);
									IDLE_CLIENTS_MOVED_CHANNEL.addElement(channelID);
								}
								addLogEntry("IDLE_MOVE", clientInfo, false);
								sendMessageToClient(IDLE_MESSAGE_MODE, clientID, IDLE_MESSAGE);
							}
						}
					}
				}
			}
			else if (IDLE_WARN_TIME > 0 && idleTime > IDLE_WARN_TIME)
			{
				if (IDLE_CLIENTS_WARN_SENT.indexOf(clientID) == -1)
				{
					if (DEBUG) System.out.println("handleIdleUser() Client id " + clientID + " need idle warning");
					
					int channelID = Integer.parseInt(clientInfo.get("cid"));
					boolean result = isIDListed(channelID, IDLE_CHANNEL_LIST);
					if (channelID != IDLE_MOVE_CHANNELID && (IDLE_CHANNEL_LIST_IGNORE ? !result : result))
					{
						result = isGroupListed(clientInfo.get("client_servergroups"), IDLE_GROUP_LIST);
						if ((IDLE_GROUP_LIST_IGNORE ? !result : result))
						{
							if (sendMessageToClient(IDLE_WARN_MESSAGE_MODE, clientID, IDLE_WARN_MESSAGE))
							{
								idleClientsWarnSentTemp.addElement(clientID);
							}
							else
							{
								addLogEntry("IDLE_WARN_ERROR", "Unable to send idle warn message, maybe an invalid message mode in config file?", false);
							}
						}
					}
				}
				else
				{
					idleClientsWarnSentTemp.addElement(clientID);
				}
			}
		}
		
		if (cachePos != -1 && idleTime < (CHECK_INTERVAL * 2000) && clientInfo.get("client_away").equals("0") && 
				clientInfo.get("client_output_muted").equals("0") && clientInfo.get("client_input_muted").equals("0") && 
				clientInfo.get("client_output_hardware").equals("1") && clientInfo.get("client_input_hardware").equals("1"))
		{
			if (Integer.parseInt(clientInfo.get("cid")) != IDLE_MOVE_CHANNELID)
			{
				IDLE_CLIENTS_MOVED.removeElementAt(cachePos);
				IDLE_CLIENTS_MOVED_CHANNEL.removeElementAt(cachePos);
			}
			else
			{
				if (!queryLib.moveClient(clientID, IDLE_CLIENTS_MOVED_CHANNEL.elementAt(cachePos), null))
				{
					addLogEntry("MOVE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
				}
				else
				{
					IDLE_CLIENTS_MOVED.removeElementAt(cachePos);
					IDLE_CLIENTS_MOVED_CHANNEL.removeElementAt(cachePos);
					addLogEntry("IDLE_MOVE_BACK", clientInfo, false);
				}
			}
		}
	}
	
	private boolean addComplainToUser(String message, String logType, HashMap<String, String> clientInfo)
	{
		try
		{
			int icldbid = Integer.parseInt(clientInfo.get("client_database_id"));
			if (!queryLib.complainAdd(icldbid, message))
			{
				addLogEntry("COMPLAIN_ERROR", queryLib.getLastError() + " - Client DB ID: " + Integer.toString(icldbid), queryLib.getLastErrorPermissionID(), false);
			}
			else
			{
				addLogEntry(logType, clientInfo, false);
			}
			
			return true;
		}
		catch (Exception e)
		{
			addLogEntry("COMPLAIN_ERROR", e.toString() + " - Client DB ID: " + clientInfo.get("client_database_id"), false);
		}
		
		return false;
	}
	
	private boolean sendMessageToClient(String mode, int clientID, String message)
	{
		if (mode == null) return false;
		
		boolean retValue = false;
		if (mode.equalsIgnoreCase("poke"))
		{
			if (!queryLib.pokeClient(clientID, message))
			{
				addLogEntry("POKE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
			}
			else
			{
				retValue = true;
			}
		}
		else if (mode.equalsIgnoreCase("chat"))
		{
			if (!queryLib.sendTextMessage(clientID, JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, message))
			{
				addLogEntry("MESSAGE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
			}
			else
			{
				retValue = true;
			}
		}
		
		return retValue;
	}
	
	private boolean isClientMuted(HashMap<String, String> clientInfo)
	{
		boolean retValue = false;
		
		if (MUTE_MOVE_HEADPHONE)
		{
			if (clientInfo.get("client_output_muted").equals("1"))
			{
				retValue = true;
			}
		}
		
		if (MUTE_MOVE_MICROPHONE)
		{
			if (clientInfo.get("client_input_muted").equals("1"))
			{
				retValue = true;
			}
		}
		
		if (MUTE_MOVE_HEADPHONE_HARDWARE)
		{
			if (clientInfo.get("client_output_hardware").equals("0"))
			{
				retValue = true;
			}
		}
		
		if (MUTE_MOVE_MICROPHONE_HARDWARE)
		{
			if (clientInfo.get("client_input_hardware").equals("0"))
			{
				retValue = true;
			}
		}
		
		return retValue;
	}
	
	private short getMaxMessageLength(String type)
	{
		if (type == null)
		{
			return Short.MAX_VALUE;
		}
		
		if (type.equalsIgnoreCase("chat"))
		{
			return 1023;
		}
		else if (type.equalsIgnoreCase("poke"))
		{
			return 100;
		}
		else if (type.equalsIgnoreCase("kick"))
		{
			return 80;
		}
		
		return Short.MAX_VALUE;
	}
	
	private boolean isMessageLengthValid(String type, String message)
	{
		if (message.length() > getMaxMessageLength(type))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	private long getIdleTime(HashMap<String, String> clientInfo, int ignoreInChannel)
	{
		long currentIdleTime = Long.MAX_VALUE;
		try
		{
			currentIdleTime = Long.parseLong(clientInfo.get("client_idle_time"));
		}
		catch (NumberFormatException nfe)
		{
			if (!clientInfo.get("cid").equals(Integer.toString(ignoreInChannel)))
			{
				addLogEntry("CLIENT_IDLE_TIME_WARNING", "TS3 Server sends wrong client_idle_time for client " + clientInfo.get("client_nickname") + " (id: " + clientInfo.get("clid") + ")", false);
			}
		}
		
		return currentIdleTime;
	}
	
	private boolean isIDListed(int searchID, Vector<Integer> list)
	{
		for (int listID : list)
		{
			if (searchID == listID)
			{
				return true;
			}
		}
		
		return false;
	}
	
	private boolean isGroupListed(String groupIDs, Vector<Integer> list)
	{
		StringTokenizer groupTokenizer = new StringTokenizer(groupIDs, ",", false);
		int groupID;
		
		while (groupTokenizer.hasMoreTokens())
		{
			groupID = Integer.parseInt(groupTokenizer.nextToken());
			for (int gID : list)
			{
				if (groupID == gID)
				{
					return true;
				}
			}
		}
		
		return false;
	}
	
	private String getServerGroupName(int groupID)
	{
		if (serverGroupListCache == null || groupID < 0)
		{
			return null;
		}
		
		for (HashMap<String, String> serverGroupInfo : serverGroupListCache)
		{
			if (serverGroupInfo.get("sgid").equals(Integer.toString(groupID)))
			{
				return serverGroupInfo.get("name");
			}
		}
		
		return null;
	}
	
	private int getListedGroup(String groupIDs, Vector<Integer> list)
	{
		StringTokenizer groupTokenizer = new StringTokenizer(groupIDs, ",", false);
		int groupID;
		
		while (groupTokenizer.hasMoreTokens())
		{
			groupID = Integer.parseInt(groupTokenizer.nextToken());
			for (int gID : list)
			{
				if (groupID == gID)
				{
					return groupID;
				}
			}
		}
		
		return -1;
	}
	
	private int getTargetChannel(String groupIDs, HashMap<Integer, Integer> list)
	{
		StringTokenizer groupTokenizer = new StringTokenizer(groupIDs, ",", false);
		int groupID;
		Integer channelID = null;
		
		while (groupTokenizer.hasMoreTokens())
		{
			groupID = Integer.parseInt(groupTokenizer.nextToken());
			channelID = list.get(groupID);
			if (channelID != null)
			{
				return channelID.intValue();
			}
		}
		
		return -1;
	}
	
	boolean isGroupListed(String groupIDs, int searchGroupID)
	{
		StringTokenizer groupTokenizer = new StringTokenizer(groupIDs, ",", false);
		int groupID;
		
		while (groupTokenizer.hasMoreTokens())
		{
			groupID = Integer.parseInt(groupTokenizer.nextToken());
			if (groupID == searchGroupID)
			{
				return true;
			}
		}
		
		return false;
	}
	
	private void handleChatMessage(HashMap<String, String> eventInfo)
	{
		if (Integer.parseInt(eventInfo.get("invokerid")) == queryLib.getCurrentQueryClientID())
		{
			return;
		}
		
		String msg = eventInfo.get("msg").trim();
		msg = msg.replace((char)160, (char)32);
		
		boolean isFullAdmin = false;
		for (String fulladminUID : FULL_ADMIN_UID_LIST)
		{
			if (fulladminUID.equals(eventInfo.get("invokeruid")))
			{
				isFullAdmin = true;
				break;
			}
		}
		
		boolean isAdmin = false;
		if (!isFullAdmin)
		{
			for (String adminUID : ADMIN_UID_LIST)
			{
				if (adminUID.equals(eventInfo.get("invokeruid")))
				{
					isAdmin = true;
					break;
				}
			}
		}
		
		if (msg.equalsIgnoreCase("!botquit"))
		{
			chatCommands.handleBotQuit(msg, eventInfo, instanceName, isFullAdmin);
		}
		else if (msg.toLowerCase().startsWith("!botinstancestop"))
		{
			chatCommands.handleBotInstanceStop(msg, eventInfo, isFullAdmin, instanceName);
		}
		else if (msg.toLowerCase().startsWith("!botinstancestart"))
		{
			chatCommands.handleBotInstanceStart(msg, eventInfo, isFullAdmin, instanceName);
		}
		else if (msg.equalsIgnoreCase("!botinstancelist"))
		{
			chatCommands.handleBotInstanceList(msg, eventInfo, isFullAdmin);
		}
		else if (msg.equalsIgnoreCase("!botinstancelistreload"))
		{
			chatCommands.handleBotInstanceListReload(msg, eventInfo, isFullAdmin);
		}
		else if (msg.equalsIgnoreCase("!botreload"))
		{
			chatCommands.handleBotReload(msg, eventInfo, isFullAdmin, isAdmin, CONFIG_FILE_NAME);
		}
		else if (msg.equalsIgnoreCase("!botreloadall"))
		{
			chatCommands.handleBotReloadAll(msg, eventInfo, isFullAdmin);
		}
		else if (msg.equalsIgnoreCase("!botversion") || msg.equalsIgnoreCase("!botversioncheck"))
		{
			chatCommands.handleBotVersionCheck(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!botcfgreload"))
		{
			chatCommands.handleBotCfgReload(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!botcfghelp"))
		{
			chatCommands.handleBotCfgHelp(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!botcfgget"))
		{
			chatCommands.handleBotCfgGet(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!botcfgset"))
		{
			chatCommands.handleBotCfgSet(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.equalsIgnoreCase("!botcfgcheck"))
		{
			chatCommands.handleBotCfgCheck(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.equalsIgnoreCase("!botcfgsave"))
		{
			chatCommands.handleBotCfgSave(msg, eventInfo, isFullAdmin, isAdmin, CONFIG_FILE_NAME);
		}
		else if (msg.toLowerCase().startsWith("!clientsearch"))
		{
			chatCommands.handleClientSearch(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!listinactiveclients"))
		{
			chatCommands.handleListInactiveClients(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!lastseen"))
		{
			chatCommands.handleLastSeen(msg, eventInfo, isFullAdmin, isAdmin, COMMAND_LASTSEEN_PUBLIC);
		}
		else if (msg.toLowerCase().startsWith("!removechannelgroups"))
		{
			chatCommands.handleRemoveChannelGroups(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!msgchannelgroup"))
		{
			chatCommands.handleMsgChannelGroup(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!msgservergroup"))
		{
			chatCommands.handleMsgServerGroup(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!botsrvgrpprotadd"))
		{
			chatCommands.handleBotSrvGrpProtAdd(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!botsrvgrpprotremove"))
		{
			chatCommands.handleBotSrvGrpProtRemove(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!botjoinchannel"))
		{
			chatCommands.handleBotJoinChannel(msg, eventInfo, isFullAdmin, isAdmin);
		}
		else if (msg.toLowerCase().startsWith("!exec"))
		{
			chatCommands.handleExec(msg, eventInfo, isFullAdmin, COMMAND_EXEC_ENABLED);
		}
		else if (msg.equalsIgnoreCase("!testwelcome"))
		{
			if (isFullAdmin || isAdmin)
			{
				String welcomeDebugClient = createWelcomeMessage("CLIENT_ID: %CLIENT_ID%\nCLIENT_DATABASE_ID: %CLIENT_DATABASE_ID%\nCLIENT_UNIQUE_ID: %CLIENT_UNIQUE_ID%\nCLIENT_COUNTRY: %CLIENT_COUNTRY%\nCLIENT_NICKNAME: %CLIENT_NICKNAME%\nCLIENT_VERSION: %CLIENT_VERSION%\nCLIENT_PLATFORM: %CLIENT_PLATFORM%\nCLIENT_IP: %CLIENT_IP%\nCLIENT_CREATED: %CLIENT_CREATED%\nCLIENT_TOTALCONNECTIONS: %CLIENT_TOTALCONNECTIONS%\nCLIENT_MONTH_BYTES_UPLOADED: %CLIENT_MONTH_BYTES_UPLOADED%\nCLIENT_MONTH_BYTES_DOWNLOADED: %CLIENT_MONTH_BYTES_DOWNLOADED%\nCLIENT_TOTAL_BYTES_UPLOADED: %CLIENT_TOTAL_BYTES_UPLOADED%\nCLIENT_TOTAL_BYTES_DOWNLOADED: %CLIENT_TOTAL_BYTES_DOWNLOADED%", Integer.parseInt(eventInfo.get("invokerid")));
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Welcome Message Variable Debug:\n" + welcomeDebugClient);
				
				String welcomeDebugServer = createWelcomeMessage("SERVER_NAME: %SERVER_NAME%\nSERVER_PLATFORM: %SERVER_PLATFORM%\nSERVER_VERSION: %SERVER_VERSION%\nSERVER_UPTIME: %SERVER_UPTIME%\nSERVER_UPTIME_DATE: %SERVER_UPTIME_DATE%\nSERVER_CREATED_DATE: %SERVER_CREATED_DATE%\nSERVER_UPLOAD_QUOTA: %SERVER_UPLOAD_QUOTA%\nSERVER_DOWNLOAD_QUOTA: %SERVER_DOWNLOAD_QUOTA%\nSERVER_MONTH_BYTES_UPLOADED: %SERVER_MONTH_BYTES_UPLOADED%\nSERVER_MONTH_BYTES_DOWNLOADED: %SERVER_MONTH_BYTES_DOWNLOADED%\nSERVER_TOTAL_BYTES_UPLOADED: %SERVER_TOTAL_BYTES_UPLOADED%\nSERVER_TOTAL_BYTES_DOWNLOADED: %SERVER_TOTAL_BYTES_DOWNLOADED%\nSERVER_MAX_CLIENTS: %SERVER_MAX_CLIENTS%\nSERVER_RESERVED_SLOTS: %SERVER_RESERVED_SLOTS%\nSERVER_CHANNEL_COUNT: %SERVER_CHANNEL_COUNT%\nSERVER_CLIENT_COUNT: %SERVER_CLIENT_COUNT%\nSERVER_CLIENT_CONNECTIONS_COUNT: %SERVER_CLIENT_CONNECTIONS_COUNT%", Integer.parseInt(eventInfo.get("invokerid")));
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, welcomeDebugServer);
			}
		}
		else if (msg.equalsIgnoreCase("!botinfo"))
		{
			String adminText = "You have no bot admin permissions!";
			if (isFullAdmin)
			{
				adminText = "You have all bot admin permissions!";
			}
			else if (isAdmin)
			{
				adminText = "You have limited bot admin permissions!";
			}
			
			addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "On this server runs JTS3ServerMod " + VERSION + " since " + getDifferenceTime(startTime, System.currentTimeMillis()) + "\nTry !bothelp for a list of commands! " + adminText);
		}
		else if (msg.toLowerCase().startsWith("!bothelp"))
		{
			chatCommands.handleBotHelp(msg.substring(8), eventInfo, isFullAdmin, isAdmin, COMMAND_LASTSEEN_PUBLIC, COMMAND_EXEC_ENABLED);
		}
		else if (msg.toLowerCase().startsWith("!h"))
		{
			chatCommands.handleBotHelp(msg.substring(2), eventInfo, isFullAdmin, isAdmin, COMMAND_LASTSEEN_PUBLIC, COMMAND_EXEC_ENABLED);
		}
	}
	
	private void handleServerGroupNotify(HashMap<String, String> eventInfo)
	{
		if (SERVERGROUPNOTIFY_ENABLE == 1 && clientList != null)
		{
			int groupID = getListedGroup(eventInfo.get("client_servergroups"), SERVERGROUPNOTIFY_GROUPS);
			if (groupID > 0)
			{
				String sgName = getServerGroupName(groupID);
				String sgnMessage = new String(SERVERGROUPNOTIFY_MESSAGE);
				sgnMessage = sgnMessage.replace("%SERVER_GROUP_ID%", Integer.toString(groupID));
				sgnMessage = sgnMessage.replace("%SERVER_GROUP_NAME%", (sgName == null ? "Unknown" : sgName));
				sgnMessage = sgnMessage.replace("%CLIENT_NAME%", eventInfo.get("client_nickname"));
				sgnMessage = sgnMessage.replace("%CLIENT_DBID%", eventInfo.get("client_database_id"));
				sgnMessage = sgnMessage.replace("%CLIENT_UNIQUEID%", eventInfo.get("client_unique_identifier"));
				int clientID = -1;
				
				for (HashMap<String, String> clientInfo : clientList)
				{
					if (isGroupListed(clientInfo.get("client_servergroups"), SERVERGROUPNOTIFY_GROUPTARGETS))
					{
						boolean result = isIDListed(Integer.parseInt(clientInfo.get("cid")), SERVERGROUPNOTIFY_CHANNEL_LIST);
						if (SERVERGROUPNOTIFY_CHANNEL_LIST_IGNORE ? !result : result)
						{
							clientID = Integer.parseInt(clientInfo.get("clid"));
							sendMessageToClient(SERVERGROUPNOTIFY_MESSAGE_MODE, clientID, sgnMessage);
						}
					}
				}
			}
		}
	}
	
	private void handleAutoMove(HashMap<String, String> eventInfo)
	{
		if (AUTOMOVE_ENABLE == 1)
		{
			if (Integer.parseInt(eventInfo.get("ctid")) == DEFAULT_CHANNEL_ID)
			{
				int clientID = Integer.parseInt(eventInfo.get("clid"));
				int channelID = getTargetChannel(eventInfo.get("client_servergroups"), AUTOMOVE_SGCHANNEL_LIST);
				
				if (channelID > 0)
				{
					if (!queryLib.moveClient(clientID, channelID, null))
					{
						addLogEntry("AUTOMOVE_ERROR", queryLib.getLastError() + " - Client: " + eventInfo.get("client_nickname") + " (" + Integer.toString(clientID) + ") / Channel ID: " + Integer.toString(channelID), queryLib.getLastErrorPermissionID(), false);
					}
					else
					{
						sendMessageToClient(AUTOMOVE_MESSAGE_MODE, clientID, AUTOMOVE_MESSAGE);
					}
				}
			}
		}
	}
	
	private void handleWelcomeMessage(HashMap<String, String> eventInfo)
	{
		boolean alreadySent = false;
		
		if (WELCOMEMESSAGE_ENABLE == 1 && WELCOMEMESSAGE_MESSAGE != null)
		{
			if (isGroupListed(eventInfo.get("client_servergroups"), WELCOMEMESSAGE_GROUPS))
			{
				final int clientID = Integer.parseInt(eventInfo.get("clid"));
				String welcomeMessage = createWelcomeMessage(WELCOMEMESSAGE_MESSAGE, clientID);
				
				if (welcomeMessage != null)
				{
					sendMessageToClient(WELCOMEMESSAGE_MESSAGE_MODE, clientID, welcomeMessage);
				}
				alreadySent = true;
			}
		}
		
		if (WELCOMEMESSAGE_DEFAULT_ENABLE == 1 && WELCOMEMESSAGE_DEFAULT_MESSAGE != null && !alreadySent)
		{
			final int clientID = Integer.parseInt(eventInfo.get("clid"));
			String welcomeMessage = createWelcomeMessage(WELCOMEMESSAGE_DEFAULT_MESSAGE, clientID);
			
			if (welcomeMessage != null)
			{
				sendMessageToClient(WELCOMEMESSAGE_DEFAULT_MESSAGE_MODE, clientID, welcomeMessage);
			}
		}
	}
	
	private String createWelcomeMessage(String template, int clientID)
	{
		HashMap<String, String> clientInfo = queryLib.getInfo(JTS3ServerQuery.INFOMODE_CLIENTINFO, clientID);
		String welcomeMessage = null;
		
		if (clientInfo == null)
		{
			addLogEntry("WELCOMEMESSAGE_ERROR", queryLib.getLastError() + " - Client ID: " + Integer.toString(clientID), queryLib.getLastErrorPermissionID(), false);
		}
		else
		{
			try
			{
				welcomeMessage = template;
				if (clientInfo.get("cid") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_ID%", clientInfo.get("cid"));
				if (clientInfo.get("client_database_id") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_DATABASE_ID%", clientInfo.get("client_database_id"));
				if (clientInfo.get("client_unique_identifier") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_UNIQUE_ID%", clientInfo.get("client_unique_identifier"));
				if (clientInfo.get("client_country") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_COUNTRY%", clientInfo.get("client_country"));
				if (clientInfo.get("client_nickname") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_NICKNAME%", clientInfo.get("client_nickname"));
				if (clientInfo.get("client_version") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_VERSION%", getVersionString(clientInfo.get("client_version")));
				if (clientInfo.get("client_platform") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_PLATFORM%", clientInfo.get("client_platform"));
				if (clientInfo.get("connection_client_ip") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_IP%", clientInfo.get("connection_client_ip"));
				if (clientInfo.get("client_created") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_CREATED%", sdf.format(new Date(Long.parseLong(clientInfo.get("client_created")) * 1000)));
				if (clientInfo.get("client_totalconnections") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_TOTALCONNECTIONS%", clientInfo.get("client_totalconnections"));
				if (clientInfo.get("client_month_bytes_uploaded") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_MONTH_BYTES_UPLOADED%", getFileSizeString(Long.parseLong(clientInfo.get("client_month_bytes_uploaded")), false));
				if (clientInfo.get("client_month_bytes_downloaded") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_MONTH_BYTES_DOWNLOADED%", getFileSizeString(Long.parseLong(clientInfo.get("client_month_bytes_downloaded")), false));
				if (clientInfo.get("client_total_bytes_uploaded") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_TOTAL_BYTES_UPLOADED%", getFileSizeString(Long.parseLong(clientInfo.get("client_total_bytes_uploaded")), false));
				if (clientInfo.get("client_total_bytes_downloaded") != null) welcomeMessage = welcomeMessage.replace("%CLIENT_TOTAL_BYTES_DOWNLOADED%", getFileSizeString(Long.parseLong(clientInfo.get("client_total_bytes_downloaded")), false));
				
				if (serverInfoCache != null)
				{
					if (serverInfoCache.getServerName() != null) welcomeMessage = welcomeMessage.replace("%SERVER_NAME%", serverInfoCache.getServerName());
					if (serverInfoCache.getServerPlatform() != null) welcomeMessage = welcomeMessage.replace("%SERVER_PLATFORM%", serverInfoCache.getServerPlatform());
					if (serverInfoCache.getServerVersion() != null) welcomeMessage = welcomeMessage.replace("%SERVER_VERSION%", getVersionString(serverInfoCache.getServerVersion()));
					welcomeMessage = welcomeMessage.replace("%SERVER_UPTIME%", getDifferenceTime(serverInfoCache.getServerUptimeTimestamp(), System.currentTimeMillis()));
					welcomeMessage = welcomeMessage.replace("%SERVER_CREATED_DATE%", sdf.format(new Date(serverInfoCache.getServerCreatedAt())));
					welcomeMessage = welcomeMessage.replace("%SERVER_UPTIME_DATE%", sdf.format(new Date(serverInfoCache.getServerUptimeTimestamp())));
					welcomeMessage = welcomeMessage.replace("%SERVER_UPLOAD_QUOTA%", Long.toString(serverInfoCache.getServerUploadQuota()));
					welcomeMessage = welcomeMessage.replace("%SERVER_DOWNLOAD_QUOTA%", Long.toString(serverInfoCache.getServerDownloadQuota()));
					welcomeMessage = welcomeMessage.replace("%SERVER_MONTH_BYTES_UPLOADED%", getFileSizeString(serverInfoCache.getServerMonthBytesUploaded(), false));
					welcomeMessage = welcomeMessage.replace("%SERVER_MONTH_BYTES_DOWNLOADED%", getFileSizeString(serverInfoCache.getServerMonthBytesDownloaded(), false));
					welcomeMessage = welcomeMessage.replace("%SERVER_TOTAL_BYTES_UPLOADED%", getFileSizeString(serverInfoCache.getServerTotalBytesUploaded(), false));
					welcomeMessage = welcomeMessage.replace("%SERVER_TOTAL_BYTES_DOWNLOADED%", getFileSizeString(serverInfoCache.getServerTotalBytesDownloaded(), false));
					welcomeMessage = welcomeMessage.replace("%SERVER_MAX_CLIENTS%", Integer.toString(serverInfoCache.getServerMaxClients()));
					welcomeMessage = welcomeMessage.replace("%SERVER_RESERVED_SLOTS%", Integer.toString(serverInfoCache.getServerReservedSlots()));
					welcomeMessage = welcomeMessage.replace("%SERVER_CHANNEL_COUNT%", Integer.toString(serverInfoCache.getServerChannelCount()));
					welcomeMessage = welcomeMessage.replace("%SERVER_CLIENT_COUNT%", Integer.toString(serverInfoCache.getServerClientCount()));
					welcomeMessage = welcomeMessage.replace("%SERVER_CLIENT_CONNECTIONS_COUNT%", Long.toString(serverInfoCache.getServerClientConnectionsCount()));
				}
			}
			catch (Exception e)
			{
				addLogEntry(e, false);
				welcomeMessage = null;
			}
		}
		
		return welcomeMessage;
	}
	
	private String getVersionString(String version)
	{
		String searchString = " [Build: ";
		int pos1 = version.indexOf(searchString);
		int pos2 = version.indexOf("]", pos1 + searchString.length());
		
		try
		{
			long lTime = Long.parseLong(version.substring(pos1 + searchString.length(), pos2)) * 1000;
			return version.substring(0, pos1) + " (" + sdf.format(new Date(lTime)) + ")";
		}
		catch (Exception e)
		{
			return version;
		}
	}
	
	private String getFileSizeString(long size, final boolean base1000)
	{
		int base = (base1000 ? 1000 : 1024);
		String retValue;
		double value;
		
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMinimumFractionDigits(1);
		nf.setMaximumFractionDigits(2);
		
		if (size > (base * base * base))
		{
			value = (((double)size / base) / base) / base;
			retValue = nf.format(value) + " " + (base1000 ? "GB" : "GiB");
		}
		else if (size > (base * base))
		{
			value = ((double)size / base) / base;
			retValue = nf.format(value) + " " + (base1000 ? "MB" : "MiB");
		}
		else if (size > base)
		{
			value = (double)size / base;
			retValue = nf.format(value) + " " + (base1000 ? "kB" : "KiB");
		}
		else
		{
			retValue = size + " byte";
		}
		
		return retValue;
	}
	
	public void teamspeakActionPerformed(String eventType, HashMap<String, String> eventInfo)
	{
		try
		{
			if (eventType.equals("notifytextmessage"))
			{
				handleChatMessage(eventInfo);
			}
			else if (eventType.equals("notifycliententerview"))
			{
				if (Integer.parseInt(eventInfo.get("client_type")) == 0)
				{
					handleAutoMove(eventInfo);
					handleServerGroupNotify(eventInfo);
					handleWelcomeMessage(eventInfo);
					if (clientCache != null) clientCache.updateSingleClient(eventInfo);
				}
			}
		}
		catch (Throwable e)
		{
			addLogEntry(e, false);
		}
	}
	
	private void runCheck()
	{
		try
		{
			checkTS3Clients();
		}
		catch (NullPointerException e0)
		{
			addLogEntry("WARNING", "An error occurred, make sure that you use at least TS3 server version beta 19!", true);
			addLogEntry(e0, false);
		}
		catch (OutOfMemoryError ome)
		{
			addLogEntry("CRITICAL", "Out of Memory Error occurred!", true);
			addLogEntry("CRITICAL", "Check if you set enough RAM for the java virtual machine (-mx argument)!", true);
			addLogEntry(ome, false);
			manager.stopAllInstances("CRITICAL", "Error occurred, check logfile of the virtual bot instance " + instanceName);
			return;
		}
		catch (VirtualMachineError vme)
		{
			addLogEntry("CRITICAL", "Virtual Machine Error occurred!", true);
			addLogEntry(vme, false);
			manager.stopAllInstances("CRITICAL", "Error occurred, check logfile of the virtual bot instance " + instanceName);
			return;
		}
		catch (Throwable ex)
		{
			addLogEntry(ex, false);
		}
		finally
		{
			if (timerCheck != null)
			{
				timerCheck = new TimerTask()
				{
					public void run()
					{
						runCheck();
					}
				};
				botTimer.schedule(timerCheck, CHECK_INTERVAL*1000);
			}
		}
	}
	
	private String getDifferenceTime(long from, long to)
	{
	    long difference = to - from;
	    int days = (int)(difference / (1000 * 60 * 60 * 24));
	    int hours = (int)(difference / (1000 * 60 * 60) % 24);
	    int minutes = (int)(difference / (1000 * 60) % 60);
	    int seconds = (int)(difference / 1000 % 60);
	    
	    NumberFormat nf = NumberFormat.getInstance();
	    nf.setMinimumIntegerDigits(2);
	    nf.setMaximumIntegerDigits(2);
	    
	    StringBuffer timeString = new StringBuffer();
	    if (days > 0)
	    {
	    	timeString.append(days);
	    	timeString.append(" days and ");
	    }
	    
	    if (days > 0 || hours > 0)
	    {
	    	timeString.append(hours);
	    	timeString.append(":");
	    	timeString.append(nf.format(minutes));
	    	timeString.append(":");
	    	timeString.append(nf.format(seconds));
	    	timeString.append(" hours/minutes/seconds.");
	    }
	    else if (minutes > 0)
	    {
	    	timeString.append(minutes);
	    	timeString.append(":");
	    	timeString.append(nf.format(seconds));
	    	timeString.append(" minutes/seconds.");
	    }
	    else
	    {
	    	timeString.append(seconds);
	    	timeString.append(" seconds.");
	    }
	    
	    return timeString.toString();
	}
	
	private void addLogEntry(String type, HashMap<String, String> clientInfo, int serverGroupID, boolean outputToSystemOut)
	{
		try
		{
			String msgOut;
			if (type.equalsIgnoreCase("SERVERGROUPPROTECTION_ADD_GROUP"))
			{
				msgOut = "Added client \"" + clientInfo.get("client_nickname") + "\" to server group " + Integer.toString(serverGroupID) + "!";
			}
			else if (type.equalsIgnoreCase("SERVERGROUPPROTECTION_REMOVE_GROUP"))
			{
				msgOut = "Removed client \"" + clientInfo.get("client_nickname") + "\" from server group " + Integer.toString(serverGroupID) + "!";
			}
			else if (type.equalsIgnoreCase("SERVERGROUPPROTECTION_ADD_GROUP_ERROR"))
			{
				msgOut = "Error while adding client \"" + clientInfo.get("client_nickname") + "\" to server group " + Integer.toString(serverGroupID) + "!";
			}
			else if (type.equalsIgnoreCase("SERVERGROUPPROTECTION_REMOVE_GROUP_ERROR"))
			{
				msgOut = "Error while removing client \"" + clientInfo.get("client_nickname") + "\" from server group " + Integer.toString(serverGroupID) + "!";
			}
			else if (type.equalsIgnoreCase("SERVERGROUPPROTECTION_COMPLAINADD"))
			{
				msgOut = "Added complaint to client \"" + clientInfo.get("client_nickname") + "\", not allowed to be in the server group " + Integer.toString(serverGroupID) + "!";
			}
			else
			{
				msgOut = "Client \"" + clientInfo.get("client_nickname") + "\"";
			}
			
			if (DEBUG) System.out.print(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + type.toUpperCase() + "\t" + clientInfo.get("client_database_id") + "\t");
			if (DEBUG || outputToSystemOut) System.out.println(instanceName + ": " + msgOut);
			
			if (logFile != null)
			{
				logFile.println(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + type.toUpperCase() + "\t" + clientInfo.get("client_database_id") + "\t" + msgOut);
			}
		}
		catch (Exception e)
		{
		}
	}
	
	private void addLogEntry(String type, HashMap<String, String> clientInfo, boolean outputToSystemOut)
	{
		try
		{
			String msgOut;
			if (type.equalsIgnoreCase("RECORD_MOVE"))
			{
				msgOut = "Client \"" + clientInfo.get("client_nickname") + "\" started recording, client was moved and poked!";
			}
			else if (type.equalsIgnoreCase("RECORD_KICK"))
			{
				msgOut = "Client \"" + clientInfo.get("client_nickname") + "\" started recording, client was kicked!";
			}
			else if (type.equalsIgnoreCase("RECORD_COMPLAINADD"))
			{
				msgOut = "Added complaint to recording client \"" + clientInfo.get("client_nickname") + "\"!";
			}
			else if (type.equalsIgnoreCase("IDLE_MOVE"))
			{
				msgOut = "Client \"" + clientInfo.get("client_nickname") + "\" was idle, client was moved and got a message!";
			}
			else if (type.equalsIgnoreCase("IDLE_KICK"))
			{
				msgOut = "Client \"" + clientInfo.get("client_nickname") + "\" was idle, client was kicked!";
			}
			else if (type.equalsIgnoreCase("AWAY_MOVE"))
			{
				msgOut = "Client status of \"" + clientInfo.get("client_nickname") + "\" is away, client was moved!";
			}
			else if (type.equalsIgnoreCase("AWAY_MOVE_BACK"))
			{
				msgOut = "Client status of \"" + clientInfo.get("client_nickname") + "\" is not away anymore, client was moved back!";
			}
			else if (type.equalsIgnoreCase("MUTE_MOVE"))
			{
				msgOut = "Client status of \"" + clientInfo.get("client_nickname") + "\" is muted, client was moved!";
			}
			else if (type.equalsIgnoreCase("MUTE_MOVE_BACK"))
			{
				msgOut = "Client status of \"" + clientInfo.get("client_nickname") + "\" is not muted anymore, client was moved back!";
			}
			else if (type.equalsIgnoreCase("BADNICKNAME_COMPLAINADD"))
			{
				msgOut = "Added complaint to client with the bad nickname \"" + clientInfo.get("client_nickname") + "\"!";
			}
			else if (type.equalsIgnoreCase("BADNICKNAME_KICK"))
			{
				msgOut = "Client \"" + clientInfo.get("client_nickname") + "\" was kicked, nickname matched bad nickname rules!";
			}
			else if (type.equalsIgnoreCase("SERVERGROUPPROTECTION_KICK"))
			{
				msgOut = "Client \"" + clientInfo.get("client_nickname") + "\" was kicked and removed from protected server groups, unique ID is not on list!";
			}
			else
			{
				msgOut = "Client \"" + clientInfo.get("client_nickname") + "\"";
			}
			
			if (DEBUG) System.out.print(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + type.toUpperCase() + "\t" + clientInfo.get("client_database_id") + "\t");
			if (DEBUG || outputToSystemOut) System.out.println(instanceName + ": " + msgOut);
			
			if (logFile != null)
			{
				logFile.println(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + type.toUpperCase() + "\t" + clientInfo.get("client_database_id") + "\t" + msgOut);
			}
		}
		catch (Exception e)
		{
		}
	}
	
	void addLogEntry(String type, String msg, boolean outputToSystemOut)
	{
		addLogEntry(type, msg, -1, outputToSystemOut);
	}
	
	void addLogEntry(String type, String msg, int permissionID, boolean outputToSystemOut)
	{
		try
		{
			if (outputToSystemOut) System.out.println(instanceName + ": " + msg);
			if (DEBUG) System.out.println(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + type.toUpperCase() + "\t" + instanceName + ": " + msg);
			if (logFile != null)
			{
				logFile.println(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + type.toUpperCase() + "\t" + msg);
			}

			if (permissionID > 0)
			{
				String permissionName = getPermissionName(permissionID);
				if (permissionName != null)
				{
					String permissionMsg = "Missing permission or not enough power: " + permissionName;
					if (outputToSystemOut) System.out.println(instanceName + ": " + permissionMsg);
					if (logFile != null)
					{
						logFile.println(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + type.toUpperCase() + "\t" + permissionMsg);
					}
				}
			}
		}
		catch (Exception ex)
		{
		}
	}
	
	private void addLogEntry(Throwable e, boolean outputToSystemOut)
	{
		try
		{
			if (DEBUG || outputToSystemOut) System.out.println(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + instanceName + ": " + e.toString());
			if (logFile != null)
			{
				logFile.println(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + instanceName + ": " + "EXCEPTION - Bot Version: " + VERSION);
				e.printStackTrace(logFile);
			}
		}
		catch (Exception ex)
		{
		}
	}
}
