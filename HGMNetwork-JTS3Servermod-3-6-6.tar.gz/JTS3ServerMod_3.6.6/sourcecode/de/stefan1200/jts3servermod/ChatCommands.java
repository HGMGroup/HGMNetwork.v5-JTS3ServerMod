package de.stefan1200.jts3servermod;

import java.io.BufferedInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Vector;

import de.stefan1200.jts3serverquery.JTS3ServerQuery;
import de.stefan1200.util.ArrangedPropertiesWriter;

public class ChatCommands
{
	ArrangedPropertiesWriter config;
	JTS3ServerMod modClass;
	JTS3ServerQuery queryLib;
	ClientDatabaseCache clientCache;
	InstanceManager manager;
	SimpleDateFormat sdf;
	
	public ChatCommands(JTS3ServerQuery queryLib, JTS3ServerMod modClass, ClientDatabaseCache clientCache, SimpleDateFormat sdf, ArrangedPropertiesWriter config, InstanceManager manager)
	{
		this.queryLib = queryLib;
		this.modClass = modClass;
		this.clientCache = clientCache;
		this.sdf = sdf;
		this.config = config;
		this.manager = manager;
	}
	
	void handleBotQuit(String msg, HashMap<String, String> eventInfo, String instanceName, boolean isFullAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin)
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Bye Bye, my master! Stopping all instances...");
			manager.stopAllInstances("COMMAND", "Got !botquit command from " + eventInfo.get("invokername") + " on virtual bot instance " + instanceName);
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotVersionCheck(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			StringBuffer versionInfo = new StringBuffer();
			
			try
			{
				HashMap<String, String> versionData = JTS3ServerMod.getVersionCheckData();
				if (versionData != null)
				{
					if (versionData.get("final.version") != null && versionData.get("final.url") != null)
					{
						versionInfo.append("\n[b]Latest final version:[/b] " + versionData.get("final.version") + " - [url=" + versionData.get("final.url") + "]Download[/url]");
					}
					
					if (versionData.get("dev.version") != null && versionData.get("dev.url") != null)
					{
						versionInfo.append("\n[b]Latest development version:[/b] " + versionData.get("dev.version") + " - [url=" + versionData.get("dev.url") + "]Download[/url]");
					}
				}
			}
			catch (Exception e)
			{
			}
			
			if (versionInfo.length() == 0)
			{
				versionInfo.append("\nError while getting version information!");
			}
			
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "[b]Current installed version:[/b] " + JTS3ServerMod.VERSION + versionInfo.toString());
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotInstanceStop(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, String instanceName)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin)
		{
			if (msg.length() < 17)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Bye Bye, my master! Stopping this instance...");
				modClass.stopBotInstance(0);
			}
			else if (msg.length() == 17)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botinstancestop [name]");
			}
			else
			{
				String name = msg.substring(17).trim();
				if (name.equalsIgnoreCase(instanceName))
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Bye Bye, my master! Stopping this instance...");
					modClass.stopBotInstance(0);
				}
				else
				{
					if (manager.stopInstance(name))
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Instance [b]" + name + "[/b] stopped!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Instance name [b]" + name + "[/b] not found or not running! Get a instance name list with !botinstancelist");
					}
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotInstanceStart(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, String instanceName)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin)
		{
			if (msg.length() <= 18)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botinstancestart <name>");
			}
			else
			{
				String name = msg.substring(18).trim();
				
				if (name.equalsIgnoreCase(instanceName))
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Instance [b]" + name + "[/b] is already running!");
				}
				else if (manager.startInstance(name))
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Instance [b]" + name + "[/b] started!");
				}
				else
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Instance name [b]" + name + "[/b] not found, is already running or config file missing! Get a instance name list with !botinstancelist");
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotInstanceList(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin)
		{
			StringBuffer instanceString = new StringBuffer();
			Vector<String> instanceNames = manager.getInstanceNames();
			for (String string : instanceNames)
			{
				if (instanceString.length() > 0)
				{
					instanceString.append("\n");
				}
				instanceString.append(string);
				instanceString.append(" - ");
				
				if (manager.isInstanceRunning(string) == 1)
				{
					instanceString.append("Running");
				}
				else
				{
					instanceString.append("Not Running");
				}
			}
			
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "[b]List of instance names:[/b]\n" + instanceString.toString());
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotInstanceListReload(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin)
		{
			if (manager.loadConfig())
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Succesfully reloaded the instance list!");
			}
			else
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading the instance list!");
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotReload(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin, String CONFIG_FILE_NAME)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			JTS3ServerMod configCheck = new JTS3ServerMod(CONFIG_FILE_NAME);
			int configOK = configCheck.loadAndCheckConfig(true);
			if (configOK == 0)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Config file OK, restarting now!");
				modClass.stopBotInstance(2);
			}
			else
			{
				String errorMsg = configCheck.getErrorMessage(configOK);

				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Config file checked and found following errors:\n" + errorMsg);
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotReloadAll(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin)
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Restarting all instances!");
			manager.reloadAllInstances();
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotCfgReload(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() > 14)
			{
				String cfgname = msg.substring(14);
				if (cfgname.equalsIgnoreCase("advertising"))
				{
					if (modClass.loadAdvertisingMessages())
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Advertising messages reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading advertising messages!");
					}
				}
				else if (cfgname.equalsIgnoreCase("automove"))
				{
					if (modClass.loadAutoMoveFile())
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Auto Move config reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Auto Move config!");
					}
				}
				else if (cfgname.equalsIgnoreCase("away"))
				{
					if (modClass.loadAwayMessages())
					{
						modClass.createMessages();
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Away Mover messages reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Away Mover messages!");
					}
				}
				else if (cfgname.equalsIgnoreCase("badchannel"))
				{
					if (modClass.loadBadChannelNameFile())
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Bad Channel Name rules reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Bad Channel Name rules!");
					}
				}
				else if (cfgname.equalsIgnoreCase("badnick"))
				{
					if (modClass.loadBadNicknameFile())
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Bad Nickname rules reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Bad Nickname rules and kick message!");
					}
				}
				else if (cfgname.equalsIgnoreCase("idle"))
				{
					if (modClass.loadIdleMessages())
					{
						modClass.createMessages();
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Idle Check messages reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Idle Check messages!");
					}
				}
				else if (cfgname.equalsIgnoreCase("mute"))
				{
					if (modClass.loadMuteMessages())
					{
						modClass.createMessages();
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Mute Mover messages reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Mute Mover messages!");
					}
				}
				else if (cfgname.equalsIgnoreCase("record"))
				{
					if (modClass.loadRecordMessages())
					{
						modClass.createMessages();
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Record Check messages reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Record Check messages!");
					}
				}
				else if (cfgname.equalsIgnoreCase("sgnotify"))
				{
					if (modClass.loadServerGroupNotifyMessages())
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Server Group Notify message reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Server Group Notify message!");
					}
				}
				else if (cfgname.equalsIgnoreCase("sgprotection"))
				{
					if (modClass.loadServerGroupProtectionFile())
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Server Group Protection kick message and client list reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Server Group Protection kick message and client list!");
					}
				}
				else if (cfgname.equalsIgnoreCase("welcome"))
				{
					if (modClass.loadWelcomeMessages())
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Welcome messages reloaded!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reloading Welcome messages!");
					}
				}
			}
			else
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, 
						"Wrong usage! Right: !botcfgreload <config name>\nPossible config names are:\nadvertising\nautomove\naway\nbadchannel\nbadnick\nidle\nmute\nrecord\nsgnotify\nsgprotection\nwelcome");
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotCfgHelp(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() < 13)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "[b]List of config keys:[/b]\n");
				
				StringBuffer keyString = new StringBuffer();
				Vector<String> configKeys = config.getKeys();
				
				for (int i = 0; i<configKeys.size(); i++)
				{
					if (!isFullAdmin && configKeys.elementAt(i).toLowerCase().startsWith("ts3_"))
					{
						continue;
					}
					
					if (keyString.length() != 0)
					{
						keyString.append(", ");
					}
					
					keyString.append(configKeys.elementAt(i));
					
					if (keyString.length() > 900)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, keyString.toString());
						keyString = new StringBuffer();
					}
				}
				
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, keyString.toString());
			}
			else
			{
				String key = msg.substring(12).trim();
				String helpText = config.getHelpText(key);
				if (helpText == null)
				{
					StringBuffer keyString = new StringBuffer();
					Vector<String> configKeys = config.getKeys();
					
					for (int i = 0; i<configKeys.size(); i++)
					{
						if (!configKeys.elementAt(i).toLowerCase().startsWith(key.toLowerCase()))
						{
							continue;
						}
						
						if (keyString.length() != 0)
						{
							keyString.append(", ");
						}
						keyString.append(configKeys.elementAt(i));
					}
					
					if (keyString.length() > 0)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "[b]List of config keys starting with:[/b] " + key + "\n");
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, keyString.toString());
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Key [b]" + key + "[/b] is not valid!");
					}
				}
				else
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "[b]Help of " + key + ":[/b]\n" + helpText);
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotCfgGet(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() < 13)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botcfgget <key>");
			}
			else
			{
				String key = msg.substring(11).trim();
				
				if (key.length() < 3)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botcfgget <key>");
				}
				else
				{
					if (!isFullAdmin && key.toLowerCase().startsWith("ts3_"))
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Requesting value of key [b]" + key + "[/b] is not allowed!");
					}
					else
					{
						String value = config.getValue(key);
						if (value == null)
						{
							if (config.getKeys().indexOf(key) == -1)
							{
								queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Key [b]" + key + "[/b] is not valid!");
							}
							else
							{
								queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "No value set for key [b]" + key + "[/b]!");
							}
						}
						else
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Value of [b]" + key + "[/b]:" + (value.length() > 10 ? "\n" : " ") + value);
						}
					}
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotCfgSet(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() < 13)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botcfgset <key> = <value>");
			}
			else
			{
				String args = msg.substring(11).trim();
				int pos = args.indexOf("=");
				
				if (args.length() < 3 || pos == -1)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botcfgset <key> = <value>");
				}
				else
				{
					String key = args.substring(0, pos).trim();
					String value = args.substring(pos+1).trim();
					
					if (!isFullAdmin && key.toLowerCase().startsWith("ts3_"))
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Setting value for key [b]" + key + "[/b] is not allowed!");
					}
					else
					{
						if (config.setValue(key, value))
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Successfully set key [b]" + key + "[/b] to value:" + (value.length() > 6 ? "\n" : " ") + value + "\nDon't forget to do [b]!botcfgsave[/b] to make this change permanent!");
						}
						else
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Key [b]" + key + "[/b] is not valid!");
						}
					}
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotCfgCheck(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			JTS3ServerMod configCheck = new JTS3ServerMod(config);
			int configOK = configCheck.loadAndCheckConfig(false);
			
			if (configOK == 0)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Config OK!");
			}
			else
			{
				String errorMsg = configCheck.getErrorMessage(configOK);

				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Config checked and found following errors:\n" + errorMsg);
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotCfgSave(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin, String CONFIG_FILE_NAME)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			JTS3ServerMod configCheck = new JTS3ServerMod(config);
			int configOK = configCheck.loadAndCheckConfig(false);
			
			if (configOK == 0)
			{
				if (config.save(CONFIG_FILE_NAME, "Config file of the JTS3ServerMod\nhttp://www.stefan1200.de\nThis file must be saved with the encoding ISO-8859-1!"))
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Config OK and written to disk! Do [b]!botreload[/b] to see the changes!");
				}
				else
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Config OK, but an error occurred while writing to disk! Maybe file write protected?");
				}
			}
			else
			{
				String errorMsg = configCheck.getErrorMessage(configOK);

				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Config checked and found following errors:\n" + errorMsg + "\nNot written to disk!");
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleClientSearch(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (clientCache == null)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Client database cache disabled, command disabled!");
			}
			else
			{
				if (msg.length() < 15)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !clientsearch <clientname>\nYou can use * as wildcard!");
				}
				else
				{
					String clientname = msg.substring(14).trim();
					if (clientname.indexOf("**") != -1)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage, only single wildcards are allowed!");
					}
					else
					{
						if (clientCache.isUpdateRunning())
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Client database cache is updating, please wait some time and try again!");
						}
						else
						{
							Vector<Integer> clientSearch = clientCache.searchClientNickname(clientname);
							if (clientSearch == null)
							{
								queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage, use a valid search pattern with at least 3 characters!");
							}
							else
							{
								if (clientSearch.size() == 0)
								{
									queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "No clients found in the database!");
								}
								else if (clientSearch.size() > 5)
								{
									queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Found " + Integer.toString(clientSearch.size()) + " entries in the database, please refine your search.");
								}
								else
								{
									StringBuffer sb = new StringBuffer("Found " + Integer.toString(clientSearch.size()) + " entries in the database:\n");
									
									for (int clientDBID : clientSearch)
									{
										try
										{
											long createdAt = ((long)clientCache.getCreatedAt(clientDBID)) * 1000;
											long lastOnline = ((long)clientCache.getLastOnline(clientDBID)) * 1000;
											sb.append("[b]" + clientCache.getNickname(clientDBID) + "[/b] ([i]DB ID:[/i] " + Integer.toString(clientDBID) + ")  [i]public unique ID:[/i] " + clientCache.getUniqueID(clientDBID) + "  [i]created at:[/i] " + sdf.format(new Date(createdAt)) + "  [i]last seen at:[/i] " + sdf.format(new Date(lastOnline)) + "\n");
										}
										catch (Exception e)
										{
											e.printStackTrace();
										}
									}
									
									queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, sb.toString());
								}
							}
						}
					}
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleListInactiveClients(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (clientCache == null)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Client database cache disabled, command disabled!");
			}
			else
			{
				if (msg.length() < 22)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !listinactiveclients <days>");
				}
				else
				{
					int days = -1;
					try
					{
						days = Integer.parseInt(msg.substring(21).trim());
					}
					catch (Exception e)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !listinactiveclients <minimum days inactive>");
					}
					
					if (days >= 10)
					{
						Vector<Integer> result = clientCache.searchInactiveClients(days);
						
						if (result == null)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Please wait until the client database cache is ready!");
						}
						else if (result.size() > 10)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Found " + Integer.toString(result.size()) + " clients which are inactive for at least " + Integer.toString(days) + " days! Please use a higher day value to list this clients.");
						}
						else
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Found " + Integer.toString(result.size()) + " clients which are inactive for at least " + Integer.toString(days) + " days!");
							StringBuffer clientList = new StringBuffer();
							long currentTime = System.currentTimeMillis() / 1000;
							
							for (int i = 0; i < result.size(); i++)
							{
								if (clientList.length() > 0)
								{
									clientList.append(", ");
								}
								
								clientList.append("[b]" + clientCache.getNickname(result.elementAt(i)) + "[/b] ([i]DB ID:[/i] ");
								clientList.append(result.elementAt(i));
								clientList.append(" - ");
								clientList.append((int)((currentTime - clientCache.getLastOnline(result.elementAt(i))) / (60 * 60 * 24)));
								clientList.append(" [i]days[/i])");
							}
							
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, clientList.toString());
						}
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Lowest possible days to list inactive players are 10 days!");
					}
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleLastSeen(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin, boolean COMMAND_LASTSEEN_PUBLIC)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin || COMMAND_LASTSEEN_PUBLIC)
		{
			if (clientCache == null)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Client database cache disabled, command disabled!");
			}
			else
			{
				if (msg.length() < 11)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !lastseen <clientname>\nYou can use * as wildcard!");
				}
				else
				{
					String clientname = msg.substring(10).trim();
					if (clientname.indexOf("**") != -1)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage, only single wildcards are allowed!");
					}
					else
					{
						if (clientCache.isUpdateRunning())
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Client database cache is updating, please wait some time and try again!");
						}
						else
						{
							Vector<Integer> clientSearch = clientCache.searchClientNickname(clientname);
							if (clientSearch == null)
							{
								queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage, use a valid search pattern with at least 3 characters!");
							}
							else
							{
								if (clientSearch.size() == 0)
								{
									queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "No clients found in the database!");
								}
								else if (clientSearch.size() > 5)
								{
									queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Found " + Integer.toString(clientSearch.size()) + " entries in the database, please refine your search.");
								}
								else
								{
									StringBuffer sb = new StringBuffer("Found " + Integer.toString(clientSearch.size()) + " entries in the database:\n");
									
									Vector<HashMap<String, String>> clientList = queryLib.getList(JTS3ServerQuery.LISTMODE_CLIENTLIST);
									boolean foundClient = false;
									
									for (int clientDBID : clientSearch)
									{
										for (HashMap<String, String> clientOnline : clientList)
										{
											if (clientDBID == Integer.parseInt(clientOnline.get("client_database_id")) && Integer.parseInt(clientOnline.get("client_type")) == 0)
											{
												if (clientOnline.get("clid").equals(eventInfo.get("invokerid")))
												{
													sb.append("[b]" + clientOnline.get("client_nickname") + "[/b] need a mirror :)\n");
												}
												else
												{
													sb.append("[b]" + clientOnline.get("client_nickname") + "[/b] is currently online\n");
												}
												foundClient = true;
												break;
											}
										}
										
										if (!foundClient)
										{
											try
											{
												long lastOnline = ((long)clientCache.getLastOnline(clientDBID)) * 1000;
												sb.append("[b]" + clientCache.getNickname(clientDBID) + "[/b] was last seen at " + sdf.format(new Date(lastOnline)) + "\n");
											}
											catch (Exception e)
											{
												e.printStackTrace();
											}
										}
										foundClient = false;
									}
									
									queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, sb.toString());
								}
							}
						}
					}
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleRemoveChannelGroups(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() > 21)
			{
				HashMap<String, String> serverInfo = queryLib.getInfo(JTS3ServerQuery.INFOMODE_SERVERINFO, -1);
				if (serverInfo == null)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while getting server info, command aborted...");
				}
				else
				{
					Vector<Integer> channelList = new Vector<Integer>();
					int defChannelGroupID = -1;
					int clientIDArg = -1;
					boolean doAction = false;
					
					try
					{
						defChannelGroupID = Integer.parseInt(serverInfo.get("virtualserver_default_channel_group"));
						clientIDArg = Integer.parseInt(msg.substring(21));
						
						HashMap<String, String> cgcListResponse = queryLib.doCommand("channelgroupclientlist cldbid=" + Integer.toString(clientIDArg));
						if (cgcListResponse.get("id").equals("0"))
						{
							Vector<HashMap<String, String>> channelGroupClientList = queryLib.parseRawData(cgcListResponse.get("response"));
							for (HashMap<String, String> hashMap : channelGroupClientList)
							{
								if (Integer.parseInt(hashMap.get("cgid")) != defChannelGroupID)
								{
									channelList.addElement(Integer.parseInt(hashMap.get("cid")));
								}
							}
							
							doAction = true;
						}
					}
					catch (NumberFormatException nfe)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while parsing numbers, command aborted...");
					}
					
					if (doAction)
					{
						int count = 0;
						int errorcount = 0;
						for (int channelID : channelList)
						{
							HashMap<String, String> actionResponse = queryLib.doCommand("setclientchannelgroup cgid=" + Integer.toString(defChannelGroupID) + " cid=" + channelID + " cldbid=" + Integer.toString(clientIDArg));
							if (actionResponse.get("id").equals("0"))
							{
								++count;
							}
							else
							{
								++errorcount;
							}
						}
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Channel group for client database id " + Integer.toString(clientIDArg) + " successfully set to default channel group for " + Integer.toString(count) + " channels!" + (errorcount > 0 ? " " + Integer.toString(errorcount) + " channels could not set to default channel group!" : ""));
					}
				}
			}
			else
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !removechannelgroups <client database id>");
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleMsgChannelGroup(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() > 20)
			{
				int pos = msg.indexOf(" ", 17);
				if (pos == -1)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !msgchannelgroup <channelgroup id> <message>");
				}
				else
				{
					Vector<Integer> clientListSend = new Vector<Integer>();
					String sendMessage = "Message from " + eventInfo.get("invokername") + ": " + msg.substring(pos+1);
					boolean doAction = false;
					try
					{
						int targetChannelGroup = Integer.parseInt(msg.substring(17, pos));
						Vector<HashMap<String, String>> clientListGroups = queryLib.getList(JTS3ServerQuery.LISTMODE_CLIENTLIST, "-groups");
						
						for (HashMap<String, String> hashMap : clientListGroups)
						{
							if (Integer.parseInt(hashMap.get("client_channel_group_id")) == targetChannelGroup)
							{
								clientListSend.addElement(Integer.parseInt(hashMap.get("clid")));
							}
						}
						
						doAction = true;
					}
					catch (NumberFormatException nfe)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while parsing numbers, command aborted...");
					}
					
					if (doAction)
					{
						int count = 0;
						int errorcount = 0;
						for (int clientid : clientListSend)
						{
							if (queryLib.sendTextMessage(clientid, JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, sendMessage))
							{
								++count;
							}
							else
							{
								++errorcount;
							}
						}
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Message sent to " + Integer.toString(count) + " clients!" + (errorcount > 0 ? " Error while sending message to " + Integer.toString(errorcount) + " clients!" : ""));
					}
				}
			}
			else
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !msgchannelgroup <channelgroup id> <message>");
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleMsgServerGroup(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() > 19)
			{
				int pos = msg.indexOf(" ", 16);
				if (pos == -1)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !msgservergroup <servergroup id> <message>");
				}
				else
				{
					Vector<Integer> clientListSend = new Vector<Integer>();
					String sendMessage = "Message from " + eventInfo.get("invokername") + ": " + msg.substring(pos+1);
					boolean doAction = false;
					try
					{
						int targetChannelGroup = Integer.parseInt(msg.substring(16, pos));
						Vector<HashMap<String, String>> clientListGroups = queryLib.getList(JTS3ServerQuery.LISTMODE_CLIENTLIST, "-groups");
						
						for (HashMap<String, String> hashMap : clientListGroups)
						{
							if (modClass.isGroupListed(hashMap.get("client_servergroups"), targetChannelGroup))
							{
								clientListSend.addElement(Integer.parseInt(hashMap.get("clid")));
							}
						}
						
						doAction = true;
					}
					catch (NumberFormatException nfe)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while parsing numbers, command aborted...");
					}
					
					if (doAction)
					{
						int count = 0;
						int errorcount = 0;
						for (int clientid : clientListSend)
						{
							if (queryLib.sendTextMessage(clientid, JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, sendMessage))
							{
								++count;
							}
							else
							{
								++errorcount;
							}
						}
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Message sent to " + Integer.toString(count) + " clients!" + (errorcount > 0 ? " Error while sending message to " + Integer.toString(errorcount) + " clients!" : ""));
					}
				}
			}
			else
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !msgservergroup <servergroup id> <message>");
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleExec(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean COMMAND_EXEC_ENABLED)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (msg.toLowerCase().startsWith("!execwait"))
		{
			handleExecWait(msg, eventInfo, isFullAdmin, COMMAND_EXEC_ENABLED);
		}
		else
		{
			if (isFullAdmin)
			{
				if (COMMAND_EXEC_ENABLED)
				{
					if (msg.length() >= 7)
					{
						try
						{
							Runtime.getRuntime().exec(msg.substring(6));
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Command executed!");
						}
						catch (Exception e)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while executing command!");
						}
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !exec <system command>");
					}
				}
				else
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Command disabled!");
				}
			}
			else
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
			}
		}
	}
	
	void handleExecWait(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean COMMAND_EXEC_ENABLED)
	{
		if (isFullAdmin)
		{
			if (COMMAND_EXEC_ENABLED)
			{
				if (msg.length() >= 11)
				{
					try
					{
						Process proc = Runtime.getRuntime().exec(msg.substring(10));
						BufferedInputStream bisOut = new BufferedInputStream(proc.getInputStream());
						BufferedInputStream bisErr = new BufferedInputStream(proc.getErrorStream());
						int returnValue = proc.waitFor();
						
						StringBuffer output = new StringBuffer();
						while (bisOut.available() > 0)
						{
							output.append((char)bisOut.read());
						}
						while (bisErr.available() > 0)
						{
							output.append((char)bisErr.read());
						}
						
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Command executed with a return value of " + Integer.toString(returnValue) + "!\n");
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Output:\n" + output.toString());
					}
					catch (Exception e)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while executing command!");
					}
				}
				else
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !execwait <system command>");
				}
			}
			else
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Command disabled!");
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotSrvGrpProtAdd(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() < 30)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botsrvgrpprotadd <server group id> <client unique id>");
			}
			else
			{
				try
				{
					StringTokenizer st = new StringTokenizer(msg.substring(18), " ", false);
					int serverGroupID = -1;
					String clientUniqueID = null;
					
					String tmp = st.nextToken().trim();
					try
					{
						serverGroupID = Integer.parseInt(tmp);
						tmp = st.nextToken().trim();
						clientUniqueID = new String(tmp);
					}
					catch (Exception e)
					{
						clientUniqueID = new String(tmp);
						tmp = st.nextToken().trim();
						serverGroupID = Integer.parseInt(tmp);
					}
					
					if (clientUniqueID.length() < 20)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reading given client unique id!");
					}
					else if (serverGroupID < 1)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reading given server group id!");
					}
					else
					{
						int retValue = modClass.addServerGroupProtectionEntry(serverGroupID, clientUniqueID);
						if (retValue == 1)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Successfully added client to protected server group!");
						}
						else if (retValue == 0)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Client was already on that list for server group " + Integer.toString(serverGroupID) + "!");
						}
						else if (retValue == -1)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Unable to save server group protection configuration file! Check if the configuration file is write protected!");
						}
						else if (retValue == -2)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Unable to add client to protected server group! Server group protection feature must be enabled and server group " + Integer.toString(serverGroupID) + " has to be on the watch list of the server group protection feature. Please make sure that this feature is enabled and add this server group to config value servergroupprotection_groups first!");
						}
						else if (retValue == -3)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Unable to add client to protected server group! Server group protection feature is disabled, enable it first!");
						}
					}
				}
				catch (Exception e)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reading given server group id!");
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotSrvGrpProtRemove(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() < 33)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botsrvgrpprotremove <server group id> <client unique id>");
			}
			else
			{
				try
				{
					StringTokenizer st = new StringTokenizer(msg.substring(21), " ", false);
					int serverGroupID = -1;
					String clientUniqueID = null;
					
					String tmp = st.nextToken().trim();
					try
					{
						serverGroupID = Integer.parseInt(tmp);
						tmp = st.nextToken().trim();
						clientUniqueID = new String(tmp);
					}
					catch (Exception e)
					{
						clientUniqueID = new String(tmp);
						tmp = st.nextToken().trim();
						serverGroupID = Integer.parseInt(tmp);
					}
					
					if (clientUniqueID.length() < 20)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reading given client unique id!");
					}
					else if (serverGroupID < 1)
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reading given server group id!");
					}
					else
					{
						int retValue = modClass.removeServerGroupProtectionEntry(serverGroupID, clientUniqueID);
						if (retValue == 1)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Successfully removed client from protected server group!");
						}
						else if (retValue == 0)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Client is already not on that list for server group " + Integer.toString(serverGroupID) + "!");
						}
						else if (retValue == -1)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Unable to save server group protection configuration file! Check if the configuration file is write protected!");
						}
						else if (retValue == -2)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Unable to removed client from protected server group! Server group protection feature must be enabled and server group " + Integer.toString(serverGroupID) + " has to be on the watch list of the server group protection feature. Please make sure that this feature is enabled and add this server group to config value servergroupprotection_groups first!");
						}
						else if (retValue == -3)
						{
							queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Unable to removed client from protected server group! Server group protection feature is disabled, enable it first!");
						}
					}
				}
				catch (Exception e)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reading given server group id!");
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotJoinChannel(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": " + msg, false);
		if (isFullAdmin || isAdmin)
		{
			if (msg.length() < 17)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !botjoinchannel <channel id>");
			}
			else
			{
				try
				{
					int newChannelID = Integer.parseInt(msg.substring(16).trim());
					
					if (newChannelID == queryLib.getCurrentQueryClientChannelID())
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Bot is already in the given channel!");
					}
					else if (queryLib.moveClient(queryLib.getCurrentQueryClientID(), newChannelID, null))
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Bot was moved into the given channel!");
					}
					else
					{
						queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while moving bot into the given channel!\n"+queryLib.getLastError());
					}
				}
				catch (Exception e)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Error while reading given channel id!");
				}
			}
		}
		else
		{
			queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "You are not my master!");
		}
	}
	
	void handleBotHelp(String msg, HashMap<String, String> eventInfo, boolean isFullAdmin, boolean isAdmin, boolean COMMAND_LASTSEEN_PUBLIC, boolean COMMAND_EXEC_ENABLED)
	{
		modClass.addLogEntry("COMMAND", "Got command from " + eventInfo.get("invokername") + ": !bothelp" + msg, false);
		if (msg.length() < 2)
		{
			StringBuffer helpText = new StringBuffer("List of commands:\n!botinfo");
			StringBuffer helpTextFullAdmin = new StringBuffer();
			
			if (isFullAdmin || isAdmin || COMMAND_LASTSEEN_PUBLIC)
			{
				helpText.append("\n!lastseen <search pattern>");
			}
			
			if (isFullAdmin || isAdmin)
			{
				helpText.append("\n\nYou can also use the following admin commands:\n!botcfghelp [key]\n!botcfgget <key>\n!botcfgset <key> = <value>\n!botcfgcheck\n!botcfgreload <config name>\n!botcfgsave\n!botjoinchannel <channel id>\n!botreload\n!botsrvgrpprotadd <server group id> <client unique id>\n!botsrvgrpprotremove <server group id> <client unique id>\n!botversioncheck\n!clientsearch <nickname>\n!listinactiveclients <days>\n!msgchannelgroup <channelgroup id> <message>\n!msgservergroup <servergroup id> <message>\n!removechannelgroups <client database id>");
			}
			
			if (isFullAdmin)
			{
				helpTextFullAdmin.append("You can also use the following full admin commands:\n!botinstancestart <name>\n!botinstancestop <name>\n!botinstancelist\n!botinstancelistreload\n!botreloadall\n!botquit");
			}
			
			if (isFullAdmin && COMMAND_EXEC_ENABLED)
			{
				helpTextFullAdmin.append("\n!exec <system command>\n!execwait <system command>");
			}
			
			String lastMessage = "\n\nTo get a help about the commands, just do !bothelp <command>";
			if (isFullAdmin)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, helpText.toString());
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, helpTextFullAdmin.toString() + lastMessage);
			}
			else
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, helpText.toString() + lastMessage);
			}
		}
		else
		{
			String args = msg.substring(1).trim().toLowerCase();
			
			if (args.length() < 3)
			{
				queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Wrong usage! Right: !bothelp <command>");
			}
			else
			{
				if (args.charAt(0) == '!')
				{
					args = args.substring(1);
				}
				
				String helpText = null;
				
				if (args.equals("botinfo"))
				{
					helpText = "Shows you the running bot version and uptime.";
				}
				else if (args.equals("botquit"))
				{
					helpText = "Disconnect and quits all bot instances.";
				}
				else if (args.equals("botreload"))
				{
					helpText = "Disconnects the current bot instance, reload config file from disk and start bot instance again. Config file will be checked first!";
				}
				else if (args.equals("botreloadall"))
				{
					helpText = "Disconnects all bot instances, reload config file from disk and start all bot instances again. This command do not check config file first!";
				}
				else if (args.equals("botversioncheck") || args.equals("botversion"))
				{
					helpText = "Displays current installed, latest final and latest development versions of this bot.";
				}
				else if (args.equals("botcfghelp"))
				{
					helpText = "Returns informations about a config key. If no key argument given, a list of config keys will be returned.\nExample: !botcfghelp ts3_server_address";
				}
				else if (args.equals("botcfgget"))
				{
					helpText = "Returns the value of a current config key.\nExample: !botcfgget ts3_server_address";
				}
				else if (args.equals("botcfgset"))
				{
					helpText = "Set a new value for a config key. Notice: This changes will not used by the bot without saving and reloading!\nExample: !botcfgset ts3_server_address = ts3.server.net";
				}
				else if (args.equals("botcfgcheck"))
				{
					helpText = "Check if current config (for example after !botcfgset) is valid.";
				}
				else if (args.equals("botcfgreload"))
				{
					helpText = "Reloads a single config file. Just enter !botcfgreload without argument to get a list of possible config names.";
				}
				else if (args.equals("botcfgsave"))
				{
					helpText = "Writes current config to disk.";
				}
				else if (args.equals("clientsearch"))
				{
					helpText = "Shows some database informations of a client. Use * as a wildcard.\nclientsearch: !lastseen *foo*bar*";
				}
				else if (args.equals("listinactiveclients"))
				{
					helpText = "List all clients which are inactive since X days.";
				}
				else if (args.equals("lastseen"))
				{
					helpText = "Shows the last online time of a client. Use * as a wildcard.\nExample: !lastseen *foo*bar*";
				}
				else if (args.equals("botinstancestart"))
				{
					helpText = "Starts a bot instance with the given name. Usage: !botinstancestart <name>";
				}
				else if (args.equals("botinstancestop"))
				{
					helpText = "Stops a bot instance with the given name. If no name given, the current instance will be stopped. Usage: !botinstancestop [name]";
				}
				else if (args.equals("botinstancelist"))
				{
					helpText = "Shows a list of all bot instances with the current status.";
				}
				else if (args.equals("botinstancelistreload"))
				{
					helpText = "Reloads the instance list from file.";
				}
				else if (args.equals("removechannelgroups"))
				{
					helpText = "Sets all non-default channel groups of a client to the default channel group in all channels!";
				}
				else if (args.equals("msgchannelgroup"))
				{
					helpText = "Sends a private message to all online clients with this specified channel group at the moment.";
				}
				else if (args.equals("msgservergroup"))
				{
					helpText = "Sends a private message to all online clients that are member of the specified server group.";
				}
				else if (args.equals("botsrvgrpprotadd"))
				{
					helpText = "Adds a client unique id to a protected server group (this will also saved into config).";
				}
				else if (args.equals("botsrvgrpprotremove"))
				{
					helpText = "Removes a client unique id from a protected server group (this will also saved into config).";
				}
				else if (args.equals("botjoinchannel"))
				{
					helpText = "Switch the bot into another channel.";
				}
				else if (args.equals("exec"))
				{
					helpText = "Executes the specified command.";
				}
				else if (args.equals("execwait"))
				{
					helpText = "Executes the specified command and waits for process end. Program output and return code will be send as answer.";
				}
				
				if (helpText == null)
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "No such command: [b]!" + args + "[/b]!");
				}
				else
				{
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, "Help of the command [b]!" + args + "[/b]:\n");
					queryLib.sendTextMessage(Integer.parseInt(eventInfo.get("invokerid")), JTS3ServerQuery.TEXTMESSAGE_TARGET_CLIENT, helpText);
				}
			}
		}
	}
}
