package de.stefan1200.jts3servermod;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class InstanceManager
{
	public static final String DEFAULT_LOG_FILE_PATH = "JTS3ServerMod_InstanceManager.log";
	public static final String DEFAULT_CONFIG_FILE_PATH = "config/JTS3ServerMod_InstanceManager.cfg";
	private String CONFIG_FILE_NAME = "config/JTS3ServerMod_InstanceManager.cfg";
	private String LOG_FILE_NAME = "JTS3ServerMod_InstanceManager.log";
	private Vector<String> FULL_ADMIN_UID_LIST = new Vector<String>();
	private Vector<JTS3ServerMod> instanceClass = new Vector<JTS3ServerMod>();
	private Vector<String> instanceConfigFilePath = new Vector<String>();
	private Vector<String> instanceLogFilePath = new Vector<String>();
	private Vector<String> instanceName = new Vector<String>();
	private Vector<Boolean> instanceDebug = new Vector<Boolean>();
	private Vector<Boolean> instanceEnabled = new Vector<Boolean>();
	private Vector<JTS3ServerMod> instanceClassReloadTemp = null;
	private Vector<String> instanceConfigFilePathReloadTemp = null;
	private Vector<String> instanceLogFilePathReloadTemp = null;
	private Vector<String> instanceNameReloadTemp = null;
	private Vector<Boolean> instanceDebugReloadTemp = null;
	private Vector<Boolean> instanceEnabledReloadTemp = null;
	private SimpleDateFormat sdfDebug = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private PrintStream logFile;
	
	private boolean alreadyStopped = false;
    private boolean botCommandExec = false;
	private boolean firstInit = true;
	
	public InstanceManager(String instanceConfig, String instanceLog)
	{
		if (instanceConfig != null)
		{
			CONFIG_FILE_NAME = instanceConfig;
		}
		
		if (instanceLog != null)
		{
			LOG_FILE_NAME = instanceLog;
		}
		
		try
		{
			logFile = new PrintStream(new FileOutputStream(LOG_FILE_NAME, true), true, "UTF-8");
		}
		catch (Exception e)
		{
			
		}
		
		addLogEntry("START_MANAGER", "JTS3ServerMod " + JTS3ServerMod.VERSION + " Instance Manager started...", true);
		String msg;
		
		if (!loadConfig())
		{
			msg = "InstanceManager config file does not exists or is not readable, quitting now...";
			addLogEntry("QUIT_MANAGER", msg, true);
		}
		else if (startAllInstances() == 0)
		{
			msg = "No instances enabled or needed entries missing in InstanceManager config file, quitting now...";
			addLogEntry("QUIT_MANAGER", msg, true);
		}
		else
		{
			firstInit = false;
			
			Runtime runtime = Runtime.getRuntime();
			runtime.addShutdownHook(new Thread(new Runnable()
			{
				public void run()
				{
					if (!alreadyStopped)
					{
						stopAllInstances("SHUTDOWN", "Got signal from operating system, quitting now...");
					}
				}
			}));
		}
	}
	
	void removeInstance(JTS3ServerMod instance)
	{
		for (int i=0; i<instanceClass.size(); i++)
		{
			if (instanceClass.elementAt(i) == instance)
			{
				instanceClass.setElementAt(null, i);
				break;
			}
		}
	}
	
	int isInstanceRunning(String name)
	{
		if (name == null || name.length() < 1)
		{
			return -1;
		}
		
		for (int i=0; i<instanceName.size(); i++)
		{
			if (instanceName.elementAt(i).equalsIgnoreCase(name))
			{
				if (instanceClass.elementAt(i) == null)
				{
					return 0;
				}
				else
				{
					return 1;
				}
			}
		}
		
		return -1;
	}
	
	Vector<String> getInstanceNames()
	{
		Vector<String> retList = new Vector<String>();
		retList.addAll(instanceName);
		return retList;
	}
	
	private boolean startInstance(int i)
	{
		if (instanceClass.elementAt(i) == null)
		{
			File instanceFile = new File(instanceConfigFilePath.elementAt(i));
			if (instanceFile.isFile())
			{
				addLogEntry("START_INSTANCE", "Start bot instance " + instanceName.elementAt(i) + "...", false);
				instanceClass.setElementAt(new JTS3ServerMod(this, instanceName.elementAt(i), instanceConfigFilePath.elementAt(i), instanceLogFilePath.elementAt(i), instanceDebug.elementAt(i), FULL_ADMIN_UID_LIST, botCommandExec), i);
				instanceClass.elementAt(i).runThread();
				return true;
			}
			else
			{
				addLogEntry("CHECK_INSTANCE", "Config file of instance " + instanceName.elementAt(i) + " is missing! Start of this instance skipped...", true);
			}
		}
		
		return false;
	}
	
	boolean startInstance(String name)
	{
		if (name == null || name.length() < 1)
		{
			return false;
		}
		
		for (int i=0; i<instanceName.size(); i++)
		{
			if (instanceName.elementAt(i).equalsIgnoreCase(name))
			{
				return startInstance(i);
			}
		}
		
		return false;
	}
	
	boolean stopInstance(String name)
	{
		if (name == null || name.length() < 1)
		{
			return false;
		}
		
		for (int i=0; i<instanceName.size(); i++)
		{
			if (instanceName.elementAt(i).equalsIgnoreCase(name))
			{
				if (instanceClass.elementAt(i) != null)
				{
					addLogEntry("STOP_INSTANCE", "Stop bot instance " + instanceName.elementAt(i) + "...", false);
					instanceClass.elementAt(i).stopBotInstance(0);
					return true;
				}
			}
		}
		
		return false;
	}
	
	void stopAllInstances()
	{
		stopAllInstances(null, null);
	}
	
	void stopAllInstances(String messageType, String message)
	{
		if (messageType != null && message != null)
		{
			addLogEntry(messageType, message, false);
		}
		
		addLogEntry("STOP_ALL", "Stopping all instances and quit manager...", false);
		for (int i=0; i<instanceClass.size(); i++)
		{
			if (instanceClass.elementAt(i) != null)
			{
				instanceClass.elementAt(i).stopBotInstance(0);
			}
		}
		alreadyStopped = true;
		
		int countTimer = 0;
		while (countTimer < 10)
		{
			++countTimer;
			
			try
			{
				Thread.sleep(100);
			}
			catch (Exception e)
			{
			}
		}
	}
	
	void reloadAllInstances()
	{
		addLogEntry("RELOAD_ALL", "Reload all instances...", false);
		for (int i=0; i<instanceClass.size(); i++)
		{
			if (instanceClass.elementAt(i) != null)
			{
				instanceClass.elementAt(i).stopBotInstance(2);
			}
		}
	}
	
	private int startAllInstances()
	{
		int count = 0;
		for (int i=0; i<instanceEnabled.size(); i++)
		{
			if (instanceEnabled.elementAt(i))
			{
				if (startInstance(i))
				{
					++count;
				}
			}
		}
		return count;
	}
	
	boolean loadConfig()
	{
		boolean retValue = false;
		try
		{
			File confFile = new File(CONFIG_FILE_NAME);
			
			if (!confFile.isFile())
			{
				return false;
			}
			
			Properties prop = new Properties();
			prop.load(new FileInputStream(confFile));
			
			if (firstInit)
			{
				String fulladminListTemp = prop.getProperty("bot_fulladmin_list");
				if (fulladminListTemp != null)
				{
					StringTokenizer fulladminListTokenizer = new StringTokenizer(fulladminListTemp, ",", false);
					while (fulladminListTokenizer.hasMoreTokens())
					{
						FULL_ADMIN_UID_LIST.addElement(fulladminListTokenizer.nextToken().trim());
					}
				}
				
				String temp = prop.getProperty("bot_command_exec", "0");
				if (temp.equals("1"))
				{
					botCommandExec = true;
				}
				else
				{
					botCommandExec = false;
				}
			}
			
			instanceClassReloadTemp = new Vector<JTS3ServerMod>();
			instanceConfigFilePathReloadTemp = new Vector<String>();
			instanceLogFilePathReloadTemp = new Vector<String>();
			instanceNameReloadTemp = new Vector<String>();
			instanceDebugReloadTemp = new Vector<Boolean>();
			instanceEnabledReloadTemp = new Vector<Boolean>();
			
			if (loadInstanceListFile(prop))
			{
				int oldNamePos = -1;
				for (int i = 0; i < instanceNameReloadTemp.size(); i++)
				{
					oldNamePos = instanceName.indexOf(instanceNameReloadTemp.elementAt(i));
					if (oldNamePos != -1)
					{
						instanceClassReloadTemp.setElementAt(instanceClass.elementAt(oldNamePos), i);
					}
				}
				
				int newNamePos = -1;
				for (int i = 0; i < instanceName.size(); i++)
				{
					newNamePos = instanceNameReloadTemp.indexOf(instanceName.elementAt(i));
					if (newNamePos == -1)
					{
						stopInstance(instanceName.elementAt(i));
					}
				}
				
				instanceName.clear();
				instanceLogFilePath.clear();
				instanceEnabled.clear();
				instanceDebug.clear();
				instanceConfigFilePath.clear();
				instanceClass.clear();
				
				instanceName.addAll(instanceNameReloadTemp);
				instanceLogFilePath.addAll(instanceLogFilePathReloadTemp);
				instanceEnabled.addAll(instanceEnabledReloadTemp);
				instanceDebug.addAll(instanceDebugReloadTemp);
				instanceConfigFilePath.addAll(instanceConfigFilePathReloadTemp);
				instanceClass.addAll(instanceClassReloadTemp);
				
				instanceNameReloadTemp = null;
				instanceLogFilePathReloadTemp = null;
				instanceEnabledReloadTemp = null;
				instanceDebugReloadTemp = null;
				instanceConfigFilePathReloadTemp = null;
				instanceClassReloadTemp = null;
				
				retValue = true;
			}
		}
		catch (Throwable e)
		{
			retValue = false;
		}
		
		return retValue;
	}
	
	private boolean loadInstanceListFile(Properties prop)
	{
		try
		{
			String configPath;
			String logPath;
			String name;
			String debug;
			String enabled;
			File instanceFile;
			int breakCount = 0;
			
			for (int i=1; true; i++)
			{
				enabled = prop.getProperty(Integer.toString(i) + ".instance_enable");
				if (enabled != null)
				{
					breakCount = 0;
					name = prop.getProperty(Integer.toString(i) + ".instance_name");
					configPath = prop.getProperty(Integer.toString(i) + ".instance_config_path");
					logPath = prop.getProperty(Integer.toString(i) + ".instance_logfile_path");
					debug = prop.getProperty(Integer.toString(i) + ".instance_debug", "0");
					
					if (name != null && name.length() > 0 && configPath != null && configPath.length() > 0)
					{
						instanceClassReloadTemp.addElement(null);
						instanceConfigFilePathReloadTemp.addElement(configPath);
						
						if (instanceNameReloadTemp.indexOf(name) == -1)
						{
							instanceNameReloadTemp.addElement(name);
						}
						else
						{
							instanceNameReloadTemp.addElement(name + Integer.toString(i));
						}
						
						if (logPath == null || logPath.length() < 2)
						{
							instanceLogFilePathReloadTemp.addElement(null);
						}
						else
						{
							instanceLogFilePathReloadTemp.addElement(logPath);
						}
						
						if (enabled.equals("1"))
						{
							instanceFile = new File(configPath);
							if (instanceFile.isFile())
							{
								instanceEnabledReloadTemp.addElement(true);
							}
							else
							{
								addLogEntry("CHECK_INSTANCE", "Config file of instance " + name + " is missing! Disable instance...", true);
								instanceEnabledReloadTemp.addElement(false);
							}
						}
						else
						{
							instanceEnabledReloadTemp.addElement(false);
						}
						
						if (debug.equals("1"))
						{
							instanceDebugReloadTemp.addElement(true);
						}
						else
						{
							instanceDebugReloadTemp.addElement(false);
						}
					}
				}
				else
				{
					++breakCount;
					if (breakCount > 10)
					{
						break;
					}
				}
			}
		}
		catch (Exception e)
		{
			return false;
		}
		
		return true;
	}
	
	private void addLogEntry(String type, String msg, boolean outputToSystemOut)
	{
		try
		{
			if (logFile != null)
			{
				if (outputToSystemOut) System.out.println(msg);
				logFile.println(sdfDebug.format(new Date(System.currentTimeMillis())) + "\t" + type.toUpperCase() + "\t" + msg);
			}
		}
		catch (Exception ex)
		{
		}
	}
}
